## What changes

## Checklist
- [ ] Read-only: nothing modifies the system; any new command is in the runner allowlist with tests
- [ ] Warnings/errors carry evidence; unavailable data returns `SKIP` with a reason
- [ ] Tests added (fixtures of real command output for parsers)
- [ ] `pytest`, `ruff check .`, `ruff format --check .`, `mypy`, `bandit -q -r lume` pass
- [ ] `CHANGELOG.md` updated
