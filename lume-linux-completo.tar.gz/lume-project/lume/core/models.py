"""Result model shared by every diagnostic check.

A check never reports a problem without evidence: ``WARN`` and ``ERROR``
results must carry at least one piece of evidence explaining the verdict.
``SKIP`` is not a classification of the system: it means a check could not run
(missing tool, missing permission, ``--offline``) and says why.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass, field
from enum import StrEnum


class Status(StrEnum):
    """Outcome of a check."""

    OK = "OK"  # normal operation
    WARN = "WARN"  # possible problem
    ERROR = "ERROR"  # identified problem
    SKIP = "SKIP"  # could not be checked (not a verdict about the system)


@dataclass(frozen=True, slots=True)
class CheckResult:
    """Outcome of a single diagnostic check.

    Attributes:
        name: Short human-readable name of what was checked.
        status: Classification of the result.
        summary: One-line explanation shown to the user.
        evidence: Raw facts supporting the verdict (required for WARN/ERROR).
        check_id: Stable identifier (e.g. ``storage.space``) used to link
            solutions and to compare runs.
    """

    name: str
    status: Status
    summary: str
    evidence: tuple[str, ...] = field(default_factory=tuple)
    check_id: str = ""

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("CheckResult.name must not be empty")
        if self.status in (Status.WARN, Status.ERROR) and not self.evidence:
            raise ValueError(
                f"{self.status.value} result '{self.name}' requires evidence; "
                "LUME does not flag problems without proof"
            )

    def to_dict(self) -> dict[str, object]:
        """Return a JSON-serializable representation."""
        return {
            "id": self.check_id,
            "name": self.name,
            "status": self.status.value,
            "summary": self.summary,
            "evidence": list(self.evidence),
        }


def ok(check_id: str, name: str, summary: str, evidence: Iterable[str] = ()) -> CheckResult:
    """Build an ``OK`` result."""
    return CheckResult(name, Status.OK, summary, tuple(evidence), check_id)


def warn(check_id: str, name: str, summary: str, evidence: Iterable[str]) -> CheckResult:
    """Build a ``WARN`` result (evidence is mandatory)."""
    return CheckResult(name, Status.WARN, summary, tuple(evidence), check_id)


def error(check_id: str, name: str, summary: str, evidence: Iterable[str]) -> CheckResult:
    """Build an ``ERROR`` result (evidence is mandatory)."""
    return CheckResult(name, Status.ERROR, summary, tuple(evidence), check_id)


def skip(check_id: str, name: str, reason: str) -> CheckResult:
    """Build a ``SKIP`` result explaining why the check could not run."""
    return CheckResult(name, Status.SKIP, reason, (), check_id)


def summarize(results: Iterable[CheckResult]) -> dict[Status, int]:
    """Count results per status. Every status is present in the output."""
    counts = Counter(r.status for r in results)
    return {status: counts.get(status, 0) for status in Status}
