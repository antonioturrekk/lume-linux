"""Filesystem locations used by LUME, following the XDG Base Directory spec.

Nothing is created here: functions only compute paths. Directories are created
by the code that actually needs to write to them.
"""

from __future__ import annotations

import os
from pathlib import Path

APP_DIR_NAME = "lume"


def _xdg_dir(env_var: str, fallback: Path) -> Path:
    """Return ``$env_var`` if it is an absolute path, otherwise ``fallback``."""
    value = os.environ.get(env_var, "")
    if value and os.path.isabs(value):
        return Path(value)
    return fallback


def data_dir() -> Path:
    """Persistent user data (history database)."""
    return _xdg_dir("XDG_DATA_HOME", Path.home() / ".local" / "share") / APP_DIR_NAME


def state_dir() -> Path:
    """State and logs (application log, audit log of operations)."""
    return _xdg_dir("XDG_STATE_HOME", Path.home() / ".local" / "state") / APP_DIR_NAME


def config_dir() -> Path:
    """User configuration."""
    return _xdg_dir("XDG_CONFIG_HOME", Path.home() / ".config") / APP_DIR_NAME


def log_file() -> Path:
    """Application log file."""
    return state_dir() / "lume.log"


def audit_log_file() -> Path:
    """Audit log of operations that changed (or tried to change) the system."""
    return state_dir() / "operations.log"


def database_file() -> Path:
    """SQLite database with the diagnostic history."""
    return data_dir() / "lume.db"
