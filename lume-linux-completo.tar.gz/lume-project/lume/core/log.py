"""Logging setup.

Logs go to a file in the XDG state directory, never to the terminal, so they
do not interfere with the CLI output. Errors are logged, not hidden.
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from lume.core import paths

LOGGER_NAME = "lume"
_FORMAT = "%(asctime)s %(levelname)-8s %(name)s: %(message)s"


def get_logger(name: str | None = None) -> logging.Logger:
    """Return a logger below the ``lume`` namespace."""
    return logging.getLogger(f"{LOGGER_NAME}.{name}" if name else LOGGER_NAME)


def setup_logging(
    level: int = logging.INFO,
    log_path: Path | None = None,
) -> logging.Logger:
    """Configure the ``lume`` logger with a rotating file handler.

    Safe to call more than once: existing handlers are replaced. If the log file
    cannot be opened (read-only home, for example) LUME keeps working with a
    null handler instead of crashing.

    Args:
        level: Minimum level to record.
        log_path: Log file location. Defaults to :func:`lume.core.paths.log_file`.
    """
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(level)
    logger.propagate = False

    for old_handler in list(logger.handlers):
        logger.removeHandler(old_handler)
        old_handler.close()

    target = log_path or paths.log_file()
    handler: logging.Handler
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(target, maxBytes=512_000, backupCount=2, encoding="utf-8")
        handler.setFormatter(logging.Formatter(_FORMAT))
    except OSError:
        handler = logging.NullHandler()

    logger.addHandler(handler)
    return logger
