"""Structured report model, independent of how it is displayed.

A :class:`Report` holds the details (key/value blocks and tables) and the check
results of one analysis domain. The terminal, HTML, Markdown and JSON renderers
all consume the same model.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from lume.core.models import CheckResult


@dataclass(frozen=True, slots=True)
class KeyValues:
    """A titled list of ``key: value`` pairs."""

    title: str
    items: tuple[tuple[str, str], ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "type": "keyvalues",
            "title": self.title,
            "items": [{"key": k, "value": v} for k, v in self.items],
        }

    def map_text(self, fn: Callable[[str], str]) -> KeyValues:
        return KeyValues(self.title, tuple((k, fn(v)) for k, v in self.items))


@dataclass(frozen=True, slots=True)
class Table:
    """A titled table of strings."""

    title: str
    columns: tuple[str, ...]
    rows: tuple[tuple[str, ...], ...]

    def to_dict(self) -> dict[str, object]:
        return {
            "type": "table",
            "title": self.title,
            "columns": list(self.columns),
            "rows": [list(row) for row in self.rows],
        }

    def map_text(self, fn: Callable[[str], str]) -> Table:
        return Table(self.title, self.columns, tuple(tuple(fn(c) for c in r) for r in self.rows))


Section = KeyValues | Table


@dataclass(frozen=True, slots=True)
class Report:
    """Result of one analysis domain (system, hardware, network, ...).

    Attributes:
        id: Stable identifier of the domain.
        title: Human-readable title.
        sections: Detail blocks (inventory, measurements).
        checks: Check results.
        facts: Short facts reused in overviews (e.g. ``cpu``, ``kernel``).
    """

    id: str
    title: str
    sections: tuple[Section, ...] = ()
    checks: tuple[CheckResult, ...] = ()
    facts: tuple[tuple[str, str], ...] = field(default_factory=tuple)

    def fact(self, key: str, default: str = "") -> str:
        """Return the fact called ``key``."""
        return dict(self.facts).get(key, default)

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "title": self.title,
            "facts": dict(self.facts),
            "sections": [s.to_dict() for s in self.sections],
            "checks": [c.to_dict() for c in self.checks],
        }

    def map_text(self, fn: Callable[[str], str]) -> Report:
        """Return a copy with ``fn`` applied to every free-text value."""
        checks = tuple(
            CheckResult(
                c.name,
                c.status,
                fn(c.summary),
                tuple(fn(e) for e in c.evidence),
                c.check_id,
            )
            for c in self.checks
        )
        return Report(
            self.id,
            self.title,
            tuple(s.map_text(fn) for s in self.sections),
            checks,
            tuple((k, fn(v)) for k, v in self.facts),
        )
