"""Messages about optional system tools."""

from __future__ import annotations

# Generic package names; they are hints for humans, never executed.
_PACKAGE_HINTS: dict[str, str] = {
    "lspci": "pciutils",
    "lsusb": "usbutils",
    "ip": "iproute2, called iproute on Fedora",
    "ping": "iputils",
    "lscpu": "util-linux",
    "lsblk": "util-linux",
    "dpkg": "dpkg",
    "systemctl": "systemd",
}


def missing_message(tool: str) -> str:
    """Explain that ``tool`` is not installed and where it usually comes from."""
    package = _PACKAGE_HINTS.get(tool)
    if package:
        return f"{tool} is not installed (it is provided by: {package})"
    return f"{tool} is not installed"
