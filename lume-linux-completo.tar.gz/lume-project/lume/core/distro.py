"""Linux distribution detection and compatibility matching."""

from __future__ import annotations

import re
import shlex
from dataclasses import dataclass

from lume.core.environment import Environment

_SPEC_RE = re.compile(r"^(\*|[a-z0-9._-]+)(?:(>=|<=|=|>|<)(\d+(?:\.\d+)*))?$")

_FAMILIES: tuple[tuple[str, frozenset[str]], ...] = (
    ("debian", frozenset({"debian", "ubuntu"})),
    ("arch", frozenset({"arch"})),
    ("fedora", frozenset({"fedora", "rhel", "centos"})),
    ("suse", frozenset({"suse", "opensuse", "sles"})),
)


def _version_tuple(value: str) -> tuple[int, ...] | None:
    parts = value.split(".")
    if not parts or not all(p.isdigit() for p in parts):
        return None
    return tuple(int(p) for p in parts)


def is_valid_spec(spec: str) -> bool:
    """Whether ``spec`` is a valid compatibility expression (``ubuntu>=24.04``)."""
    return bool(_SPEC_RE.match(spec.strip().lower()))


@dataclass(frozen=True, slots=True)
class Distro:
    """Identity of the running distribution, from ``os-release``."""

    id: str = "linux"
    id_like: tuple[str, ...] = ()
    name: str = "Linux"
    version_id: str = ""
    version_codename: str = ""
    pretty_name: str = "Linux"

    @property
    def lineage(self) -> frozenset[str]:
        """The distribution id plus every id it declares to derive from."""
        return frozenset({self.id, *self.id_like})

    @property
    def family(self) -> str:
        """Package family: ``debian``, ``arch``, ``fedora``, ``suse`` or ``unknown``."""
        for family, members in _FAMILIES:
            if self.lineage & members:
                return family
        return "unknown"

    @property
    def is_ubuntu_based(self) -> bool:
        """Ubuntu itself or a derivative (Mint, Pop!_OS, Kubuntu...)."""
        return "ubuntu" in self.lineage

    def matches(self, spec: str) -> bool:
        """Check a compatibility expression.

        ``*`` matches everything. ``ubuntu`` matches Ubuntu and its derivatives.
        ``ubuntu>=24.04`` also constrains the version, which is only known for
        the distribution itself (a derivative has its own version numbers), so a
        derivative never matches a versioned expression.
        """
        match = _SPEC_RE.match(spec.strip().lower())
        if not match:
            return False
        name, operator, wanted = match.groups()
        if name == "*":
            return True
        if name not in self.lineage:
            return False
        if operator is None:
            return True
        if self.id != name:
            return False
        have_version, want_version = _version_tuple(self.version_id), _version_tuple(wanted)
        if have_version is None or want_version is None:
            return False
        return {
            ">=": have_version >= want_version,
            "<=": have_version <= want_version,
            ">": have_version > want_version,
            "<": have_version < want_version,
            "=": have_version == want_version,
        }[operator]

    def matches_any(self, specs: tuple[str, ...] | list[str]) -> bool:
        """Whether any of the expressions matches."""
        return any(self.matches(spec) for spec in specs)


def parse_os_release(text: str) -> Distro:
    """Parse the content of an ``os-release`` file."""
    values: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        try:
            parts = shlex.split(value)
        except ValueError:
            parts = [value.strip("\"'")]
        values[key.strip()] = parts[0] if parts else ""
    distro_id = values.get("ID", "linux").lower()
    name = values.get("NAME", "Linux")
    return Distro(
        id=distro_id,
        id_like=tuple(values.get("ID_LIKE", "").lower().split()),
        name=name,
        version_id=values.get("VERSION_ID", ""),
        version_codename=values.get("VERSION_CODENAME", values.get("UBUNTU_CODENAME", "")),
        pretty_name=values.get("PRETTY_NAME", name),
    )


def detect(env: Environment) -> Distro:
    """Detect the running distribution (``Distro()`` when it cannot be read)."""
    for path in ("/etc/os-release", "/usr/lib/os-release"):
        text = env.read_text(path)
        if text:
            return parse_os_release(text)
    return Distro()
