"""Safe execution of system commands.

LUME only runs a small set of **read-only** commands, with fixed arguments:

* no shell is ever used, commands are argument lists;
* the program must be a bare name from the allowlist (no paths);
* arguments must match the policy of that program;
* output is captured, size-limited, with a timeout and ``LC_ALL=C``;
* every execution is written to the audit log.

Command text coming from external files (such as the solutions database) is
never passed to this module.
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess  # nosec B404
import time
from collections.abc import Sequence
from dataclasses import dataclass

from lume.core import audit
from lume.core.exceptions import CommandTimeoutError, SafetyError, ToolUnavailableError

MAX_OUTPUT_BYTES = 2_000_000
DEFAULT_TIMEOUT = 10.0

_LSBLK_COLUMNS = frozenset(
    {"NAME", "TYPE", "SIZE", "MODEL", "ROTA", "RM", "TRAN", "FSTYPE", "MOUNTPOINT", "PKNAME"}
)
_UNIT_RE = re.compile(r"[A-Za-z0-9@_.-]{1,80}\.service")
_IPV4_RE = re.compile(r"(?:\d{1,3}\.){3}\d{1,3}")

# Tools whose complete argument list is fixed.
_FIXED: dict[str, frozenset[tuple[str, ...]]] = {
    "lscpu": frozenset({()}),
    "lsusb": frozenset({()}),
    "lspci": frozenset({("-nnk",)}),
    "free": frozenset({(), ("-b",)}),
    "ip": frozenset(
        {("-j", "addr", "show"), ("-j", "route", "show"), ("-j", "-6", "route", "show")}
    ),
    "dpkg": frozenset({("--audit",)}),
    "dmesg": frozenset({("--level=err,crit,alert,emerg",)}),
    "journalctl": frozenset({("-k", "-b", "-p", "err", "--no-pager", "-q", "-n", "200")}),
    "resolvectl": frozenset({("dns",)}),
    "systemctl": frozenset(
        {("is-system-running",), ("--failed", "--no-legend", "--plain", "--no-pager")}
    ),
}


@dataclass(frozen=True, slots=True)
class CommandResult:
    """Outcome of a finished command."""

    argv: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        """Whether the command exited with status 0."""
        return self.returncode == 0


def validate_command(argv: Sequence[str]) -> None:
    """Raise :class:`SafetyError` unless ``argv`` is an allowed read-only command."""
    if not argv:
        raise SafetyError("empty command")
    program, args = argv[0], tuple(argv[1:])
    if "/" in program or program != program.strip():
        raise SafetyError(f"programs must be bare names from the allowlist: {program!r}")
    if any("\n" in a or "\x00" in a for a in args):
        raise SafetyError("control characters are not allowed in arguments")

    if args in _FIXED.get(program, frozenset()):
        return
    if (
        program == "lsblk"
        and len(args) == 4
        and args[:3] == ("-J", "-b", "-o")
        and set(args[3].split(",")) <= _LSBLK_COLUMNS
    ):
        return
    if (
        program == "systemctl"
        and len(args) == 4
        and args[:3] == ("show", "--no-pager", "--property=LoadState,ActiveState,SubState")
        and _UNIT_RE.fullmatch(args[3])
    ):
        return
    if (
        program == "ping"
        and len(args) == 5
        and args[:4] == ("-c", "1", "-W", "2")
        and _IPV4_RE.fullmatch(args[4])
        and all(int(part) <= 255 for part in args[4].split("."))
    ):
        return
    raise SafetyError(f"command not allowed by LUME's read-only policy: {' '.join(argv)}")


def run_command(argv: Sequence[str], *, timeout: float = DEFAULT_TIMEOUT) -> CommandResult:
    """Run an allowed read-only command and return its result.

    Raises:
        SafetyError: the command is not allowed.
        ToolUnavailableError: the program is not installed.
        CommandTimeoutError: the command exceeded ``timeout`` seconds.
    """
    validate_command(argv)
    command = tuple(argv)
    if shutil.which(command[0]) is None:
        raise ToolUnavailableError(command[0])

    env = {"LC_ALL": "C", "LANG": "C", "PATH": os.environ.get("PATH", "/usr/bin:/bin")}
    started = time.monotonic()
    try:
        # Safe by construction: argv was validated against the allowlist, and no shell is used.
        completed = subprocess.run(  # nosec B603
            command,
            capture_output=True,
            timeout=timeout,
            env=env,
            stdin=subprocess.DEVNULL,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        audit.record("command", argv=list(command), result="timeout")
        raise CommandTimeoutError(command, timeout) from exc
    except OSError as exc:
        audit.record("command", argv=list(command), result="unavailable", error=str(exc))
        raise ToolUnavailableError(command[0]) from exc

    result = CommandResult(
        command,
        completed.returncode,
        completed.stdout[:MAX_OUTPUT_BYTES].decode("utf-8", errors="replace"),
        completed.stderr[:MAX_OUTPUT_BYTES].decode("utf-8", errors="replace"),
    )
    audit.record(
        "command",
        argv=list(command),
        returncode=result.returncode,
        seconds=round(time.monotonic() - started, 3),
    )
    return result
