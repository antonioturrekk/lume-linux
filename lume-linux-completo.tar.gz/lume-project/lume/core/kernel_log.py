"""Kernel log access and classification of known problem patterns.

Reading the kernel log usually requires permissions (``kernel.dmesg_restrict``).
LUME never escalates privileges: when the log is not readable the checks that
depend on it are reported as skipped, with the command the user can run.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from lume.core.environment import Environment
from lume.core.exceptions import CommandTimeoutError, LumeError, ToolUnavailableError

STORAGE_RE = re.compile(
    r"(I/O error|EXT4-fs error|XFS .*(error|corruption)|BTRFS (error|critical)|"
    r"Buffer I/O error|blk_update_request|ata\d+(\.\d+)?: .*(failed command|exception)|"
    r"nvme\d+.*(timeout|I/O error)|Remounting filesystem read-only|critical medium error)",
    re.IGNORECASE,
)
OOM_RE = re.compile(r"(Out of memory|oom-kill|oom_reaper|Killed process \d+)", re.IGNORECASE)
HARDWARE_RE = re.compile(
    r"(Machine check|mce: .*Hardware Error|Hardware Error|Core temperature above threshold|"
    r"Package temperature above threshold|thermal throttling|PCIe Bus Error)",
    re.IGNORECASE,
)

HOW_TO_READ = "sudo dmesg --level=err,crit,alert,emerg"


@dataclass(frozen=True, slots=True)
class KernelLog:
    """Error-level kernel messages of the current boot, or why they are unavailable."""

    lines: tuple[str, ...] = ()
    unavailable_reason: str | None = None

    @property
    def available(self) -> bool:
        """Whether the log could be read."""
        return self.unavailable_reason is None

    def matching(self, pattern: re.Pattern[str]) -> list[str]:
        """Lines matching ``pattern``."""
        return [line for line in self.lines if pattern.search(line)]


def read_kernel_log(env: Environment) -> KernelLog:
    """Read error-level kernel messages without elevating privileges."""
    attempts = (
        ("dmesg", ["dmesg", "--level=err,crit,alert,emerg"]),
        ("journalctl", ["journalctl", "-k", "-b", "-p", "err", "--no-pager", "-q", "-n", "200"]),
    )
    denied = False
    for _name, argv in attempts:
        try:
            result = env.run(argv, timeout=10)
        except (ToolUnavailableError, CommandTimeoutError):
            continue
        except LumeError:
            continue
        if result.ok and result.stdout.strip():
            return KernelLog(tuple(result.stdout.splitlines()))
        if result.ok:
            return KernelLog(())
        denied = True
    if denied:
        return KernelLog(
            unavailable_reason=(
                "kernel log is not readable without elevated permissions "
                f"(you can inspect it yourself with: {HOW_TO_READ})"
            )
        )
    return KernelLog(unavailable_reason="neither dmesg nor journalctl is available")
