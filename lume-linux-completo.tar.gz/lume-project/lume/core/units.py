"""Human-friendly formatting helpers."""

from __future__ import annotations

_UNITS = ("B", "KiB", "MiB", "GiB", "TiB", "PiB")


def format_bytes(value: float) -> str:
    """Format a byte count using binary units (``1.5 GiB``)."""
    size = float(value)
    for unit in _UNITS:
        if abs(size) < 1024 or unit == _UNITS[-1]:
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} {_UNITS[-1]}"  # pragma: no cover


def format_percent(value: float) -> str:
    """Format a percentage with no decimals."""
    return f"{value:.0f}%"


def format_duration(seconds: float) -> str:
    """Format a duration such as ``3 d 4 h`` or ``12 min``."""
    total = int(seconds)
    days, rest = divmod(total, 86400)
    hours, rest = divmod(rest, 3600)
    minutes = rest // 60
    if days:
        return f"{days} d {hours} h"
    if hours:
        return f"{hours} h {minutes} min"
    return f"{minutes} min"


def plural(count: int, word: str) -> str:
    """``1 core`` / ``2 cores``."""
    return f"{count} {word}{'' if count == 1 else 's'}"
