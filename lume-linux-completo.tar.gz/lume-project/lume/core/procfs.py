"""Parsers for ``/proc`` files shared by several analyzers."""

from __future__ import annotations

from dataclasses import dataclass


def parse_meminfo(text: str) -> dict[str, int]:
    """Parse ``/proc/meminfo`` into ``{key: bytes}`` (values are in kB there)."""
    result: dict[str, int] = {}
    for line in text.splitlines():
        key, _, rest = line.partition(":")
        parts = rest.split()
        if not parts or not parts[0].isdigit():
            continue
        multiplier = 1024 if len(parts) > 1 and parts[1].lower() == "kb" else 1
        result[key.strip()] = int(parts[0]) * multiplier
    return result


@dataclass(frozen=True, slots=True)
class LoadAverage:
    """The three load averages of ``/proc/loadavg``."""

    one: float
    five: float
    fifteen: float


def parse_loadavg(text: str) -> LoadAverage | None:
    """Parse ``/proc/loadavg``."""
    parts = text.split()
    try:
        return LoadAverage(float(parts[0]), float(parts[1]), float(parts[2]))
    except (IndexError, ValueError):
        return None


@dataclass(frozen=True, slots=True)
class CpuTimes:
    """Aggregated CPU time counters from ``/proc/stat`` (in clock ticks)."""

    total: int
    idle: int
    cpu_count: int


def parse_stat(text: str) -> CpuTimes | None:
    """Parse the aggregated ``cpu`` line and count the ``cpuN`` lines."""
    total_line: list[str] | None = None
    cpus = 0
    for line in text.splitlines():
        fields = line.split()
        if not fields:
            continue
        if fields[0] == "cpu":
            total_line = fields[1:]
        elif fields[0].startswith("cpu") and fields[0][3:].isdigit():
            cpus += 1
    if total_line is None or len(total_line) < 5:
        return None
    try:
        values = [int(v) for v in total_line[:8]]
    except ValueError:
        return None
    idle = values[3] + values[4]  # idle + iowait
    return CpuTimes(total=sum(values), idle=idle, cpu_count=max(cpus, 1))


def parse_uptime(text: str) -> float | None:
    """Parse ``/proc/uptime`` into seconds."""
    try:
        return float(text.split()[0])
    except (IndexError, ValueError):
        return None
