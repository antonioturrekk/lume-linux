"""Audit log of the operations LUME performs.

Every external command LUME runs is recorded (when, what, result) in
``operations.log`` inside the XDG state directory, as JSON lines. LUME is
read-only, so this log lets users verify exactly what was executed.
Writing the log is best-effort: failures never interrupt a diagnosis.
"""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime

from lume.core import paths

MAX_BYTES = 1_000_000


def record(action: str, **fields: object) -> None:
    """Append one event to the audit log."""
    event = {"time": datetime.now(UTC).isoformat(timespec="seconds"), "action": action, **fields}
    try:
        target = paths.audit_log_file()
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists() and target.stat().st_size > MAX_BYTES:
            os.replace(target, target.with_suffix(".log.1"))
        with target.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, ensure_ascii=False) + "\n")
    except OSError:
        return
