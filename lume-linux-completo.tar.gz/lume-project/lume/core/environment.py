"""Access to the running system, behind one interface.

Every analyzer reads files and runs commands **only** through an
:class:`Environment`. :class:`SystemEnvironment` talks to the real machine; the
tests use a fake one fed with captured command output, so parsers and rules can
be verified without depending on the machine running the tests.
"""

from __future__ import annotations

import fcntl
import ipaddress
import os
import platform
import socket
import struct
import threading
import time
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Protocol

from lume.core.runner import CommandResult, run_command

_MAX_READ = 4_000_000
_SIOCGIFADDR = 0x8915
_SIOCGIFNETMASK = 0x891B


@dataclass(frozen=True, slots=True)
class DiskUsage:
    """Space and inode usage of a mounted filesystem (same math as ``df``)."""

    total: int
    used: int
    available: int
    inodes_total: int
    inodes_free: int

    @property
    def percent_used(self) -> float:
        """Used share of the space usable by regular users, like ``df``."""
        denominator = self.used + self.available
        return 100.0 * self.used / denominator if denominator else 0.0

    @property
    def inodes_percent_used(self) -> float:
        """Used share of the inodes (0 when the filesystem has no inode limit)."""
        if not self.inodes_total:
            return 0.0
        return 100.0 * (self.inodes_total - self.inodes_free) / self.inodes_total


class Environment(Protocol):
    """Everything analyzers need from the machine."""

    def read_text(self, path: str) -> str | None:
        """Return the text of a file, or ``None`` if missing or unreadable."""

    def listdir(self, path: str) -> list[str]:
        """Return the sorted entries of a directory (empty if missing)."""

    def exists(self, path: str) -> bool:
        """Whether a path exists."""

    def run(self, argv: Sequence[str], *, timeout: float = 10.0) -> CommandResult:
        """Run an allowed read-only command (see :mod:`lume.core.runner`)."""

    def disk_usage(self, path: str) -> DiskUsage | None:
        """Usage of the filesystem mounted at ``path``."""

    def sleep(self, seconds: float) -> None:
        """Wait (used between two samples)."""

    def geteuid(self) -> int:
        """Effective user id of the process."""

    def machine(self) -> str:
        """CPU architecture (``x86_64``...)."""

    def page_size(self) -> int:
        """Memory page size in bytes."""

    def now(self) -> datetime:
        """Current time (timezone-aware UTC)."""

    def interface_ipv4(self, name: str) -> tuple[str, int] | None:
        """IPv4 address and prefix length of an interface, if any."""

    def resolve_host(self, host: str, timeout: float) -> list[str]:
        """Resolve a name using the system resolver (raises ``OSError``)."""

    def tcp_connect(self, host: str, port: int, timeout: float) -> float:
        """Open a TCP connection and return the latency in ms (raises ``OSError``)."""


class SystemEnvironment:
    """The real machine."""

    def read_text(self, path: str) -> str | None:
        try:
            with open(path, encoding="utf-8", errors="replace") as handle:
                return handle.read(_MAX_READ)
        except OSError:
            return None

    def listdir(self, path: str) -> list[str]:
        try:
            return sorted(os.listdir(path))
        except OSError:
            return []

    def exists(self, path: str) -> bool:
        return os.path.exists(path)

    def run(self, argv: Sequence[str], *, timeout: float = 10.0) -> CommandResult:
        return run_command(argv, timeout=timeout)

    def disk_usage(self, path: str) -> DiskUsage | None:
        try:
            stat = os.statvfs(path)
        except OSError:
            return None
        frsize = stat.f_frsize or stat.f_bsize
        return DiskUsage(
            total=stat.f_blocks * frsize,
            used=(stat.f_blocks - stat.f_bfree) * frsize,
            available=stat.f_bavail * frsize,
            inodes_total=stat.f_files,
            inodes_free=stat.f_ffree,
        )

    def sleep(self, seconds: float) -> None:
        time.sleep(seconds)

    def geteuid(self) -> int:
        return os.geteuid()

    def machine(self) -> str:
        return platform.machine()

    def page_size(self) -> int:
        return os.sysconf("SC_PAGE_SIZE")

    def now(self) -> datetime:
        return datetime.now(UTC)

    def interface_ipv4(self, name: str) -> tuple[str, int] | None:
        packed = struct.pack("256s", name.encode()[:15])
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                address = socket.inet_ntoa(fcntl.ioctl(sock.fileno(), _SIOCGIFADDR, packed)[20:24])
                mask = socket.inet_ntoa(fcntl.ioctl(sock.fileno(), _SIOCGIFNETMASK, packed)[20:24])
        except OSError:
            return None
        return address, ipaddress.IPv4Network(f"0.0.0.0/{mask}").prefixlen

    def resolve_host(self, host: str, timeout: float) -> list[str]:
        outcome: dict[str, object] = {}

        def work() -> None:
            try:
                infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
                outcome["addresses"] = sorted({str(info[4][0]) for info in infos})
            except Exception as exc:  # never lose a failure inside the helper thread
                outcome["error"] = exc

        thread = threading.Thread(target=work, daemon=True)
        thread.start()
        thread.join(timeout)
        if thread.is_alive():
            raise TimeoutError(f"name resolution timed out after {timeout:g}s")
        error = outcome.get("error")
        if isinstance(error, OSError):
            raise error
        if isinstance(error, BaseException):
            raise OSError(f"name resolution failed: {error}") from error
        addresses = outcome.get("addresses")
        return list(addresses) if isinstance(addresses, list) else []

    def tcp_connect(self, host: str, port: int, timeout: float) -> float:
        started = time.perf_counter()
        with socket.create_connection((host, port), timeout=timeout):
            return (time.perf_counter() - started) * 1000
