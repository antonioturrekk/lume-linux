"""Exception hierarchy for LUME.

Every error raised on purpose by LUME inherits from :class:`LumeError`, so the
CLI can tell expected failures apart from real bugs.
"""


class LumeError(Exception):
    """Base class for all LUME errors."""


class ToolUnavailableError(LumeError):
    """A system tool (e.g. ``lspci``) is not installed or not executable."""

    def __init__(self, tool: str) -> None:
        super().__init__(f"required tool not available: {tool}")
        self.tool = tool


class CommandTimeoutError(LumeError):
    """A system command did not finish in time."""

    def __init__(self, argv: tuple[str, ...], timeout: float) -> None:
        super().__init__(f"command timed out after {timeout:g}s: {' '.join(argv)}")
        self.argv = argv


class UnsupportedPlatformError(LumeError):
    """The running system is not supported for the requested operation."""


class SafetyError(LumeError):
    """An operation was blocked by LUME's safety rules."""
