"""Shared foundation: result model, exceptions, paths, logging and system access."""

from lume.core.exceptions import (
    CommandTimeoutError,
    LumeError,
    SafetyError,
    ToolUnavailableError,
    UnsupportedPlatformError,
)
from lume.core.models import CheckResult, Status, error, ok, skip, summarize, warn

__all__ = [
    "CheckResult",
    "CommandTimeoutError",
    "LumeError",
    "SafetyError",
    "Status",
    "ToolUnavailableError",
    "UnsupportedPlatformError",
    "error",
    "ok",
    "skip",
    "summarize",
    "warn",
]
