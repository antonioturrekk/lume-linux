"""Allow ``python -m lume``."""

from lume.cli.main import entrypoint

if __name__ == "__main__":
    entrypoint()
