"""PCI devices (``lspci -nnk``)."""

from __future__ import annotations

import re
from dataclasses import dataclass

_HEADER_RE = re.compile(
    r"^(?P<slot>(?:[0-9a-f]{4}:)?[0-9a-f]{2}:[0-9a-f]{2}\.[0-7])\s+"
    r"(?P<cls>.+?)\s+\[(?P<classid>[0-9a-f]{4})\]:\s+"
    r"(?P<name>.+?)\s+\[(?P<vid>[0-9a-f]{4}):(?P<did>[0-9a-f]{4})\]"
    r"(?:\s+\(rev\s+[0-9a-f]+\))?$",
    re.IGNORECASE,
)
GPU_CLASSES = frozenset({"0300", "0302", "0380"})  # VGA, 3D, display controllers


@dataclass(frozen=True, slots=True)
class PciDevice:
    """One PCI device."""

    slot: str
    class_name: str
    class_id: str
    name: str
    vendor_id: str
    device_id: str
    driver: str | None = None
    modules: tuple[str, ...] = ()

    @property
    def is_gpu(self) -> bool:
        return self.class_id in GPU_CLASSES

    @property
    def ids(self) -> str:
        return f"{self.vendor_id}:{self.device_id}"


def parse_lspci(text: str) -> list[PciDevice]:
    """Parse ``lspci -nnk`` output (device headers followed by indented details)."""
    devices: list[PciDevice] = []
    header: re.Match[str] | None = None
    driver: str | None = None
    modules: tuple[str, ...] = ()

    def flush() -> None:
        if header is not None:
            devices.append(
                PciDevice(
                    slot=header["slot"],
                    class_name=header["cls"],
                    class_id=header["classid"].lower(),
                    name=header["name"],
                    vendor_id=header["vid"].lower(),
                    device_id=header["did"].lower(),
                    driver=driver,
                    modules=modules,
                )
            )

    for line in text.splitlines():
        if not line.strip():
            continue
        if line[0] not in " \t":
            flush()
            header, driver, modules = _HEADER_RE.match(line.strip()), None, ()
            continue
        if header is None:
            continue
        key, _, value = line.strip().partition(":")
        if key == "Kernel driver in use":
            driver = value.strip()
        elif key == "Kernel modules":
            modules = tuple(m.strip() for m in value.split(",") if m.strip())
    flush()
    return devices
