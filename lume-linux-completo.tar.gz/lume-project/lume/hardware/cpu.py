"""Processor identification."""

from __future__ import annotations

from dataclasses import dataclass

from lume.core.environment import Environment
from lume.core.exceptions import LumeError


@dataclass(frozen=True, slots=True)
class CpuInfo:
    """Processor facts. ``None`` means the system did not report the value."""

    model: str
    vendor: str = ""
    architecture: str = ""
    logical: int | None = None  # threads
    cores: int | None = None
    sockets: int | None = None
    max_mhz: float | None = None
    hypervisor: str | None = None
    virtualization: str | None = None


def _to_int(value: str | None) -> int | None:
    if value is None:
        return None
    text = value.strip()
    return int(text) if text.isdigit() else None


def parse_lscpu(text: str) -> CpuInfo | None:
    """Parse the output of ``lscpu``."""
    values: dict[str, str] = {}
    for line in text.splitlines():
        key, sep, value = line.partition(":")
        if sep:
            values.setdefault(key.strip(), value.strip())
    model = values.get("Model name", "")
    if not model:
        return None
    per_socket = _to_int(values.get("Core(s) per socket"))
    sockets = _to_int(values.get("Socket(s)")) or (1 if per_socket else None)
    max_mhz: float | None
    try:
        max_mhz = float(values["CPU max MHz"])
    except (KeyError, ValueError):
        max_mhz = None
    return CpuInfo(
        model=" ".join(model.split()),
        vendor=values.get("Vendor ID", ""),
        architecture=values.get("Architecture", ""),
        logical=_to_int(values.get("CPU(s)")),
        cores=per_socket * sockets if per_socket and sockets else None,
        sockets=sockets,
        max_mhz=max_mhz,
        hypervisor=values.get("Hypervisor vendor"),
        virtualization=values.get("Virtualization"),
    )


def parse_cpuinfo(text: str, architecture: str = "") -> CpuInfo | None:
    """Parse ``/proc/cpuinfo`` (fallback when ``lscpu`` is unavailable)."""
    logical = 0
    model = ""
    vendor = ""
    cores: int | None = None
    physical_ids: set[str] = set()
    for line in text.splitlines():
        key, sep, value = line.partition(":")
        if not sep:
            continue
        key, value = key.strip(), value.strip()
        if key == "processor" and value.isdigit():
            logical += 1
        elif key == "model name" and not model:
            model = value
        elif key == "vendor_id" and not vendor:
            vendor = value
        elif key == "cpu cores" and cores is None:
            cores = _to_int(value)
        elif key == "physical id":
            physical_ids.add(value)
    if not model:
        # ARM boards expose the SoC as "Hardware" and the board as "Model".
        board: dict[str, str] = {}
        for line in text.splitlines():
            key, _, value = line.partition(":")
            if key.strip() in {"Model", "Hardware"} and value.strip():
                board.setdefault(key.strip(), value.strip())
        soc, name = board.get("Hardware", ""), board.get("Model", "")
        model = f"{soc} ({name})" if soc and name else soc or name
    if not model or not logical:
        return None
    sockets = len(physical_ids) or None
    return CpuInfo(
        model=" ".join(model.split()),
        vendor=vendor,
        architecture=architecture,
        logical=logical,
        cores=cores * (sockets or 1) if cores else None,
        sockets=sockets,
    )


def read_cpu(env: Environment) -> CpuInfo | None:
    """Identify the processor with ``lscpu``, falling back to ``/proc/cpuinfo``."""
    try:
        completed = env.run(["lscpu"])
        if completed.ok:
            parsed = parse_lscpu(completed.stdout)
            if parsed:
                return parsed
    except LumeError:
        pass
    return parse_cpuinfo(env.read_text("/proc/cpuinfo") or "", env.machine())
