"""USB devices (``lsusb``)."""

from __future__ import annotations

import re
from dataclasses import dataclass

_LINE_RE = re.compile(
    r"^Bus (?P<bus>\d+) Device (?P<dev>\d+): "
    r"ID (?P<vid>[0-9a-f]{4}):(?P<pid>[0-9a-f]{4})\s*(?P<desc>.*)$",
    re.IGNORECASE,
)
LINUX_FOUNDATION = "1d6b"


@dataclass(frozen=True, slots=True)
class UsbDevice:
    """One USB device."""

    bus: str
    device: str
    vendor_id: str
    product_id: str
    description: str

    @property
    def is_root_hub(self) -> bool:
        return self.vendor_id == LINUX_FOUNDATION

    @property
    def ids(self) -> str:
        return f"{self.vendor_id}:{self.product_id}"


def parse_lsusb(text: str) -> list[UsbDevice]:
    """Parse ``lsusb`` output."""
    devices: list[UsbDevice] = []
    for line in text.splitlines():
        match = _LINE_RE.match(line.strip())
        if match:
            devices.append(
                UsbDevice(
                    match["bus"],
                    match["dev"],
                    match["vid"].lower(),
                    match["pid"].lower(),
                    match["desc"].strip() or "(no description)",
                )
            )
    return devices
