"""Block devices (``lsblk -J``)."""

from __future__ import annotations

import json
from dataclasses import dataclass

LSBLK_COLUMNS = "NAME,TYPE,SIZE,MODEL,ROTA,RM,TRAN,FSTYPE,MOUNTPOINT"


@dataclass(frozen=True, slots=True)
class BlockDevice:
    """A disk, partition or other block device."""

    name: str
    type: str
    size: int
    model: str = ""
    rotational: bool | None = None
    removable: bool = False
    transport: str = ""
    fstype: str = ""
    mountpoint: str = ""
    parent: str = ""

    @property
    def kind(self) -> str:
        """Human-friendly kind of device."""
        if self.type != "disk":
            return self.type
        if self.removable or self.transport == "usb":
            return "USB / removable"
        if self.name.startswith("nvme") or self.transport == "nvme":
            return "NVMe SSD"
        if self.transport == "virtio":
            return "Virtual disk"
        if self.rotational is False:
            return "SSD"
        if self.rotational is True:
            return "HDD"
        return "Disk"


def _bool(value: object) -> bool | None:
    if isinstance(value, bool):
        return value
    if value in (1, "1"):
        return True
    if value in (0, "0"):
        return False
    return None


def _int(value: object) -> int:
    if isinstance(value, bool):
        return 0
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().isdigit():
        return int(value)
    return 0


def _text(value: object) -> str:
    return value.strip() if isinstance(value, str) else ""


def _walk(nodes: object, parent: str, out: list[BlockDevice]) -> None:
    if not isinstance(nodes, list):
        return
    for node in nodes:
        if not isinstance(node, dict):
            continue
        name = _text(node.get("name"))
        if not name:
            continue
        out.append(
            BlockDevice(
                name=name,
                type=_text(node.get("type")),
                size=_int(node.get("size")),
                model=_text(node.get("model")),
                rotational=_bool(node.get("rota")),
                removable=bool(_bool(node.get("rm"))),
                transport=_text(node.get("tran")),
                fstype=_text(node.get("fstype")),
                mountpoint=_text(node.get("mountpoint")),
                parent=parent,
            )
        )
        _walk(node.get("children"), name, out)


def parse_lsblk(text: str) -> list[BlockDevice] | None:
    """Parse ``lsblk -J`` output into a flat list (``None`` if it is not valid)."""
    try:
        data = json.loads(text)
    except ValueError:
        return None
    if not isinstance(data, dict) or not isinstance(data.get("blockdevices"), list):
        return None
    devices: list[BlockDevice] = []
    _walk(data["blockdevices"], "", devices)
    return devices


def real_devices(devices: list[BlockDevice]) -> list[BlockDevice]:
    """Hide loop devices and empty devices (such as an unused ``zram``)."""
    return [d for d in devices if d.type != "loop" and d.size > 0]
