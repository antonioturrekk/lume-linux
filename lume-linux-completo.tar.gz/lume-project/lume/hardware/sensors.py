"""Temperature sensors, read from the same ``/sys`` interfaces ``sensors`` uses."""

from __future__ import annotations

import re
from dataclasses import dataclass

from lume.core.environment import Environment

_TEMP_INPUT_RE = re.compile(r"^temp(\d+)_input$")
MIN_VALID, MAX_VALID = 1.0, 150.0  # discards bogus readings (0, -273, 255...)


@dataclass(frozen=True, slots=True)
class Temperature:
    """A temperature reading in degrees Celsius."""

    sensor: str
    label: str
    celsius: float
    high: float | None = None
    critical: float | None = None


def _millidegrees(env: Environment, path: str) -> float | None:
    text = (env.read_text(path) or "").strip()
    try:
        return int(text) / 1000
    except ValueError:
        return None


def read_temperatures(env: Environment) -> list[Temperature]:
    """Read every available sensor (``hwmon`` and ``thermal_zone``)."""
    readings: list[Temperature] = []
    for hwmon in env.listdir("/sys/class/hwmon"):
        base = f"/sys/class/hwmon/{hwmon}"
        sensor = (env.read_text(f"{base}/name") or hwmon).strip()
        for entry in env.listdir(base):
            match = _TEMP_INPUT_RE.match(entry)
            if not match:
                continue
            index = match.group(1)
            value = _millidegrees(env, f"{base}/{entry}")
            if value is None or not MIN_VALID <= value <= MAX_VALID:
                continue
            label = (env.read_text(f"{base}/temp{index}_label") or f"temp{index}").strip()
            readings.append(
                Temperature(
                    sensor,
                    label,
                    value,
                    _millidegrees(env, f"{base}/temp{index}_max"),
                    _millidegrees(env, f"{base}/temp{index}_crit"),
                )
            )
    for zone in env.listdir("/sys/class/thermal"):
        if not zone.startswith("thermal_zone"):
            continue
        base = f"/sys/class/thermal/{zone}"
        value = _millidegrees(env, f"{base}/temp")
        if value is None or not MIN_VALID <= value <= MAX_VALID:
            continue
        kind = (env.read_text(f"{base}/type") or zone).strip()
        readings.append(Temperature("thermal", kind, value))
    return readings
