"""Read-only hardware discovery: CPU, RAM, GPU, PCI, USB, disks, sensors."""

from __future__ import annotations

from lume.core import CheckResult, error, ok, skip, warn
from lume.core.environment import Environment
from lume.core.exceptions import LumeError, ToolUnavailableError
from lume.core.kernel_log import HARDWARE_RE, KernelLog, read_kernel_log
from lume.core.procfs import parse_meminfo
from lume.core.report import KeyValues, Report, Section, Table
from lume.core.tools import missing_message
from lume.core.units import format_bytes, plural
from lume.hardware.cpu import CpuInfo, read_cpu
from lume.hardware.disks import (
    LSBLK_COLUMNS,
    BlockDevice,
    parse_lsblk,
    real_devices,
)
from lume.hardware.pci import PciDevice, parse_lspci
from lume.hardware.sensors import Temperature, read_temperatures
from lume.hardware.usb import UsbDevice, parse_lsusb
from lume.network.interfaces import list_interfaces

GENERIC_GPU_DRIVERS = frozenset({"vesafb", "simplefb", "efifb", "vga16fb", "uvesafb"})
TEMP_WARN, TEMP_ERROR = 90.0, 100.0

__all__ = ["analyze"]


def _cpu_section_and_check(cpu: CpuInfo | None) -> tuple[Section | None, CheckResult]:
    if cpu is None:
        return None, skip("hardware.cpu", "Processor", "could not identify the processor")
    items = [("Model", cpu.model)]
    if cpu.vendor:
        items.append(("Vendor", cpu.vendor))
    if cpu.architecture:
        items.append(("Architecture", cpu.architecture))
    if cpu.cores:
        items.append(("Cores", str(cpu.cores)))
    if cpu.logical:
        items.append(("Threads", str(cpu.logical)))
    if cpu.max_mhz:
        items.append(("Max frequency", f"{cpu.max_mhz / 1000:.2f} GHz"))
    if cpu.hypervisor:
        items.append(("Hypervisor", cpu.hypervisor))
    elif cpu.virtualization:
        items.append(("Virtualization support", cpu.virtualization))
    cores, threads = cpu.cores, cpu.logical
    if cores and threads:
        detail = f"{plural(cores, 'core')} / {plural(threads, 'thread')}"
    elif threads:
        detail = plural(threads, "thread")
    else:
        detail = "core count not reported"
    return KeyValues("Processor", tuple(items)), ok(
        "hardware.cpu", "Processor", f"{cpu.model} ({detail})"
    )


def _memory_section_and_check(env: Environment) -> tuple[Section | None, CheckResult, str]:
    text = env.read_text("/proc/meminfo")
    info = parse_meminfo(text) if text else {}
    total = info.get("MemTotal")
    if not total:
        return None, skip("hardware.memory", "Memory", "/proc/meminfo is not readable"), ""
    items = [("Total", format_bytes(total))]
    if "MemAvailable" in info:
        items.append(("Available now", format_bytes(info["MemAvailable"])))
    swap = info.get("SwapTotal", 0)
    items.append(("Swap", format_bytes(swap) if swap else "none configured"))
    summary = f"{format_bytes(total)} of RAM detected"
    return (
        KeyValues("Memory", tuple(items)),
        ok("hardware.memory", "Memory", summary),
        format_bytes(total),
    )


def _gpu_check(gpus: list[PciDevice]) -> CheckResult:
    if not gpus:
        return skip("hardware.gpu", "Graphics driver", "no graphics adapter reported by lspci")
    problems: list[str] = []
    described: list[str] = []
    for gpu in gpus:
        label = f"{gpu.name} [{gpu.ids}]"
        if gpu.driver is None:
            extra = f" (available modules: {', '.join(gpu.modules)})" if gpu.modules else ""
            problems.append(f"{label}: no kernel driver in use{extra}")
        elif gpu.driver in GENERIC_GPU_DRIVERS:
            problems.append(f"{label}: generic framebuffer driver '{gpu.driver}' in use")
        described.append(f"{gpu.name} ({gpu.driver or 'no driver'})")
    if problems:
        return warn(
            "hardware.gpu",
            "Graphics driver",
            "a graphics adapter is not using a dedicated driver",
            problems,
        )
    return ok("hardware.gpu", "Graphics driver", "; ".join(described))


def _temperature_check(temps: list[Temperature]) -> CheckResult:
    if not temps:
        return skip(
            "hardware.temperature",
            "Temperatures",
            "this system exposes no temperature sensors (common in virtual machines)",
        )
    errors: list[str] = []
    warnings: list[str] = []
    for t in temps:
        text = f"{t.sensor}/{t.label}: {t.celsius:.0f} °C"
        if t.critical and t.celsius >= t.critical:
            errors.append(f"{text} (critical limit {t.critical:.0f} °C)")
        elif t.high and t.celsius >= t.high:
            warnings.append(f"{text} (high limit {t.high:.0f} °C)")
        elif t.high is None and t.critical is None:
            if t.celsius >= TEMP_ERROR:
                errors.append(f"{text} (above {TEMP_ERROR:.0f} °C)")
            elif t.celsius >= TEMP_WARN:
                warnings.append(f"{text} (above {TEMP_WARN:.0f} °C)")
    if errors:
        return error(
            "hardware.temperature",
            "Temperatures",
            "a sensor reached its critical limit",
            errors + warnings,
        )
    if warnings:
        return warn("hardware.temperature", "Temperatures", "a component is running hot", warnings)
    hottest = max(temps, key=lambda t: t.celsius)
    return ok(
        "hardware.temperature",
        "Temperatures",
        f"{len(temps)} sensors, hottest {hottest.sensor}/{hottest.label} "
        f"at {hottest.celsius:.0f} °C",
    )


def _machine_check(kernel_log: KernelLog) -> CheckResult:
    if not kernel_log.available:
        return skip(
            "hardware.errors", "Hardware errors", kernel_log.unavailable_reason or "unavailable"
        )
    lines = kernel_log.matching(HARDWARE_RE)
    if lines:
        return warn(
            "hardware.errors",
            "Hardware errors",
            f"{len(lines)} hardware-related message(s) in the kernel log",
            lines[:3],
        )
    return ok("hardware.errors", "Hardware errors", "no hardware error messages in the kernel log")


def analyze(env: Environment, *, kernel_log: KernelLog | None = None) -> Report:
    """Identify the hardware of the machine (read-only)."""
    sections: list[Section] = []
    checks: list[CheckResult] = []
    facts: list[tuple[str, str]] = []

    cpu = read_cpu(env)
    cpu_section, cpu_check = _cpu_section_and_check(cpu)
    checks.append(cpu_check)
    if cpu_section:
        sections.append(cpu_section)
        facts.append(("cpu", cpu.model if cpu else ""))

    mem_section, mem_check, mem_total = _memory_section_and_check(env)
    checks.append(mem_check)
    if mem_section:
        sections.append(mem_section)
        facts.append(("memory", mem_total))

    # PCI / GPU
    pci: list[PciDevice] = []
    try:
        completed = env.run(["lspci", "-nnk"])
        if completed.ok:
            pci = parse_lspci(completed.stdout)
            gpus = [d for d in pci if d.is_gpu]
            if gpus:
                sections.append(
                    Table(
                        "Graphics",
                        ("Adapter", "ID", "Driver"),
                        tuple((g.name, g.ids, g.driver or "none") for g in gpus),
                    )
                )
                facts.append(("gpu", "; ".join(g.name for g in gpus)))
            sections.append(
                Table(
                    "PCI devices",
                    ("Slot", "Class", "Device", "Driver"),
                    tuple((d.slot, d.class_name, d.name, d.driver or "-") for d in pci),
                )
            )
            checks.append(_gpu_check(gpus))
            checks.append(ok("hardware.pci", "PCI devices", f"{len(pci)} device(s) identified"))
        else:
            reason = f"lspci failed (exit {completed.returncode})"
            checks.append(skip("hardware.gpu", "Graphics driver", reason))
            checks.append(skip("hardware.pci", "PCI devices", reason))
    except ToolUnavailableError:
        reason = missing_message("lspci")
        checks.append(skip("hardware.gpu", "Graphics driver", reason))
        checks.append(skip("hardware.pci", "PCI devices", reason))
    except LumeError as exc:
        checks.append(skip("hardware.gpu", "Graphics driver", str(exc)))
        checks.append(skip("hardware.pci", "PCI devices", str(exc)))

    # USB
    try:
        completed = env.run(["lsusb"])
        if completed.ok:
            usb: list[UsbDevice] = parse_lsusb(completed.stdout)
            external = [d for d in usb if not d.is_root_hub]
            if external:
                sections.append(
                    Table(
                        "USB devices",
                        ("Bus/Device", "ID", "Description"),
                        tuple((f"{d.bus}/{d.device}", d.ids, d.description) for d in external),
                    )
                )
            checks.append(
                ok(
                    "hardware.usb",
                    "USB devices",
                    f"{len(external)} device(s) plugged in ({len(usb) - len(external)} root hubs)",
                )
            )
        else:
            checks.append(
                skip("hardware.usb", "USB devices", f"lsusb failed (exit {completed.returncode})")
            )
    except ToolUnavailableError:
        checks.append(skip("hardware.usb", "USB devices", missing_message("lsusb")))
    except LumeError as exc:
        checks.append(skip("hardware.usb", "USB devices", str(exc)))

    # Disks
    try:
        completed = env.run(["lsblk", "-J", "-b", "-o", LSBLK_COLUMNS])
        devices: list[BlockDevice] | None = parse_lsblk(completed.stdout) if completed.ok else None
        if devices is None:
            checks.append(skip("hardware.disks", "Disks", "lsblk output could not be read"))
        else:
            visible = real_devices(devices)
            disks = [d for d in visible if d.type == "disk"]
            sections.append(
                Table(
                    "Disks",
                    ("Device", "Kind", "Size", "Model", "Transport"),
                    tuple(
                        (d.name, d.kind, format_bytes(d.size), d.model or "-", d.transport or "-")
                        for d in disks
                    ),
                )
            )
            total = sum(d.size for d in disks)
            checks.append(
                ok(
                    "hardware.disks",
                    "Disks",
                    f"{len(disks)} disk(s), {format_bytes(total)} in total",
                )
                if disks
                else skip("hardware.disks", "Disks", "no physical disk reported by lsblk")
            )
    except ToolUnavailableError:
        checks.append(skip("hardware.disks", "Disks", missing_message("lsblk")))
    except LumeError as exc:
        checks.append(skip("hardware.disks", "Disks", str(exc)))

    # Network interfaces
    interfaces = list_interfaces(env)
    if interfaces:
        sections.append(
            Table(
                "Network interfaces",
                ("Name", "Type", "State", "MAC", "Addresses"),
                tuple(
                    (i.name, i.kind, i.state, i.mac or "-", ", ".join(i.addresses) or "-")
                    for i in interfaces
                ),
            )
        )

    # Sensors
    temps = read_temperatures(env)
    if temps:
        sections.append(
            Table(
                "Temperatures",
                ("Sensor", "Label", "Temperature"),
                tuple((t.sensor, t.label, f"{t.celsius:.0f} °C") for t in temps),
            )
        )
    checks.append(_temperature_check(temps))
    checks.append(_machine_check(kernel_log if kernel_log is not None else read_kernel_log(env)))

    return Report("hardware", "Hardware", tuple(sections), tuple(checks), tuple(facts))
