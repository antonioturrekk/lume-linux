"""Mounted filesystems (``/proc/self/mounts``)."""

from __future__ import annotations

import re
from dataclasses import dataclass

PSEUDO_FS = frozenset(
    {
        "proc", "sysfs", "devtmpfs", "devpts", "tmpfs", "ramfs", "cgroup", "cgroup2", "pstore",
        "securityfs", "debugfs", "tracefs", "configfs", "fusectl", "mqueue", "hugetlbfs", "bpf",
        "autofs", "binfmt_misc", "rpc_pipefs", "nsfs", "efivarfs", "selinuxfs", "overlayfs-proc",
    }
)  # fmt: skip
READONLY_BY_DESIGN = frozenset({"squashfs", "erofs", "iso9660", "udf", "cramfs"})
_OCTAL_RE = re.compile(r"\\([0-7]{3})")


@dataclass(frozen=True, slots=True)
class Mount:
    """One mounted filesystem."""

    source: str
    target: str
    fstype: str
    options: tuple[str, ...]

    @property
    def read_only(self) -> bool:
        return "ro" in self.options

    @property
    def is_block_device(self) -> bool:
        return self.source.startswith("/dev/")


def _unescape(value: str) -> str:
    return _OCTAL_RE.sub(lambda m: chr(int(m.group(1), 8)), value)


def parse_mounts(text: str) -> list[Mount]:
    """Parse ``/proc/self/mounts``."""
    mounts: list[Mount] = []
    for line in text.splitlines():
        fields = line.split()
        if len(fields) < 4:
            continue
        mounts.append(
            Mount(
                _unescape(fields[0]),
                _unescape(fields[1]),
                fields[2],
                tuple(fields[3].split(",")),
            )
        )
    return mounts


def real_mounts(mounts: list[Mount]) -> list[Mount]:
    """Keep the filesystems that hold user data.

    Drops kernel pseudo filesystems, snap/ISO images (read-only by design) and
    FUSE helpers. Several mounts of the same block device (bind mounts) are
    reduced to the one with the shortest path.
    """
    kept: list[Mount] = []
    best_by_device: dict[str, Mount] = {}
    for mount in mounts:
        if mount.fstype in PSEUDO_FS or mount.fstype in READONLY_BY_DESIGN:
            continue
        if mount.fstype.startswith("fuse.") or mount.fstype == "fuse":
            continue
        if mount.is_block_device:
            current = best_by_device.get(mount.source)
            if current is None or len(mount.target) < len(current.target):
                best_by_device[mount.source] = mount
        else:
            kept.append(mount)
    kept.extend(best_by_device.values())
    return sorted(kept, key=lambda m: m.target)
