"""Read-only storage analysis: partitions, filesystems, mount points, free space."""

from __future__ import annotations

import re

from lume.core import CheckResult, error, ok, skip, warn
from lume.core.environment import DiskUsage, Environment
from lume.core.exceptions import LumeError, ToolUnavailableError
from lume.core.kernel_log import STORAGE_RE, KernelLog, read_kernel_log
from lume.core.report import Report, Section, Table
from lume.core.tools import missing_message
from lume.core.units import format_bytes, format_percent
from lume.hardware.disks import LSBLK_COLUMNS, BlockDevice, parse_lsblk, real_devices
from lume.storage.mounts import Mount, parse_mounts, real_mounts

__all__ = ["analyze", "space_check"]

SPACE_WARN, SPACE_ERROR = 90.0, 97.0
MIN_FILESYSTEM_BYTES = 16 * 1024 * 1024
CRITICAL_RE = re.compile(
    r"(EXT4-fs error|XFS .*(corruption|error)|BTRFS (error|critical)|"
    r"Remounting filesystem read-only)",
    re.IGNORECASE,
)


def _describe(mount: Mount, usage: DiskUsage) -> str:
    return (
        f"{mount.target}: {format_percent(usage.percent_used)} used "
        f"({format_bytes(usage.available)} free of {format_bytes(usage.total)})"
    )


def space_check(
    check_id: str, name: str, filesystems: list[tuple[Mount, DiskUsage]]
) -> CheckResult:
    """Classify free space of the given filesystems (worst one wins)."""
    if not filesystems:
        return skip(check_id, name, "no mounted filesystem could be measured")
    errors = [_describe(m, u) for m, u in filesystems if u.percent_used >= SPACE_ERROR]
    warnings = [
        _describe(m, u) for m, u in filesystems if SPACE_WARN <= u.percent_used < SPACE_ERROR
    ]
    if errors:
        return error(
            check_id,
            name,
            "a disk is almost full; programs may fail to save files",
            errors + warnings,
        )
    if warnings:
        return warn(check_id, name, "a disk is running out of free space", warnings)
    fullest_mount, fullest = max(filesystems, key=lambda pair: pair[1].percent_used)
    return ok(
        check_id,
        name,
        f"{len(filesystems)} filesystem(s) with enough free space "
        f"(fullest: {fullest_mount.target} at {format_percent(fullest.percent_used)})",
    )


def _inode_check(filesystems: list[tuple[Mount, DiskUsage]]) -> CheckResult:
    limited = [(m, u) for m, u in filesystems if u.inodes_total > 0]
    if not limited:
        return skip("storage.inodes", "Inodes", "no filesystem reports an inode limit")
    errors = [
        f"{m.target}: {format_percent(u.inodes_percent_used)} of inodes used"
        for m, u in limited
        if u.inodes_percent_used >= SPACE_ERROR
    ]
    warnings = [
        f"{m.target}: {format_percent(u.inodes_percent_used)} of inodes used"
        for m, u in limited
        if SPACE_WARN <= u.inodes_percent_used < SPACE_ERROR
    ]
    if errors:
        return error(
            "storage.inodes",
            "Inodes",
            "a filesystem is out of file entries (inodes) even if space remains",
            errors + warnings,
        )
    if warnings:
        return warn("storage.inodes", "Inodes", "a filesystem is running out of inodes", warnings)
    return ok("storage.inodes", "Inodes", "enough free inodes on every filesystem")


def _readonly_check(mounts: list[Mount]) -> CheckResult:
    suspects = [m for m in mounts if m.is_block_device and m.read_only]
    if not suspects:
        return ok("storage.readonly", "Read-only filesystems", "all disk filesystems are writable")
    evidence = [f"{m.target}: {m.source} ({m.fstype}) mounted read-only" for m in suspects]
    if any(m.target == "/" for m in suspects):
        return error(
            "storage.readonly",
            "Read-only filesystems",
            "the system disk is read-only; this usually follows disk errors",
            evidence,
        )
    return warn(
        "storage.readonly",
        "Read-only filesystems",
        "a disk filesystem is mounted read-only",
        evidence,
    )


def _kernel_check(kernel_log: KernelLog) -> CheckResult:
    if not kernel_log.available:
        return skip(
            "storage.kernel_errors",
            "Disk errors in kernel log",
            kernel_log.unavailable_reason or "unavailable",
        )
    lines = kernel_log.matching(STORAGE_RE)
    if not lines:
        return ok("storage.kernel_errors", "Disk errors in kernel log", "no disk errors this boot")
    critical = [line for line in lines if CRITICAL_RE.search(line)]
    summary = f"{len(lines)} disk-related error message(s) in the kernel log"
    if critical:
        return error("storage.kernel_errors", "Disk errors in kernel log", summary, lines[:3])
    return warn("storage.kernel_errors", "Disk errors in kernel log", summary, lines[:3])


def measured_filesystems(env: Environment, mounts: list[Mount]) -> list[tuple[Mount, DiskUsage]]:
    """Real filesystems together with their usage."""
    measured: list[tuple[Mount, DiskUsage]] = []
    for mount in real_mounts(mounts):
        usage = env.disk_usage(mount.target)
        if usage is not None and usage.total >= MIN_FILESYSTEM_BYTES:
            measured.append((mount, usage))
    return measured


def analyze(env: Environment, *, kernel_log: KernelLog | None = None) -> Report:
    """Analyze disks, filesystems and free space (read-only)."""
    sections: list[Section] = []
    checks: list[CheckResult] = []

    # Partitions (lsblk)
    try:
        completed = env.run(["lsblk", "-J", "-b", "-o", LSBLK_COLUMNS])
        devices: list[BlockDevice] | None = parse_lsblk(completed.stdout) if completed.ok else None
        if devices is None:
            checks.append(
                skip("storage.partitions", "Partitions", "lsblk output could not be read")
            )
        else:
            visible = real_devices(devices)
            sections.append(
                Table(
                    "Partitions",
                    ("Device", "Type", "Size", "Filesystem", "Mounted at"),
                    tuple(
                        (
                            ("  " if d.parent else "") + d.name,
                            d.type,
                            format_bytes(d.size),
                            d.fstype or "-",
                            d.mountpoint or "-",
                        )
                        for d in visible
                    ),
                )
            )
            parts = [d for d in visible if d.type == "part"]
            disks = [d for d in visible if d.type == "disk"]
            checks.append(
                ok(
                    "storage.partitions",
                    "Partitions",
                    f"{len(parts)} partition(s) on {len(disks)} disk(s)",
                )
            )
    except ToolUnavailableError:
        checks.append(skip("storage.partitions", "Partitions", missing_message("lsblk")))
    except LumeError as exc:
        checks.append(skip("storage.partitions", "Partitions", str(exc)))

    # Filesystems (/proc/self/mounts + statvfs)
    mounts_text = env.read_text("/proc/self/mounts") or env.read_text("/proc/mounts")
    filesystems: list[tuple[Mount, DiskUsage]] = []
    if mounts_text is None:
        reason = "/proc/self/mounts is not readable"
        checks += [
            skip("storage.space", "Disk space", reason),
            skip("storage.inodes", "Inodes", reason),
            skip("storage.readonly", "Read-only filesystems", reason),
        ]
    else:
        mounts = parse_mounts(mounts_text)
        filesystems = measured_filesystems(env, mounts)
        if filesystems:
            sections.append(
                Table(
                    "Filesystems",
                    (
                        "Mount point",
                        "Device",
                        "Type",
                        "Size",
                        "Used",
                        "Free",
                        "Use%",
                        "Inodes%",
                        "Mode",
                    ),
                    tuple(
                        (
                            m.target,
                            m.source,
                            m.fstype,
                            format_bytes(u.total),
                            format_bytes(u.used),
                            format_bytes(u.available),
                            format_percent(u.percent_used),
                            format_percent(u.inodes_percent_used) if u.inodes_total else "-",
                            "ro" if m.read_only else "rw",
                        )
                        for m, u in filesystems
                    ),
                )
            )
        checks.append(space_check("storage.space", "Disk space", filesystems))
        checks.append(_inode_check(filesystems))
        checks.append(_readonly_check(real_mounts(mounts)))

    checks.append(_kernel_check(kernel_log if kernel_log is not None else read_kernel_log(env)))
    facts = tuple(
        ("root_usage", f"{format_percent(u.percent_used)} used ({format_bytes(u.available)} free)")
        for m, u in (filesystems if mounts_text is not None else [])
        if m.target == "/"
    )
    return Report("storage", "Storage", tuple(sections), tuple(checks), facts)
