"""One-sentence verdict of a diagnosis."""

from __future__ import annotations

from lume.core import Status
from lume.diagnostics.engine import Diagnosis


def verdict(diagnosis: Diagnosis) -> str:
    """Plain-language conclusion."""
    counts = diagnosis.counts
    errors, warnings = counts[Status.ERROR], counts[Status.WARN]
    if errors:
        return f"{errors} problem(s) identified and {warnings} possible problem(s) detected."
    if warnings:
        return f"No identified problems, but {warnings} possible problem(s) deserve attention."
    return "No problems detected."
