"""JSON report."""

from __future__ import annotations

import json

from lume.diagnostics.engine import Diagnosis
from lume.reports.recommendations import Recommendation
from lume.reports.verdict import verdict

SCHEMA_VERSION = 1


def render(diagnosis: Diagnosis, recommendations: tuple[Recommendation, ...]) -> str:
    """Render the diagnosis as JSON (stable keys, UTF-8)."""
    document = {
        "schema_version": SCHEMA_VERSION,
        **diagnosis.to_dict(),
        "verdict": verdict(diagnosis),
        "recommendations": [r.to_dict() for r in recommendations],
    }
    return json.dumps(document, indent=2, ensure_ascii=False) + "\n"
