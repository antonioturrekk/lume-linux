"""Self-contained HTML report (no scripts, no external resources)."""

from __future__ import annotations

from html import escape

from lume.core import Status
from lume.core.report import KeyValues, Report, Table
from lume.diagnostics.engine import Diagnosis
from lume.reports.recommendations import Recommendation
from lume.reports.verdict import verdict

CSS = """
:root{color-scheme:dark;--bg:#14161a;--panel:#1c1f26;--text:#e6e6e6;--muted:#9aa0a6;
--line:#2c313a;--brand:#ffb000;--ok:#3fb950;--warn:#d29922;--error:#f85149;--skip:#6e7681}
@media print{:root{color-scheme:light;--bg:#fff;--panel:#fff;--text:#111;--muted:#555;--line:#ccc}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);
font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
main{max-width:980px;margin:0 auto;padding:32px 20px}
h1{margin:0;font-size:28px;color:var(--brand)}h2{margin:36px 0 12px;border-bottom:1px solid var(--line);
padding-bottom:6px}h3{margin:22px 0 8px;font-size:16px;color:var(--muted)}
.tag{color:var(--muted);margin:2px 0 18px}.meta{display:grid;grid-template-columns:max-content 1fr;
gap:2px 16px;color:var(--muted)}.meta b{color:var(--text);font-weight:600}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin:14px 0}.card{background:var(--panel);
border:1px solid var(--line);border-radius:8px;padding:10px 18px;min-width:90px}
.card b{display:block;font-size:24px}
table{width:100%;border-collapse:collapse;background:var(--panel);border:1px solid var(--line);
border-radius:6px;overflow:hidden;margin:6px 0 4px}
th,td{text-align:left;padding:6px 10px;border-bottom:1px solid var(--line);vertical-align:top;
word-break:break-word}th{color:var(--muted);font-weight:600}
.wrap{overflow-x:auto}.badge{display:inline-block;min-width:58px;text-align:center;border-radius:4px;
padding:1px 6px;font:600 12px ui-monospace,monospace;color:#111}
.OK{background:var(--ok)}.WARN{background:var(--warn)}.ERROR{background:var(--error)}
.SKIP{background:var(--skip);color:#fff}
.problem{background:var(--panel);border:1px solid var(--line);border-left:4px solid var(--warn);
border-radius:6px;padding:10px 14px;margin:10px 0}.problem.ERROR{border-left-color:var(--error)}
.problem ul{margin:6px 0 0;color:var(--muted)}code,pre{font-family:ui-monospace,Menlo,monospace}
pre{background:#0d0f12;color:#e6e6e6;padding:8px 12px;border-radius:6px;overflow-x:auto;margin:6px 0}
.note{color:var(--muted);font-size:13px}.risk-high{color:var(--error)}.risk-medium{color:var(--warn)}
footer{margin-top:40px;color:var(--muted);font-size:13px;border-top:1px solid var(--line);padding-top:10px}
"""


def _e(value: object) -> str:
    return escape(str(value), quote=True)


def _table(columns: tuple[str, ...], rows: list[tuple[str, ...]]) -> str:
    head = "".join(f"<th>{_e(c)}</th>" for c in columns)
    body = "".join("<tr>" + "".join(f"<td>{_e(c)}</td>" for c in row) + "</tr>" for row in rows)
    return (
        f'<div class="wrap"><table><thead><tr>{head}</tr></thead>'
        f"<tbody>{body}</tbody></table></div>"
    )


def _badge(status: Status) -> str:
    return f'<span class="badge {status.value}">{status.value}</span>'


def _report_html(report: Report) -> str:
    parts = [f"<h2>{_e(report.title)}</h2>"]
    for section in report.sections:
        parts.append(f"<h3>{_e(section.title)}</h3>")
        if isinstance(section, KeyValues):
            parts.append(_table(("Item", "Value"), list(section.items)))
        elif isinstance(section, Table):
            parts.append(_table(section.columns, list(section.rows)))
    rows = "".join(
        f"<tr><td>{_badge(c.status)}</td><td>{_e(c.name)}</td><td>{_e(c.summary)}</td></tr>"
        for c in report.checks
    )
    parts.append(
        "<h3>Checks</h3><div class='wrap'><table><thead><tr><th>Status</th><th>Check</th>"
        f"<th>Result</th></tr></thead><tbody>{rows}</tbody></table></div>"
    )
    return "".join(parts)


def _recommendation_html(rec: Recommendation) -> str:
    s = rec.solution
    steps = []
    for step in s.steps:
        item = f"<li>{_e(step.description)}"
        if step.command:
            item += f"<pre>{_e(step.command)}</pre>"
        steps.append(item + "</li>")
    return (
        f"<h3>{_e(s.id)} — {_e(s.name)}</h3>"
        f'<p class="note">Risk: <b class="risk-{_e(s.risk)}">{_e(s.risk)}</b> · '
        f"Because of: {_e(', '.join(rec.because_of))}</p>"
        f"<p>{_e(s.summary)}</p><ol>{''.join(steps)}</ol>"
    )


def render(diagnosis: Diagnosis, recommendations: tuple[Recommendation, ...]) -> str:
    """Render the diagnosis as a single HTML document."""
    counts = diagnosis.counts
    cards = "".join(
        f'<div class="card">{_badge(status)}<b>{counts[status]}</b></div>' for status in Status
    )
    problems = ""
    for check in diagnosis.problems:
        evidence = "".join(f"<li><code>{_e(e)}</code></li>" for e in check.evidence)
        problems += (
            f'<div class="problem {check.status.value}">{_badge(check.status)} '
            f"<b>{_e(check.name)}</b> — {_e(check.summary)}<ul>{evidence}</ul></div>"
        )
    skipped = "".join(
        f"<li><b>{_e(c.name)}</b>: {_e(c.summary)}</li>"
        for c in diagnosis.checks
        if c.status is Status.SKIP
    )
    if recommendations:
        recommendations_html = "".join(_recommendation_html(r) for r in recommendations) + (
            '<p class="note">LUME does not run these commands. '
            "Review them and run them yourself.</p>"
        )
    else:
        recommendations_html = "<p>No recommendations for this system.</p>"
    skipped_html = f"<ul>{skipped}</ul>" if skipped else "<p>Every check ran.</p>"
    problems_html = problems or "<p>No problems were found.</p>"
    reports_html = "".join(_report_html(r) for r in diagnosis.reports)
    meta = [
        ("Generated", diagnosis.generated_at),
        ("LUME version", diagnosis.lume_version),
        ("System", diagnosis.distro.pretty_name),
        ("Personal data", "removed (anonymized)" if diagnosis.anonymized else "included"),
        ("Network probes", "disabled (offline)" if diagnosis.offline else "enabled"),
    ]
    meta_html = "".join(f"<span>{_e(k)}</span><b>{_e(v)}</b>" for k, v in meta)
    policy = "default-src 'none'; style-src 'unsafe-inline'"
    head = (
        '<!DOCTYPE html>\n<html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f'<meta http-equiv="Content-Security-Policy" content="{policy}">'
        f"<title>LUME diagnostic report</title><style>{CSS}</style></head><body><main>"
        "<h1>✦ LUME</h1>"
        '<div class="tag">Linux Utility &amp; Monitoring Engine — diagnostic report</div>'
        f'<div class="meta">{meta_html}</div>'
    )
    body = (
        f"<h2>Summary</h2><p>{_e(verdict(diagnosis))}</p>"
        f'<div class="cards">{cards}</div>'
        f"<h2>Problems found</h2>{problems_html}"
        f"<h2>Recommendations</h2>{recommendations_html}"
        f"{reports_html}"
        f"<h2>Checks that could not run</h2>{skipped_html}"
    )
    footer = (
        f"<footer>Generated by LUME {_e(diagnosis.lume_version)}</footer></main></body></html>\n"
    )
    return head + body + footer
