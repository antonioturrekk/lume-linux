"""Turns problems into recommendations using the solutions database."""

from __future__ import annotations

from dataclasses import dataclass

from lume.diagnostics.engine import Diagnosis
from lume.solutions import Solution, SolutionBase


@dataclass(frozen=True, slots=True)
class Recommendation:
    """A solution suggested because of one or more problems."""

    solution: Solution
    because_of: tuple[str, ...]  # names of the checks

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.solution.id,
            "name": self.solution.name,
            "risk": self.solution.risk,
            "because_of": list(self.because_of),
            "summary": self.solution.summary,
            "steps": [s.to_dict() for s in self.solution.steps],
            "note": "LUME does not run these commands; review them and run them yourself.",
        }


def build_recommendations(diagnosis: Diagnosis, base: SolutionBase) -> tuple[Recommendation, ...]:
    """Compatible solutions for every WARN/ERROR check, without repeats."""
    triggers: dict[str, list[str]] = {}
    found: dict[str, Solution] = {}
    for check in diagnosis.problems:
        if not check.check_id:
            continue
        for solution in base.related_to([check.check_id], diagnosis.distro):
            found[solution.id] = solution
            triggers.setdefault(solution.id, []).append(check.name)
    return tuple(Recommendation(found[sid], tuple(triggers[sid])) for sid in sorted(found))
