"""Writing reports to disk safely."""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from lume.core.exceptions import LumeError
from lume.diagnostics.engine import Diagnosis

EXTENSIONS = {"html": "html", "markdown": "md", "json": "json"}


class ReportWriteError(LumeError):
    """The report file could not be written."""


def default_filename(diagnosis: Diagnosis, report_format: str) -> str:
    """``lume-report-YYYYMMDD-HHMMSS.<ext>`` from the diagnosis time."""
    try:
        stamp = datetime.fromisoformat(diagnosis.generated_at).strftime("%Y%m%d-%H%M%S")
    except ValueError:
        stamp = "report"
    return f"lume-report-{stamp}.{EXTENSIONS[report_format]}"


def write_report(content: str, path: Path, *, overwrite: bool = False) -> Path:
    """Write ``content`` to ``path``.

    An existing file is never replaced unless ``overwrite`` is true. The file is
    created readable only by its owner, because reports describe the machine.
    """
    flags = os.O_WRONLY | os.O_CREAT | (os.O_TRUNC if overwrite else os.O_EXCL)
    try:
        descriptor = os.open(path, flags, 0o600)
    except FileExistsError as exc:
        raise ReportWriteError(
            f"{path} already exists; choose another name or use --force to replace it"
        ) from exc
    except OSError as exc:
        raise ReportWriteError(f"cannot write {path}: {exc.strerror or exc}") from exc
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(content)
    except OSError as exc:
        raise ReportWriteError(f"cannot write {path}: {exc.strerror or exc}") from exc
    return path
