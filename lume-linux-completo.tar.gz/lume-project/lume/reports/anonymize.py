"""Removal of personal information from reports.

LUME never collects serial numbers, user names, SSIDs or machine ids. What can
still appear in a diagnosis are network addresses, the host name and home
paths; this module masks them so a report can be shared safely.
"""

from __future__ import annotations

import ipaddress
import re
from dataclasses import replace

from lume.core.report import KeyValues, Report
from lume.diagnostics.engine import Diagnosis

_UUID_RE = re.compile(
    r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b"
)
_MAC_RE = re.compile(r"\b([0-9a-fA-F]{2}(?::[0-9a-fA-F]{2}){2})(?::[0-9a-fA-F]{2}){3}\b")
_IPV6_RE = re.compile(r"(?<![\w:.])[0-9a-fA-F:]*:[0-9a-fA-F:]+(?![\w:])")
_IPV4_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_HOME_RE = re.compile(r"/home/[^/\s:;,'\")]+")
_RUN_USER_RE = re.compile(r"/run/user/\d+")
_COMMON_HOSTNAMES = frozenset(
    {"localhost", "ubuntu", "debian", "linux", "fedora", "arch", "mint", "raspberrypi"}
)
HOSTNAME_PLACEHOLDER = "<hostname>"


def _mask_ipv4(match: re.Match[str]) -> str:
    try:
        address = ipaddress.IPv4Address(match.group(0))
    except ValueError:
        return match.group(0)
    if address.is_loopback or address.is_unspecified:
        return match.group(0)
    octets = match.group(0).split(".")
    if address.is_link_local:
        return "169.254.x.x"  # the range itself tells DHCP failed; the host part is irrelevant
    if address.is_private:
        return f"{octets[0]}.{octets[1]}.x.x"
    return "<public-ip>"


def _mask_ipv6(match: re.Match[str]) -> str:
    token = match.group(0)
    try:
        address = ipaddress.IPv6Address(token)
    except ValueError:
        return token
    if address.is_loopback or address.is_unspecified:
        return token
    if address.is_link_local:
        return "fe80::xxxx"
    return "<ipv6>"


class Anonymizer:
    """Masks personal data in text."""

    def __init__(self, hostname: str = "") -> None:
        self.hostname = hostname.strip()
        self._hostname_re: re.Pattern[str] | None = None
        if len(self.hostname) >= 4 and self.hostname.lower() not in _COMMON_HOSTNAMES:
            self._hostname_re = re.compile(
                rf"(?<![\w-]){re.escape(self.hostname)}(?![\w-])", re.IGNORECASE
            )

    def text(self, value: str) -> str:
        """Return ``value`` with personal data masked."""
        value = _UUID_RE.sub("<uuid>", value)
        value = _MAC_RE.sub(lambda m: f"{m.group(1).lower()}:xx:xx:xx", value)
        value = _IPV6_RE.sub(_mask_ipv6, value)
        value = _IPV4_RE.sub(_mask_ipv4, value)
        value = _HOME_RE.sub("/home/<user>", value)
        value = _RUN_USER_RE.sub("/run/user/<uid>", value)
        if self._hostname_re is not None:
            value = self._hostname_re.sub(HOSTNAME_PLACEHOLDER, value)
        return value

    def report(self, report: Report) -> Report:
        """Anonymize one report (the host name row is always masked)."""
        masked = report.map_text(self.text)
        sections = tuple(
            KeyValues(
                s.title,
                tuple((k, HOSTNAME_PLACEHOLDER if k == "Hostname" else v) for k, v in s.items),
            )
            if isinstance(s, KeyValues)
            else s
            for s in masked.sections
        )
        return replace(masked, sections=sections)

    def diagnosis(self, diagnosis: Diagnosis) -> Diagnosis:
        """Return an anonymized copy of a diagnosis."""
        return replace(
            diagnosis,
            reports=tuple(self.report(r) for r in diagnosis.reports),
            anonymized=True,
        )
