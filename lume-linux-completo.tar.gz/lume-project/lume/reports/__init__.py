"""Report generation: HTML, Markdown and JSON, with optional anonymization."""

from __future__ import annotations

from lume.diagnostics.engine import Diagnosis
from lume.reports import html, json_report, markdown
from lume.reports.anonymize import Anonymizer
from lume.reports.recommendations import Recommendation, build_recommendations
from lume.reports.writer import ReportWriteError, default_filename, write_report
from lume.solutions import SolutionBase

FORMATS = ("html", "markdown", "json")
_RENDERERS = {"html": html.render, "markdown": markdown.render, "json": json_report.render}

__all__ = [
    "FORMATS",
    "Anonymizer",
    "Recommendation",
    "ReportWriteError",
    "build_recommendations",
    "default_filename",
    "generate",
    "write_report",
]


def generate(diagnosis: Diagnosis, report_format: str, base: SolutionBase) -> str:
    """Render ``diagnosis`` in the given format, with recommendations from ``base``."""
    if report_format not in _RENDERERS:
        raise ValueError(f"unknown report format: {report_format}")
    return _RENDERERS[report_format](diagnosis, build_recommendations(diagnosis, base))
