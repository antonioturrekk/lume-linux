"""LUME - Linux Utility & Monitoring Engine.

Read-only diagnostic and support tool for Linux systems.
"""

__version__ = "0.1.0.dev0"

__all__ = ["__version__"]
