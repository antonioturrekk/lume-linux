"""General system checks: distribution, kernel, services, packages, privileges."""

from __future__ import annotations

from lume.core import CheckResult, error, ok, skip, warn
from lume.core.distro import Distro, detect
from lume.core.environment import Environment
from lume.core.exceptions import LumeError, ToolUnavailableError
from lume.core.kernel_log import KernelLog
from lume.core.procfs import parse_uptime
from lume.core.report import KeyValues, Report
from lume.core.tools import missing_message
from lume.core.units import format_duration

__all__ = ["analyze"]

OFFICIAL_UBUNTU_MINIMUM = (26, 4)
ESSENTIAL_UNITS = (
    "dbus.service",
    "systemd-journald.service",
    "systemd-logind.service",
    "systemd-udevd.service",
)
NETWORK_UNITS = ("NetworkManager.service", "systemd-networkd.service")
SYSTEMD_RUNTIME_DIR = "/run/systemd/system"

TAINT_FLAGS = {
    0: "proprietary module loaded",
    1: "module force-loaded",
    2: "unsafe SMP processors",
    3: "module force-unloaded",
    4: "machine check exception",
    5: "bad page referenced",
    6: "taint requested by user",
    7: "kernel died (oops)",
    8: "ACPI table overridden",
    9: "kernel warning issued",
    10: "staging driver loaded",
    11: "firmware workaround applied",
    12: "out-of-tree module loaded",
    13: "unsigned module loaded",
    14: "soft lockup detected",
    15: "kernel live-patched",
}
SERIOUS_TAINT_BITS = frozenset({4, 5, 7, 9, 14})


def _version(distro: Distro) -> tuple[int, ...]:
    try:
        return tuple(int(p) for p in distro.version_id.split("."))
    except ValueError:
        return ()


def _platform_check(distro: Distro) -> CheckResult:
    if distro.id == "linux" and distro.pretty_name == "Linux":
        return skip(
            "system.platform", "Platform support", "the distribution could not be identified"
        )
    if distro.id == "ubuntu":
        if _version(distro) >= OFFICIAL_UBUNTU_MINIMUM:
            return ok(
                "system.platform",
                "Platform support",
                f"{distro.pretty_name} is officially supported",
            )
        return ok(
            "system.platform",
            "Platform support",
            f"{distro.pretty_name} should work, but only Ubuntu 26.04+ is officially supported",
        )
    if distro.is_ubuntu_based:
        return ok(
            "system.platform",
            "Platform support",
            f"{distro.pretty_name} is Ubuntu-based, which LUME supports",
        )
    return warn(
        "system.platform",
        "Platform support",
        "this distribution is not officially supported yet",
        [
            f"detected: {distro.pretty_name} (family: {distro.family})",
            "LUME is developed for Ubuntu 26.04+; some checks may be skipped or incomplete",
        ],
    )


def _privileges_check(env: Environment) -> CheckResult:
    if env.geteuid() == 0:
        return warn(
            "system.privileges",
            "Privileges",
            "LUME is running as root, which it does not need",
            ["effective user id is 0; run LUME as a regular user"],
        )
    return ok(
        "system.privileges", "Privileges", "running as a regular user (no elevated privileges)"
    )


def _taint_check(env: Environment) -> CheckResult:
    text = (env.read_text("/proc/sys/kernel/tainted") or "").strip()
    if not text.isdigit():
        return skip(
            "system.kernel_taint", "Kernel state", "/proc/sys/kernel/tainted is not readable"
        )
    value = int(text)
    if value == 0:
        return ok("system.kernel_taint", "Kernel state", "the kernel is not tainted")
    bits = [bit for bit in range(32) if value & (1 << bit)]
    serious = [TAINT_FLAGS.get(b, f"bit {b}") for b in bits if b in SERIOUS_TAINT_BITS]
    if serious:
        return warn(
            "system.kernel_taint",
            "Kernel state",
            "the kernel reported a serious event since boot",
            [f"taint value {value}: {', '.join(serious)}"],
        )
    benign = ", ".join(TAINT_FLAGS.get(b, f"bit {b}") for b in bits)
    return ok(
        "system.kernel_taint",
        "Kernel state",
        f"tainted only by: {benign} (normal with third-party drivers)",
    )


def _reboot_check(env: Environment, distro: Distro) -> CheckResult:
    if distro.family != "debian":
        return skip(
            "system.reboot",
            "Pending restart",
            "the reboot-required marker is a Debian/Ubuntu feature "
            f"(detected family: {distro.family})",
        )
    for directory in ("/var/run", "/run"):
        if env.exists(f"{directory}/reboot-required"):
            packages = (env.read_text(f"{directory}/reboot-required.pkgs") or "").split()
            evidence = [f"{directory}/reboot-required exists"]
            if packages:
                evidence.append(f"updated packages: {', '.join(sorted(set(packages))[:5])}")
            return warn(
                "system.reboot",
                "Pending restart",
                "a restart is needed to finish updates",
                evidence,
            )
    return ok("system.reboot", "Pending restart", "no restart is pending")


def _systemd_state(env: Environment) -> CheckResult:
    if not env.exists(SYSTEMD_RUNTIME_DIR):
        return skip(
            "system.services",
            "System services",
            "systemd is not the running init system (or this is a container)",
        )
    try:
        state_result = env.run(["systemctl", "is-system-running"])
    except ToolUnavailableError:
        return skip("system.services", "System services", missing_message("systemctl"))
    except LumeError as exc:
        return skip("system.services", "System services", str(exc))
    state = state_result.stdout.strip() or "unknown"
    if state == "running":
        return ok("system.services", "System services", "all services started correctly")
    if state in ("starting", "initializing"):
        return ok(
            "system.services", "System services", f"the system is still starting up ({state})"
        )
    if state == "degraded":
        failed: list[str] = []
        try:
            listing = env.run(["systemctl", "--failed", "--no-legend", "--plain", "--no-pager"])
            failed = [
                " ".join(line.split()[:4]) for line in listing.stdout.splitlines() if line.strip()
            ]
        except LumeError:
            pass
        evidence = [f"failed unit: {line}" for line in failed[:8]] or [
            "systemd reports state 'degraded'"
        ]
        return warn(
            "system.services", "System services", "one or more services failed to start", evidence
        )
    if state == "maintenance":
        return error(
            "system.services",
            "System services",
            "the system is in maintenance (rescue) mode",
            ["systemctl is-system-running: maintenance"],
        )
    return skip("system.services", "System services", f"systemd reports state '{state}'")


def _parse_show(text: str) -> dict[str, str]:
    return dict(line.split("=", 1) for line in text.splitlines() if "=" in line)


def _unit_state(env: Environment, unit: str) -> dict[str, str] | None:
    try:
        completed = env.run(
            ["systemctl", "show", "--no-pager", "--property=LoadState,ActiveState,SubState", unit]
        )
    except LumeError:
        return None
    return _parse_show(completed.stdout) if completed.ok else None


def _essential_services_check(env: Environment) -> CheckResult:
    if not env.exists(SYSTEMD_RUNTIME_DIR):
        return skip(
            "system.essential", "Essential services", "systemd is not the running init system"
        )
    problems: list[str] = []
    checked = 0
    for unit in ESSENTIAL_UNITS:
        state = _unit_state(env, unit)
        if state is None or state.get("LoadState") != "loaded":
            continue
        checked += 1
        if state.get("ActiveState") != "active":
            problems.append(f"{unit}: {state.get('ActiveState')} ({state.get('SubState')})")
    network = [(u, _unit_state(env, u)) for u in NETWORK_UNITS]
    loaded = [(u, s) for u, s in network if s and s.get("LoadState") == "loaded"]
    if loaded:
        checked += 1
        if not any(s.get("ActiveState") == "active" for _, s in loaded):
            names = ", ".join(u for u, _ in loaded)
            return (
                error(
                    "system.essential",
                    "Essential services",
                    "essential services are not running",
                    problems,
                )
                if problems
                else warn(
                    "system.essential",
                    "Essential services",
                    "no network service is running",
                    [f"none of the installed network services is active: {names}"],
                )
            )
    if problems:
        return error(
            "system.essential", "Essential services", "essential services are not running", problems
        )
    if not checked:
        return skip("system.essential", "Essential services", "service states could not be read")
    return ok(
        "system.essential", "Essential services", f"{checked} essential service group(s) running"
    )


def _packages_check(env: Environment, distro: Distro) -> CheckResult:
    if distro.family != "debian":
        return skip(
            "system.packages",
            "Package database",
            f"only Debian/Ubuntu-based systems are checked (detected family: {distro.family})",
        )
    try:
        completed = env.run(["dpkg", "--audit"])
    except ToolUnavailableError:
        return skip("system.packages", "Package database", missing_message("dpkg"))
    except LumeError as exc:
        return skip("system.packages", "Package database", str(exc))
    output = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if not completed.ok:
        return skip(
            "system.packages",
            "Package database",
            f"dpkg --audit failed (exit {completed.returncode})",
        )
    if output:
        return error(
            "system.packages",
            "Package database",
            "some packages are broken or half-configured",
            output[:6],
        )
    return ok("system.packages", "Package database", "no broken or half-configured packages")


def analyze(env: Environment, *, kernel_log: KernelLog | None = None) -> Report:
    """Run the general system checks (read-only). ``kernel_log`` is unused here."""
    del kernel_log
    distro = detect(env)
    kernel = (env.read_text("/proc/sys/kernel/osrelease") or "").strip()
    uptime = parse_uptime(env.read_text("/proc/uptime") or "")
    hostname = (env.read_text("/proc/sys/kernel/hostname") or "").strip()
    items = [
        ("Distribution", distro.pretty_name),
        ("Family", distro.family),
        ("Kernel", f"Linux {kernel}" if kernel else "unknown"),
        ("Architecture", env.machine()),
        ("Boot mode", "UEFI" if env.exists("/sys/firmware/efi") else "BIOS / not reported"),
        (
            "Init system",
            "systemd" if env.exists(SYSTEMD_RUNTIME_DIR) else "not systemd / container",
        ),
    ]
    if uptime is not None:
        items.append(("Uptime", format_duration(uptime)))
    if hostname:
        items.append(("Hostname", hostname))

    identification = (
        ok(
            "system.identification",
            "System identification",
            f"{distro.pretty_name}, kernel {kernel or '?'}",
        )
        if distro.pretty_name != "Linux" or kernel
        else skip("system.identification", "System identification", "os-release is not readable")
    )
    checks = (
        identification,
        _platform_check(distro),
        _privileges_check(env),
        _taint_check(env),
        _reboot_check(env, distro),
        _systemd_state(env),
        _essential_services_check(env),
        _packages_check(env, distro),
    )
    facts = (
        ("os", distro.pretty_name),
        ("kernel", f"Linux {kernel}" if kernel else ""),
        ("family", distro.family),
    )
    return Report("system", "System", (KeyValues("Operating system", tuple(items)),), checks, facts)
