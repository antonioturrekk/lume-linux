"""Runs all analysis domains and aggregates their results."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from lume import __version__
from lume.core import CheckResult, Status, skip, summarize
from lume.core.distro import Distro, detect
from lume.core.environment import Environment
from lume.core.kernel_log import KernelLog, read_kernel_log
from lume.core.log import get_logger
from lume.core.report import Report
from lume.diagnostics import system
from lume.hardware import analyze as analyze_hardware
from lume.network import analyze as analyze_network
from lume.performance import analyze as analyze_performance
from lume.storage import analyze as analyze_storage

_log = get_logger("diagnostics")
Progress = Callable[[str], None]


@dataclass(frozen=True, slots=True)
class Diagnosis:
    """Result of a complete diagnosis."""

    generated_at: str
    lume_version: str
    distro: Distro
    reports: tuple[Report, ...]
    offline: bool = False
    anonymized: bool = False

    @property
    def checks(self) -> tuple[CheckResult, ...]:
        """Every check, without repeating a check id that two domains both produced."""
        seen: set[str] = set()
        unique: list[CheckResult] = []
        for report in self.reports:
            for check in report.checks:
                if check.check_id:
                    if check.check_id in seen:
                        continue
                    seen.add(check.check_id)
                unique.append(check)
        return tuple(unique)

    @property
    def counts(self) -> dict[Status, int]:
        """Number of checks per status."""
        return summarize(self.checks)

    @property
    def problems(self) -> tuple[CheckResult, ...]:
        """Checks classified WARN or ERROR."""
        return tuple(c for c in self.checks if c.status in (Status.WARN, Status.ERROR))

    def report(self, report_id: str) -> Report | None:
        """The report of one domain."""
        return next((r for r in self.reports if r.id == report_id), None)

    def fact(self, key: str) -> str:
        """First non-empty fact called ``key`` across the reports."""
        for report in self.reports:
            value = report.fact(key)
            if value:
                return value
        return ""

    def to_dict(self) -> dict[str, object]:
        counts = {status.value: count for status, count in self.counts.items()}
        return {
            "generated_at": self.generated_at,
            "lume_version": self.lume_version,
            "anonymized": self.anonymized,
            "offline": self.offline,
            "system": {
                "distribution": self.distro.pretty_name,
                "id": self.distro.id,
                "version": self.distro.version_id,
                "family": self.distro.family,
            },
            "summary": counts,
            "reports": [r.to_dict() for r in self.reports],
        }


def _safe(report_id: str, title: str, build: Callable[[], Report]) -> Report:
    """Run one analyzer; a bug in it must not hide the other domains' results."""
    try:
        return build()
    except Exception:
        _log.exception("analysis of %s failed", report_id)
        return Report(
            report_id,
            title,
            (),
            (
                skip(
                    f"{report_id}.internal",
                    f"{title} checks",
                    "an internal error stopped these checks; details were written to the log file",
                ),
            ),
        )


def run_diagnosis(
    env: Environment,
    *,
    offline: bool = False,
    interval: float = 1.0,
    progress: Progress | None = None,
) -> Diagnosis:
    """Run every analysis domain (all read-only).

    Args:
        env: Machine access.
        offline: Skip active network probes.
        interval: Sampling window of the performance analysis, in seconds.
        progress: Called with a short message before each domain.
    """

    def step(message: str) -> None:
        if progress:
            progress(message)

    step("Reading the kernel log")
    kernel_log: KernelLog = read_kernel_log(env)
    reports: list[Report] = []

    step("Checking the system")
    reports.append(_safe("system", "System", lambda: system.analyze(env, kernel_log=kernel_log)))
    step("Identifying hardware")
    reports.append(
        _safe("hardware", "Hardware", lambda: analyze_hardware(env, kernel_log=kernel_log))
    )
    step("Testing the network")
    reports.append(_safe("network", "Network", lambda: analyze_network(env, offline=offline)))
    step("Measuring performance")
    reports.append(
        _safe(
            "performance",
            "Performance",
            lambda: analyze_performance(
                env, interval=interval, include_disk=False, kernel_log=kernel_log
            ),
        )
    )
    step("Analyzing storage")
    reports.append(_safe("storage", "Storage", lambda: analyze_storage(env, kernel_log=kernel_log)))

    return Diagnosis(
        generated_at=env.now().isoformat(timespec="seconds"),
        lume_version=__version__,
        distro=detect(env),
        reports=tuple(reports),
        offline=offline,
    )
