"""Diagnosis orchestration: runs every analysis domain and aggregates the results."""

from lume.diagnostics.engine import Diagnosis, run_diagnosis

__all__ = ["Diagnosis", "run_diagnosis"]
