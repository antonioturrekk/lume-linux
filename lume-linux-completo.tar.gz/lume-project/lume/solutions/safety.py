"""Safety screening of the command text stored in the solutions database.

The commands are only displayed, never executed. Even so, a solution that
suggests something destructive is rejected when the database is loaded, so a
tampered or careless entry cannot reach the user.
"""

from __future__ import annotations

import re


def _word(names: str) -> str:
    """Match a command name, but not the same letters inside a file name or option."""
    return rf"(?<![\w./-])(?:{names})(?![\w-])"


_DANGEROUS: tuple[tuple[re.Pattern[str], str], ...] = tuple(
    (re.compile(pattern, re.IGNORECASE), reason)
    for pattern, reason in (
        (_word("rm"), "deletes files"),
        (
            _word(r"mkfs[\w.]*|wipefs|shred|fdisk|sfdisk|cfdisk|parted|mkswap"),
            "changes disk layout",
        ),
        (_word("dd"), "raw disk writes"),
        (r">\s*/dev/(?!null\b)", "writes to a device"),
        (r"\bchmod\s+-\w*R", "recursive permission change"),
        (r"\bchown\s+-\w*R", "recursive ownership change"),
        (r":\(\)\s*\{", "fork bomb"),
        (r"\|\s*(sudo\s+)?(ba|z|da)?sh\b", "pipes data into a shell"),
        (r"\b(curl|wget)\b.*\|", "pipes a download into another command"),
        (_word("shutdown|reboot|poweroff|halt") + r"|\binit\s+[06]\b", "stops the machine"),
        (r"--no-preserve-root", "disables a safeguard"),
        (r"\bmv\s+/\s", "moves the root directory"),
        (r"\bsudo\s+su\b|\bsu\s+-", "opens a root shell"),
        (r"[\x00-\x08\x0b-\x1f]", "control characters"),
    )
)


def dangerous_reason(command: str) -> str | None:
    """Return why ``command`` is unsafe to suggest, or ``None`` if it is acceptable."""
    if "\n" in command or "\r" in command:
        return "multi-line commands are not allowed"
    for pattern, reason in _DANGEROUS:
        if pattern.search(command):
            return reason
    return None
