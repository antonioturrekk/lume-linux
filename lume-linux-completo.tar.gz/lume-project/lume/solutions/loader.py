"""Loading and validation of the solutions database.

Every entry is validated before it can be shown: strict schema, known keys only,
unique ids, valid compatibility expressions and safe command text. Invalid
entries are rejected (and reported), they are never presented.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path

from lume.core.distro import Distro, is_valid_spec
from lume.core.exceptions import LumeError
from lume.core.log import get_logger
from lume.solutions.models import RISK_LEVELS, Solution, Step
from lume.solutions.safety import dangerous_reason

SCHEMA_VERSION = 1
_ID_RE = re.compile(r"^SOL-\d{4}$")
_CHECK_ID_RE = re.compile(r"^[a-z_]+\.[a-z_]+$")
_TOP_KEYS = {
    "id", "name", "description", "symptoms", "causes", "diagnostic_commands",
    "solution", "compatible_distros", "risk", "related_checks",
}  # fmt: skip
_STEP_KEYS = {"description", "command", "needs_root"}
_log = get_logger("solutions")


class SolutionError(LumeError):
    """The solutions database or one of its entries is invalid."""


def _text(value: object, field_name: str, *, maximum: int = 600) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SolutionError(f"'{field_name}' must be a non-empty string")
    if len(value) > maximum:
        raise SolutionError(f"'{field_name}' is longer than {maximum} characters")
    return value.strip()


def _text_list(value: object, field_name: str, *, allow_empty: bool = False) -> tuple[str, ...]:
    if not isinstance(value, list) or (not value and not allow_empty):
        raise SolutionError(f"'{field_name}' must be a non-empty list")
    return tuple(_text(item, f"{field_name}[]", maximum=300) for item in value)


def _command(value: str, field_name: str) -> str:
    reason = dangerous_reason(value)
    if reason:
        raise SolutionError(f"unsafe command in '{field_name}' ({reason}): {value!r}")
    return value


def _step(raw: object) -> Step:
    if not isinstance(raw, dict):
        raise SolutionError("each step must be an object")
    unknown = set(raw) - _STEP_KEYS
    if unknown:
        raise SolutionError(f"unknown step field(s): {', '.join(sorted(unknown))}")
    description = _text(raw.get("description"), "step.description")
    command = raw.get("command")
    needs_root = raw.get("needs_root", False)
    if not isinstance(needs_root, bool):
        raise SolutionError("'needs_root' must be true or false")
    if command is None:
        if needs_root:
            raise SolutionError("a step without a command cannot need root")
        return Step(description)
    cmd = _command(_text(command, "step.command", maximum=300), "step.command")
    if needs_root != cmd.startswith("sudo "):
        raise SolutionError(f"'needs_root' must match the use of sudo in: {cmd!r}")
    return Step(description, cmd, needs_root)


def validate_solution(raw: object) -> Solution:
    """Validate one raw entry and return it as a :class:`Solution`."""
    if not isinstance(raw, dict):
        raise SolutionError("a solution must be an object")
    unknown = set(raw) - _TOP_KEYS
    if unknown:
        raise SolutionError(f"unknown field(s): {', '.join(sorted(unknown))}")
    solution_id = raw.get("id")
    if not isinstance(solution_id, str) or not _ID_RE.match(solution_id):
        raise SolutionError("'id' must look like SOL-0001")
    body = raw.get("solution")
    if not isinstance(body, dict) or not isinstance(body.get("steps"), list) or not body["steps"]:
        raise SolutionError("'solution' needs a summary and at least one step")
    distros = _text_list(raw.get("compatible_distros"), "compatible_distros")
    bad = [d for d in distros if not is_valid_spec(d)]
    if bad:
        raise SolutionError(f"invalid compatibility expression(s): {', '.join(bad)}")
    risk = raw.get("risk")
    if risk not in RISK_LEVELS:
        raise SolutionError(f"'risk' must be one of {', '.join(RISK_LEVELS)}")
    related = _text_list(raw.get("related_checks", []), "related_checks", allow_empty=True)
    bad_ids = [c for c in related if not _CHECK_ID_RE.match(c)]
    if bad_ids:
        raise SolutionError(f"invalid check id(s): {', '.join(bad_ids)}")
    diagnostics = tuple(
        _command(c, "diagnostic_commands")
        for c in _text_list(
            raw.get("diagnostic_commands", []), "diagnostic_commands", allow_empty=True
        )
    )
    return Solution(
        id=solution_id,
        name=_text(raw.get("name"), "name", maximum=100),
        description=_text(raw.get("description"), "description"),
        symptoms=_text_list(raw.get("symptoms"), "symptoms"),
        causes=_text_list(raw.get("causes"), "causes"),
        diagnostic_commands=diagnostics,
        summary=_text(body.get("summary"), "solution.summary"),
        steps=tuple(_step(s) for s in body["steps"]),
        compatible_distros=distros,
        risk=str(risk),
        related_checks=related,
    )


@dataclass(frozen=True, slots=True)
class SolutionBase:
    """The validated knowledge base."""

    solutions: tuple[Solution, ...]
    rejected: tuple[tuple[str, str], ...] = field(default_factory=tuple)

    def get(self, solution_id: str) -> Solution | None:
        """Solution by id (case-insensitive)."""
        wanted = solution_id.strip().upper()
        return next((s for s in self.solutions if s.id == wanted), None)

    def for_distro(self, distro: Distro) -> tuple[Solution, ...]:
        """Solutions verified as compatible with ``distro``."""
        return tuple(s for s in self.solutions if distro.matches_any(s.compatible_distros))

    def related_to(self, check_ids: Iterable[str], distro: Distro) -> tuple[Solution, ...]:
        """Compatible solutions linked to any of the given check ids."""
        wanted = set(check_ids)
        return tuple(s for s in self.for_distro(distro) if wanted & set(s.related_checks))

    def search(self, query: str, distro: Distro | None = None) -> tuple[Solution, ...]:
        """Solutions whose text contains every word of ``query``, best match first."""
        words = [w for w in re.split(r"\W+", query.lower()) if w]
        if not words:
            return ()
        pool = self.for_distro(distro) if distro is not None else self.solutions
        scored: list[tuple[int, Solution]] = []
        for solution in pool:
            haystack = " ".join(
                (
                    solution.id,
                    solution.name,
                    solution.description,
                    *solution.symptoms,
                    *solution.causes,
                )
            ).lower()
            if all(word in haystack for word in words):
                title_hits = sum(word in solution.name.lower() for word in words)
                scored.append((-title_hits, solution))
        return tuple(s for _, s in sorted(scored, key=lambda pair: (pair[0], pair[1].id)))


def parse_database(data: object) -> SolutionBase:
    """Validate a decoded database; invalid entries are rejected one by one."""
    if not isinstance(data, dict) or data.get("schema_version") != SCHEMA_VERSION:
        raise SolutionError(f"the database must be an object with schema_version {SCHEMA_VERSION}")
    entries = data.get("solutions")
    if not isinstance(entries, list):
        raise SolutionError("'solutions' must be a list")
    accepted: list[Solution] = []
    rejected: list[tuple[str, str]] = []
    seen: set[str] = set()
    for index, raw in enumerate(entries):
        label = (
            raw.get("id", f"entry #{index + 1}") if isinstance(raw, dict) else f"entry #{index + 1}"
        )
        try:
            solution = validate_solution(raw)
            if solution.id in seen:
                raise SolutionError(f"duplicate id {solution.id}")
        except SolutionError as exc:
            rejected.append((str(label), str(exc)))
            _log.warning("solution %s rejected: %s", label, exc)
            continue
        seen.add(solution.id)
        accepted.append(solution)
    return SolutionBase(tuple(accepted), tuple(rejected))


def load_file(path: Path) -> SolutionBase:
    """Load and validate a database file."""
    try:
        text = path.read_text(encoding="utf-8")
        return parse_database(json.loads(text))
    except (OSError, ValueError) as exc:
        raise SolutionError(f"cannot read the solutions database {path}: {exc}") from exc


def load_builtin() -> SolutionBase:
    """Load the database shipped with LUME."""
    resource = resources.files("lume.solutions").joinpath("data/solutions.json")
    try:
        return parse_database(json.loads(resource.read_text(encoding="utf-8")))
    except (OSError, ValueError) as exc:
        raise SolutionError(f"cannot read the built-in solutions database: {exc}") from exc
