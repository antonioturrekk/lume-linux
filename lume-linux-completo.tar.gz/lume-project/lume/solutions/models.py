"""Data model of the solutions knowledge base."""

from __future__ import annotations

from dataclasses import dataclass

RISK_LEVELS = ("low", "medium", "high")


@dataclass(frozen=True, slots=True)
class Step:
    """One step of a recommended solution.

    Commands are **text shown to the user**. LUME never executes them.
    """

    description: str
    command: str | None = None
    needs_root: bool = False

    def to_dict(self) -> dict[str, object]:
        return {
            "description": self.description,
            "command": self.command,
            "needs_root": self.needs_root,
        }


@dataclass(frozen=True, slots=True)
class Solution:
    """A known problem with its recommended solution."""

    id: str
    name: str
    description: str
    symptoms: tuple[str, ...]
    causes: tuple[str, ...]
    diagnostic_commands: tuple[str, ...]
    summary: str
    steps: tuple[Step, ...]
    compatible_distros: tuple[str, ...]
    risk: str
    related_checks: tuple[str, ...] = ()

    @property
    def needs_root(self) -> bool:
        """Whether any step needs administrator rights."""
        return any(step.needs_root for step in self.steps)

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "symptoms": list(self.symptoms),
            "causes": list(self.causes),
            "diagnostic_commands": list(self.diagnostic_commands),
            "solution": {"summary": self.summary, "steps": [s.to_dict() for s in self.steps]},
            "compatible_distros": list(self.compatible_distros),
            "risk": self.risk,
            "related_checks": list(self.related_checks),
        }
