"""Visual identity of the LUME terminal interface.

Dark-terminal friendly: amber brand color (light, discovery), muted gray for
secondary text and the usual green/yellow/red for OK/WARN/ERROR.
"""

from __future__ import annotations

from typing import IO

from rich.console import Console
from rich.text import Text
from rich.theme import Theme

from lume.core import Status

BRAND_COLOR = "#ffb000"
TAGLINE = "Linux Utility & Monitoring Engine"

THEME = Theme(
    {
        "brand": f"bold {BRAND_COLOR}",
        "muted": "grey62",
        "heading": "bold",
        "ok": "bold green",
        "warn": "bold yellow",
        "error": "bold red",
    }
)

STATUS_STYLES: dict[Status, str] = {
    Status.OK: "ok",
    Status.WARN: "warn",
    Status.ERROR: "error",
    Status.SKIP: "muted",
}


def make_console(
    *,
    stderr: bool = False,
    file: IO[str] | None = None,
    width: int | None = None,
) -> Console:
    """Create a console with the LUME theme.

    Colors are disabled automatically when output is not a terminal or when
    ``NO_COLOR`` is set (handled by Rich).
    """
    return Console(theme=THEME, stderr=stderr, file=file, width=width, highlight=False)


def _utf8(console: Console) -> bool:
    return "utf" in console.encoding


def symbol(console: Console) -> str:
    """Brand symbol, with an ASCII fallback for non-UTF-8 terminals."""
    return "✦" if _utf8(console) else "*"


def arrow(console: Console) -> str:
    """Marker for evidence lines, with an ASCII fallback."""
    return "↳" if _utf8(console) else "->"


def print_banner(console: Console) -> None:
    """Print the LUME banner."""
    console.print(Text(f"{symbol(console)} LUME", style="brand"))
    console.print(Text(TAGLINE, style="muted"))
    console.rule(style="muted")
