"""Process exit codes returned by the ``lume`` command."""

from enum import IntEnum


class ExitCode(IntEnum):
    """Exit codes. Stable: scripts may rely on them."""

    OK = 0
    ERROR = 1  # expected or unexpected failure while running a command
    USAGE = 2  # invalid command line (same code argparse uses)
    NOT_IMPLEMENTED = 3  # command exists but is not available yet
    PROBLEMS = 4  # the analysis finished and identified at least one ERROR
    INTERRUPTED = 130  # Ctrl+C (128 + SIGINT)
