"""Interactive menu shown when ``lume`` is run without arguments."""

from __future__ import annotations

import argparse
from collections.abc import Callable, Sequence

from rich.text import Text

from lume.cli.commands import Command
from lume.cli.context import AppContext
from lume.cli.exit_codes import ExitCode
from lume.cli.registry import run_command
from lume.cli.render import command_table
from lume.cli.theme import print_banner

QUIT_WORDS = frozenset({"q", "quit", "exit", "0"})


def resolve_choice(raw: str, commands: Sequence[Command]) -> Command | None:
    """Map what the user typed (a number or a command name) to a command."""
    choice = raw.strip().lower()
    if choice.isdigit():
        index = int(choice)
        return commands[index - 1] if 1 <= index <= len(commands) else None
    return next((command for command in commands if command.name == choice), None)


def _default_args(ctx: AppContext, name: str) -> argparse.Namespace:
    """Arguments of a command with all its defaults (as if typed with no options)."""
    args = ctx.command_parsers[name].parse_args([])
    args.command = name
    return args


def run_menu(ctx: AppContext, input_fn: Callable[[str], str] | None = None) -> int:
    """Show the menu until the user quits.

    Args:
        ctx: Application context.
        input_fn: Function used to read input (defaults to the console prompt);
            injectable for tests.

    Returns:
        :attr:`ExitCode.OK` (also on Ctrl+C / end of input).
    """
    read = input_fn or ctx.console.input
    console = ctx.console
    while True:
        print_banner(console)
        console.print(command_table(ctx.commands, numbered=True))
        console.print(Text("q  quit", style="muted"))
        console.print()
        try:
            raw = read("Select an option: ")
        except (EOFError, KeyboardInterrupt):
            console.print()
            return ExitCode.OK

        if raw.strip().lower() in QUIT_WORDS:
            return ExitCode.OK
        command = resolve_choice(raw, ctx.commands)
        if command is None:
            console.print(Text(f"Invalid option: {raw.strip()!r}", style="warn"))
            continue

        console.print()
        run_command(command.name, _default_args(ctx, command.name), ctx)
        console.print()
        try:
            read("Press Enter to continue...")
        except (EOFError, KeyboardInterrupt):
            console.print()
            return ExitCode.OK
