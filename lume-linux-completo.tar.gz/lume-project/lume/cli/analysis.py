"""Handlers of the analysis commands: diagnose, hardware, network, performance,
storage, solutions and report."""

from __future__ import annotations

import argparse
from collections.abc import Callable
from contextlib import AbstractContextManager, nullcontext
from pathlib import Path

from rich.console import Console
from rich.table import Table
from rich.text import Text

from lume.cli.context import AppContext
from lume.cli.exit_codes import ExitCode
from lume.cli.render import render_checks, render_report, render_section, render_summary
from lume.cli.theme import arrow, print_banner
from lume.core import Status, paths
from lume.core.distro import detect
from lume.core.models import CheckResult
from lume.core.report import KeyValues, Report
from lume.database import HistoryStore, compare
from lume.diagnostics import Diagnosis, run_diagnosis
from lume.hardware import analyze as analyze_hardware
from lume.network import analyze as analyze_network
from lume.performance import analyze as analyze_performance
from lume.reports import (
    FORMATS,
    Anonymizer,
    ReportWriteError,
    default_filename,
    generate,
    write_report,
)
from lume.solutions import Solution, SolutionBase, load_builtin
from lume.storage import analyze as analyze_storage

RISK_STYLES = {"low": "ok", "medium": "warn", "high": "error"}


# ---------- argument helpers ----------
def _interval(value: str) -> float:
    try:
        seconds = float(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(f"not a number: {value!r}") from exc
    if not 0.2 <= seconds <= 10:
        raise argparse.ArgumentTypeError("must be between 0.2 and 10 seconds")
    return seconds


def _add_offline(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--offline",
        action="store_true",
        help="do not run active network probes (TCP connection, name resolution)",
    )


def _add_interval(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--interval",
        type=_interval,
        default=1.0,
        metavar="SECONDS",
        help="sampling window for CPU measurements (default: 1)",
    )


def configure_diagnose(parser: argparse.ArgumentParser) -> None:
    _add_offline(parser)
    _add_interval(parser)
    parser.add_argument(
        "--no-history",
        action="store_true",
        help="do not store this run (and do not compare with the previous one)",
    )


def configure_network(parser: argparse.ArgumentParser) -> None:
    _add_offline(parser)


def configure_performance(parser: argparse.ArgumentParser) -> None:
    _add_interval(parser)


def configure_solutions(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("solution_id", nargs="?", metavar="ID", help="show one solution (SOL-0001)")
    parser.add_argument("-s", "--search", metavar="TEXT", help="search by symptom or keyword")
    parser.add_argument(
        "--all", action="store_true", help="include solutions not verified for this distribution"
    )


def configure_report(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "-f", "--format", choices=FORMATS, default="html", help="report format (default: html)"
    )
    parser.add_argument(
        "-o", "--output", metavar="FILE", help="file to create (default: lume-report-<date>.<ext>)"
    )
    parser.add_argument(
        "--anonymize", action="store_true", help="remove IP/MAC addresses, host name"
    )
    parser.add_argument("--stdout", action="store_true", help="print the report instead of a file")
    parser.add_argument("--force", action="store_true", help="replace the output file if it exists")
    _add_offline(parser)


# ---------- shared helpers ----------
def _progress(ctx: AppContext) -> tuple[AbstractContextManager[object], Callable[[str], None]]:
    """A spinner (only on terminals) and the callback that updates its message."""
    if not ctx.console.is_terminal:
        return nullcontext(), lambda message: None
    status = ctx.console.status("Starting...", spinner="dots")
    return status, lambda message: status.update(f"{message}...")


def _exit_for(checks: tuple[CheckResult, ...] | list[CheckResult]) -> int:
    has_error = any(check.status is Status.ERROR for check in checks)
    return int(ExitCode.PROBLEMS if has_error else ExitCode.OK)


def _diagnose(ctx: AppContext, *, offline: bool, interval: float) -> Diagnosis:
    spinner, update = _progress(ctx)
    with spinner:
        return run_diagnosis(ctx.env, offline=offline, interval=interval, progress=update)


def _solution_base(ctx: AppContext) -> SolutionBase:
    base = load_builtin()
    if base.rejected:
        ctx.err_console.print(
            Text(
                f"{len(base.rejected)} solution(s) failed validation and are not shown.",
                style="warn",
            )
        )
    return base


# ---------- diagnose ----------
def _overview(diagnosis: Diagnosis) -> KeyValues:
    wanted = (
        ("Operating System", "os"),
        ("Kernel", "kernel"),
        ("CPU", "cpu"),
        ("Memory", "memory"),
        ("Graphics", "gpu"),
        ("Root filesystem", "root_usage"),
    )
    items = tuple((label, diagnosis.fact(key)) for label, key in wanted if diagnosis.fact(key))
    return KeyValues("System Analysis", items)


def _print_suggestions(ctx: AppContext, diagnosis: Diagnosis) -> None:
    base = _solution_base(ctx)
    ids = [check.check_id for check in diagnosis.problems if check.check_id]
    related = base.related_to(ids, diagnosis.distro)
    if not related:
        return
    table = Table.grid(padding=(0, 2))
    for solution in related:
        table.add_row(
            Text(solution.id, style="brand"),
            Text(solution.name),
            Text(f"risk: {solution.risk}", style=RISK_STYLES[solution.risk]),
        )
    ctx.console.print()
    ctx.console.print(Text("Suggested solutions", style="heading"))
    ctx.console.print(table)
    ctx.console.print(Text("Details: lume solutions <ID>", style="muted"))


def _print_history(ctx: AppContext, diagnosis: Diagnosis) -> None:
    store = HistoryStore(paths.database_file())
    previous = store.latest()
    store.record(diagnosis)
    if previous is None:
        return
    delta = compare(previous, diagnosis)
    when = previous.created_at[:16].replace("T", " ")
    console = ctx.console
    console.print()
    if not delta.changed:
        console.print(Text(f"No changes since the previous diagnosis ({when}).", style="muted"))
        return
    console.print(Text(f"Since the previous diagnosis ({when}):", style="heading"))
    for label, names, style in (
        ("new", delta.new_problems, "warn"),
        ("worse", delta.worsened, "error"),
        ("resolved", delta.resolved, "ok"),
    ):
        if names:
            console.print(Text(f"  {label}: {', '.join(names)}", style=style))


def cmd_diagnose(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume diagnose``: full diagnosis of the machine."""
    diagnosis = _diagnose(
        ctx, offline=bool(getattr(args, "offline", False)), interval=getattr(args, "interval", 1.0)
    )
    console = ctx.console
    print_banner(console)
    render_section(console, _overview(diagnosis))
    console.print(Text("SYSTEM STATUS", style="heading"))
    for report in diagnosis.reports:
        console.print()
        console.print(Text(report.title, style="brand"))
        shown = [c for c in report.checks if c in diagnosis.checks]
        render_checks(console, shown)
    render_summary(console, diagnosis.checks)
    _print_suggestions(ctx, diagnosis)
    if not getattr(args, "no_history", False):
        _print_history(ctx, diagnosis)
    return _exit_for(diagnosis.checks)


# ---------- single-domain commands ----------
def _run_domain(ctx: AppContext, title: str, build: Callable[[], Report]) -> int:
    spinner, update = _progress(ctx)
    with spinner:
        update(title)
        report = build()
    render_report(ctx.console, report)
    return _exit_for(report.checks)


def cmd_hardware(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume hardware``."""
    return _run_domain(ctx, "Identifying hardware", lambda: analyze_hardware(ctx.env))


def cmd_network(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume network``."""
    offline = bool(getattr(args, "offline", False))
    return _run_domain(
        ctx, "Testing the network", lambda: analyze_network(ctx.env, offline=offline)
    )


def cmd_performance(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume performance``."""
    interval = getattr(args, "interval", 1.0)
    return _run_domain(
        ctx, "Measuring performance", lambda: analyze_performance(ctx.env, interval=interval)
    )


def cmd_storage(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume storage``."""
    return _run_domain(ctx, "Analyzing storage", lambda: analyze_storage(ctx.env))


# ---------- solutions ----------
def _risk_text(solution: Solution) -> Text:
    return Text(f"risk: {solution.risk}", style=RISK_STYLES[solution.risk])


def _list_solutions(ctx: AppContext, solutions: tuple[Solution, ...], title: str) -> None:
    console = ctx.console
    console.print(Text(title, style="heading"))
    if not solutions:
        console.print(Text("No solutions found.", style="muted"))
        return
    table = Table.grid(padding=(0, 2))
    for solution in solutions:
        table.add_row(Text(solution.id, style="brand"), Text(solution.name), _risk_text(solution))
    console.print(table)
    console.print()
    console.print(Text("Details: lume solutions <ID>", style="muted"))


def _bullets(console: Console, heading: str, items: tuple[str, ...]) -> None:
    console.print(Text(heading, style="heading"))
    for item in items:
        console.print(Text(f"  • {item}"))
    console.print()


def _show_solution(ctx: AppContext, solution: Solution, *, verified: bool) -> None:
    console = ctx.console
    marker = arrow(console)
    console.print(Text.assemble((solution.id, "brand"), "  ", (solution.name, "heading")))
    console.print(_risk_text(solution))
    if not verified:
        console.print(
            Text("Not verified for this distribution; shown for reference.", style="warn")
        )
    console.print()
    console.print(Text(solution.description))
    console.print()
    _bullets(console, "Symptoms", solution.symptoms)
    _bullets(console, "Possible causes", solution.causes)
    if solution.diagnostic_commands:
        console.print(Text("Diagnostic commands", style="heading"))
        for command in solution.diagnostic_commands:
            console.print(Text(f"  $ {command}", style="brand"))
        console.print()
    console.print(Text("Recommended solution", style="heading"))
    console.print(Text(solution.summary, style="muted"))
    for number, step in enumerate(solution.steps, start=1):
        console.print(Text(f"  {number}. {step.description}"))
        if step.command:
            console.print(Text(f"     $ {step.command}", style="brand"))
    console.print()
    console.print(Text("Compatible with: " + ", ".join(solution.compatible_distros), style="muted"))
    console.print(
        Text(
            f"{marker} LUME does not run these commands. Review each one and run it yourself.",
            style="muted",
        )
    )


def cmd_solutions(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume solutions [ID] [--search TEXT] [--all]``."""
    base = _solution_base(ctx)
    distro = detect(ctx.env)
    show_all = bool(getattr(args, "all", False))
    solution_id: str | None = getattr(args, "solution_id", None)
    query: str | None = getattr(args, "search", None)

    if solution_id:
        solution = base.get(solution_id)
        if solution is None:
            ctx.err_console.print(Text(f"No solution called {solution_id}.", style="error"))
            return int(ExitCode.USAGE)
        compatible = distro.matches_any(solution.compatible_distros)
        if not compatible and not show_all:
            ctx.err_console.print(
                Text(
                    f"{solution.id} is not verified for {distro.pretty_name}. "
                    "Use --all to see it anyway.",
                    style="warn",
                ),
                soft_wrap=True,
            )
            return int(ExitCode.USAGE)
        _show_solution(ctx, solution, verified=compatible)
        return int(ExitCode.OK)

    if query:
        found = base.search(query, None if show_all else distro)
        _list_solutions(ctx, found, f"Solutions matching '{query}'")
        return int(ExitCode.OK)

    pool = base.solutions if show_all else base.for_distro(distro)
    scope = "all solutions" if show_all else f"solutions for {distro.pretty_name}"
    _list_solutions(ctx, pool, f"Known problems: {scope} ({len(pool)})")
    return int(ExitCode.OK)


# ---------- report ----------
def cmd_report(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume report``: export a diagnosis."""
    report_format: str = getattr(args, "format", "html")
    anonymize = bool(getattr(args, "anonymize", False))
    diagnosis = _diagnose(ctx, offline=bool(getattr(args, "offline", False)), interval=1.0)
    if anonymize:
        hostname = ctx.env.read_text("/proc/sys/kernel/hostname") or ""
        diagnosis = Anonymizer(hostname).diagnosis(diagnosis)
    content = generate(diagnosis, report_format, _solution_base(ctx))

    if getattr(args, "stdout", False):
        ctx.console.file.write(content)
        return int(ExitCode.OK)

    output: str | None = getattr(args, "output", None)
    path = Path(output) if output else Path.cwd() / default_filename(diagnosis, report_format)
    try:
        written = write_report(content, path, overwrite=bool(getattr(args, "force", False)))
    except ReportWriteError as exc:
        ctx.err_console.print(Text(f"Error: {exc}", style="error"), soft_wrap=True)
        return int(ExitCode.ERROR)

    ctx.console.print(Text(f"Report saved to {written}", style="ok"), soft_wrap=True)
    if not anonymize:
        ctx.console.print(
            Text(
                "It may contain IP/MAC addresses and the host name. "
                "Use --anonymize before sharing it.",
                style="muted",
            )
        )
    return int(ExitCode.OK)


__all__ = [
    "cmd_diagnose",
    "cmd_hardware",
    "cmd_network",
    "cmd_performance",
    "cmd_report",
    "cmd_solutions",
    "cmd_storage",
    "configure_diagnose",
    "configure_network",
    "configure_performance",
    "configure_report",
    "configure_solutions",
]
