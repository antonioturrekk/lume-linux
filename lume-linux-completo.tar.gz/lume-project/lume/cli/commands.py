"""Command definition used by the registry, parser and menu."""

from __future__ import annotations

import argparse
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lume.cli.context import AppContext

Handler = Callable[[argparse.Namespace, "AppContext"], int]
Configure = Callable[[argparse.ArgumentParser], None]


@dataclass(frozen=True, slots=True)
class Command:
    """A ``lume`` subcommand.

    A command without a ``handler`` is registered but not implemented yet: it
    is listed in help and menu, and running it reports honestly that it is not
    available, instead of pretending to work. ``planned_phase`` then says when
    it is expected.

    Attributes:
        name: Subcommand name (``lume <name>``).
        summary: One-line description shown in help and menu.
        handler: Function that runs the command and returns an exit code.
        planned_phase: Development phase that will implement it.
        configure: Optional hook to add command-specific arguments.
    """

    name: str
    summary: str
    handler: Handler | None = None
    planned_phase: int | None = None
    configure: Configure | None = None

    def __post_init__(self) -> None:
        if not self.name or " " in self.name:
            raise ValueError(f"invalid command name: {self.name!r}")
        if self.handler is None and self.planned_phase is None:
            raise ValueError(f"command '{self.name}' needs a handler or a planned_phase")

    @property
    def implemented(self) -> bool:
        """Whether the command is available."""
        return self.handler is not None
