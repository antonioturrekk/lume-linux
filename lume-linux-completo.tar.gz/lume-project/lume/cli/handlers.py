"""Handlers of the commands that are already implemented."""

from __future__ import annotations

import argparse
import platform

from rich.table import Table
from rich.text import Text

from lume import __version__
from lume.cli.context import AppContext
from lume.cli.exit_codes import ExitCode
from lume.cli.render import print_main_help
from lume.cli.theme import print_banner


def cmd_version(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume version``: show version and runtime information."""
    print_banner(ctx.console)
    info = Table.grid(padding=(0, 2))
    info.add_column(style="muted", no_wrap=True)
    info.add_column()
    info.add_row("Version", Text(__version__))
    info.add_row("Python", Text(platform.python_version()))
    info.add_row("Platform", Text(platform.platform()))
    ctx.console.print(info)
    return ExitCode.OK


def configure_help(parser: argparse.ArgumentParser) -> None:
    """Add the optional ``command`` argument of ``lume help``."""
    parser.add_argument("topic", nargs="?", metavar="command", help="command to describe")


def cmd_help(args: argparse.Namespace, ctx: AppContext) -> int:
    """``lume help [command]``: show general help or help for one command."""
    topic: str | None = getattr(args, "topic", None)
    if topic is None:
        print_main_help(ctx.console, ctx.commands)
        return ExitCode.OK
    parser = ctx.command_parsers.get(topic)
    if parser is None:
        known = ", ".join(command.name for command in ctx.commands)
        message = f"Unknown command: {topic}. Available commands: {known}"
        ctx.err_console.print(Text(message, style="error"), soft_wrap=True)
        return ExitCode.USAGE
    parser.print_help(ctx.console.file)
    return ExitCode.OK
