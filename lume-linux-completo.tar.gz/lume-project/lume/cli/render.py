"""Rendering helpers for the terminal.

Text coming from the system (device names, hostnames, error messages) is always
wrapped in :class:`rich.text.Text` so characters such as ``[`` can never be
interpreted as Rich markup.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence

from rich.console import Console
from rich.table import Table
from rich.text import Text

from lume.cli.commands import Command
from lume.cli.theme import STATUS_STYLES, arrow, print_banner
from lume.core import CheckResult, Status, summarize
from lume.core.report import KeyValues, Report, Section

_LABEL_WIDTH = len("[ERROR]")


def _plural(count: int, word: str) -> str:
    return f"{count} {word}{'' if count == 1 else 's'}"


def summary_line(counts: Mapping[Status, int]) -> str:
    """One-line summary such as ``2 warnings detected.``."""
    parts: list[str] = []
    if errors := counts.get(Status.ERROR, 0):
        parts.append(_plural(errors, "error"))
    if warnings := counts.get(Status.WARN, 0):
        parts.append(_plural(warnings, "warning"))
    if not parts:
        return "No problems detected."
    return ", ".join(parts) + " detected."


def render_checks(
    console: Console, results: Sequence[CheckResult], *, show_evidence: bool = False
) -> None:
    """Print check results as ``[OK]``/``[WARN]``/``[ERROR]``/``[SKIP]`` lines.

    Evidence is always shown for WARN and ERROR (it is mandatory for them) and
    for the other statuses only when ``show_evidence`` is true.
    """
    marker = arrow(console)
    grid = Table.grid(padding=(0, 2))
    grid.add_column(no_wrap=True)
    grid.add_column()
    grid.add_column()
    for result in results:
        label = Text(
            f"[{result.status.value}]".ljust(_LABEL_WIDTH),
            style=STATUS_STYLES[result.status],
        )
        grid.add_row(label, Text(result.name), Text(result.summary, style="muted"))
        if result.status in (Status.WARN, Status.ERROR) or show_evidence:
            for item in result.evidence:
                grid.add_row("", "", Text(f"{marker} {item}", style="muted"))
    console.print(grid)


def render_summary(console: Console, results: Sequence[CheckResult]) -> None:
    """Print the closing line, e.g. ``2 warnings detected.``."""
    counts = summarize(results)
    if counts[Status.ERROR]:
        style = "error"
    elif counts[Status.WARN]:
        style = "warn"
    else:
        style = "ok"
    console.rule(style="muted")
    console.print(Text(summary_line(counts), style=style))
    skipped = counts[Status.SKIP]
    if skipped:
        console.print(
            Text(f"{_plural(skipped, 'check')} could not run (marked [SKIP]).", style="muted")
        )


def render_results(
    console: Console,
    results: Sequence[CheckResult],
    *,
    title: str = "SYSTEM STATUS",
    show_evidence: bool = False,
) -> None:
    """Print a titled list of results followed by the summary line."""
    console.print(Text(title, style="heading"))
    console.print()
    if not results:
        console.print(Text("No checks were run.", style="muted"))
        return
    render_checks(console, results, show_evidence=show_evidence)
    render_summary(console, results)


def render_section(console: Console, section: Section) -> None:
    """Print a key/value block or a table."""
    console.print(Text(section.title, style="heading"))
    if isinstance(section, KeyValues):
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="muted", no_wrap=True)
        grid.add_column()
        for key, value in section.items:
            grid.add_row(Text(key), Text(value))
        console.print(grid)
    else:
        table = Table(box=None, header_style="brand", padding=(0, 2, 0, 0), pad_edge=False)
        for column in section.columns:
            table.add_column(Text(column), overflow="fold")
        for row in section.rows:
            table.add_row(*(Text(cell) for cell in row))
        console.print(table)
    console.print()


def render_report(console: Console, report: Report) -> None:
    """Print one domain report: its details, then its checks and the summary."""
    print_banner(console)
    console.print(Text(report.title.upper(), style="heading"))
    console.print()
    for section in report.sections:
        render_section(console, section)
    console.print(Text("CHECKS", style="heading"))
    console.print()
    render_checks(console, report.checks)
    render_summary(console, report.checks)


def command_table(commands: Sequence[Command], *, numbered: bool = False) -> Table:
    """Table listing commands; unavailable ones are marked ``soon``."""
    table = Table.grid(padding=(0, 2))
    if numbered:
        table.add_column(justify="right", no_wrap=True)
    table.add_column(no_wrap=True)
    table.add_column()
    table.add_column(no_wrap=True)
    for index, command in enumerate(commands, start=1):
        row: list[Text] = []
        if numbered:
            row.append(Text(str(index), style="brand"))
        row.append(Text(command.name, style="brand"))
        row.append(Text(command.summary))
        row.append(Text("" if command.implemented else "(soon)", style="muted"))
        table.add_row(*row)
    return table


def print_main_help(console: Console, commands: Sequence[Command]) -> None:
    """Print the main help screen."""
    print_banner(console)
    console.print(Text("Usage: lume [options] [command]"))
    console.print()
    console.print(Text("Commands", style="heading"))
    console.print(command_table(commands))
    console.print()
    console.print(Text("Options", style="heading"))
    options = Table.grid(padding=(0, 2))
    options.add_column(no_wrap=True)
    options.add_column()
    options.add_row(Text("-h, --help", style="brand"), Text("Show this help and exit"))
    options.add_row(Text("--version", style="brand"), Text("Show the version and exit"))
    options.add_row(Text("--no-color", style="brand"), Text("Disable colored output"))
    options.add_row(Text("-v, --verbose", style="brand"), Text("Write debug details to the log"))
    console.print(options)
    console.print()
    console.print(Text("Run 'lume' without arguments for the interactive menu.", style="muted"))
