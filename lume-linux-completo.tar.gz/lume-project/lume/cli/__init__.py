"""Terminal interface built on Rich: commands and interactive menu."""
