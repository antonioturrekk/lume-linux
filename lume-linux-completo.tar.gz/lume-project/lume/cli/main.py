"""Entry point of the ``lume`` command."""

from __future__ import annotations

import logging
import sys
from collections.abc import Callable, Sequence

from rich.console import Console
from rich.text import Text

from lume.cli.commands import Command
from lume.cli.context import AppContext
from lume.cli.exit_codes import ExitCode
from lume.cli.menu import run_menu
from lume.cli.parser import build_parser
from lume.cli.registry import COMMANDS, run_command
from lume.cli.render import print_main_help
from lume.cli.theme import make_console
from lume.core import LumeError, paths
from lume.core.environment import Environment, SystemEnvironment
from lume.core.log import get_logger, setup_logging


def _exit_code(code: object) -> int:
    """Convert a ``SystemExit`` code into an integer exit code."""
    if code is None:
        return int(ExitCode.OK)
    if isinstance(code, int):
        return code
    return int(ExitCode.ERROR)


def main(
    argv: Sequence[str] | None = None,
    *,
    console: Console | None = None,
    err_console: Console | None = None,
    commands: Sequence[Command] = COMMANDS,
    interactive: bool | None = None,
    input_fn: Callable[[str], str] | None = None,
    env: Environment | None = None,
) -> int:
    """Run LUME and return the process exit code.

    Args:
        argv: Arguments (defaults to ``sys.argv[1:]``).
        console: Console for normal output.
        err_console: Console for errors.
        commands: Command registry (injectable for tests).
        interactive: Force or forbid the interactive menu when no command is
            given. Default: only when stdin and stdout are terminals.
        input_fn: Input function for the menu (tests).
        env: Machine access (defaults to the real machine; injectable for tests).
    """
    console = console or make_console()
    err_console = err_console or make_console(stderr=True)
    parser, command_parsers = build_parser(console, commands)
    ctx = AppContext(
        console,
        err_console,
        parser,
        command_parsers,
        tuple(commands),
        env or SystemEnvironment(),
    )

    try:
        args = parser.parse_args(argv)
    except SystemExit as exc:  # --help, --version or a usage error
        return _exit_code(exc.code)

    if getattr(args, "no_color", False):
        err_console.no_color = True
    setup_logging(logging.DEBUG if getattr(args, "verbose", False) else logging.INFO)
    logger = get_logger("cli")
    logger.debug("argv=%s", list(argv) if argv is not None else sys.argv[1:])

    try:
        if args.command is not None:
            return run_command(args.command, args, ctx)
        if interactive is None:
            interactive = sys.stdin.isatty() and sys.stdout.isatty()
        if interactive:
            return run_menu(ctx, input_fn)
        print_main_help(console, commands)
        return int(ExitCode.OK)
    except KeyboardInterrupt:
        err_console.print()
        err_console.print(Text("Interrupted.", style="warn"))
        return int(ExitCode.INTERRUPTED)
    except LumeError as exc:
        logger.error("command failed: %s", exc)
        err_console.print(Text(f"Error: {exc}", style="error"), soft_wrap=True)
        return int(ExitCode.ERROR)
    except Exception:
        logger.exception("unexpected error")
        err_console.print(
            Text(
                f"Unexpected error. Details were written to {paths.log_file()}",
                style="error",
            ),
            soft_wrap=True,  # keep the log path on one line (copy/paste friendly)
        )
        return int(ExitCode.ERROR)


def entrypoint() -> None:
    """Console-script entry point."""
    raise SystemExit(main())
