"""Shared state passed to every command handler."""

from __future__ import annotations

import argparse
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from rich.console import Console

from lume.core.environment import Environment, SystemEnvironment

if TYPE_CHECKING:
    from lume.cli.commands import Command


@dataclass(frozen=True, slots=True)
class AppContext:
    """Everything a command needs to run.

    Attributes:
        console: Console for normal output (stdout).
        err_console: Console for errors and notices (stderr).
        parser: The root argument parser.
        command_parsers: Parser of each subcommand, by name.
        commands: All registered commands.
        env: Access to the machine being analyzed.
    """

    console: Console
    err_console: Console
    parser: argparse.ArgumentParser
    command_parsers: Mapping[str, argparse.ArgumentParser]
    commands: Sequence[Command]
    env: Environment = field(default_factory=SystemEnvironment)
