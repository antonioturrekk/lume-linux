"""Registry of ``lume`` commands.

Later phases replace an unimplemented entry by one with a real ``handler``.
"""

from __future__ import annotations

import argparse
from collections.abc import Sequence

from rich.text import Text

from lume.cli.analysis import (
    cmd_diagnose,
    cmd_hardware,
    cmd_network,
    cmd_performance,
    cmd_report,
    cmd_solutions,
    cmd_storage,
    configure_diagnose,
    configure_network,
    configure_performance,
    configure_report,
    configure_solutions,
)
from lume.cli.commands import Command
from lume.cli.context import AppContext
from lume.cli.exit_codes import ExitCode
from lume.cli.handlers import cmd_help, cmd_version, configure_help

COMMANDS: tuple[Command, ...] = (
    Command(
        "diagnose",
        "Run a general system diagnosis",
        handler=cmd_diagnose,
        configure=configure_diagnose,
    ),
    Command("hardware", "Identify CPU, memory, GPU, devices and disks", handler=cmd_hardware),
    Command(
        "network",
        "Diagnose interfaces, DNS, gateway and connectivity",
        handler=cmd_network,
        configure=configure_network,
    ),
    Command(
        "performance",
        "Analyze CPU, memory, swap, load and heavy processes",
        handler=cmd_performance,
        configure=configure_performance,
    ),
    Command("storage", "Analyze partitions, filesystems and free space", handler=cmd_storage),
    Command(
        "solutions",
        "Browse known problems and recommended fixes",
        handler=cmd_solutions,
        configure=configure_solutions,
    ),
    Command(
        "report",
        "Export a diagnosis as HTML, Markdown or JSON",
        handler=cmd_report,
        configure=configure_report,
    ),
    Command("version", "Show version information", handler=cmd_version),
    Command(
        "help",
        "Show help for LUME or for one command",
        handler=cmd_help,
        configure=configure_help,
    ),
)


def find_command(name: str, commands: Sequence[Command] = COMMANDS) -> Command | None:
    """Return the command called ``name``, or ``None``."""
    return next((command for command in commands if command.name == name), None)


def run_command(name: str, args: argparse.Namespace, ctx: AppContext) -> int:
    """Run a command by name and return its exit code.

    Commands that are registered but not implemented yet report that clearly
    (on stderr) and return :attr:`ExitCode.NOT_IMPLEMENTED`.
    """
    command = find_command(name, ctx.commands)
    if command is None:
        ctx.err_console.print(Text(f"Unknown command: {name}", style="error"))
        return ExitCode.USAGE
    if command.handler is None:
        ctx.err_console.print(
            Text(
                f"'lume {command.name}' is not implemented yet "
                f"(planned for development phase {command.planned_phase}).",
                style="warn",
            ),
            soft_wrap=True,
        )
        return ExitCode.NOT_IMPLEMENTED
    return int(command.handler(args, ctx))
