"""Command-line parser construction."""

from __future__ import annotations

import argparse
from collections.abc import Sequence
from typing import Any

from rich.console import Console

from lume import __version__
from lume.cli.commands import Command
from lume.cli.render import print_main_help


def build_parser(
    console: Console,
    commands: Sequence[Command],
) -> tuple[argparse.ArgumentParser, dict[str, argparse.ArgumentParser]]:
    """Build the root parser and one subparser per command.

    ``--no-color`` and ``-v/--verbose`` are accepted both before and after the
    command name. ``--no-color`` takes effect immediately, so it also applies
    to help printed while parsing.

    Returns:
        The root parser and a mapping of command name to its parser.
    """

    class HelpAction(argparse.Action):
        def __init__(
            self,
            option_strings: Sequence[str],
            dest: str = argparse.SUPPRESS,
            default: str = argparse.SUPPRESS,
            help: str | None = None,
        ) -> None:
            super().__init__(option_strings, dest=dest, default=default, nargs=0, help=help)

        def __call__(
            self,
            parser: argparse.ArgumentParser,
            namespace: argparse.Namespace,
            values: Any,
            option_string: str | None = None,
        ) -> None:
            print_main_help(console, commands)
            parser.exit()

    class NoColorAction(argparse.Action):
        def __init__(
            self,
            option_strings: Sequence[str],
            dest: str = "no_color",
            default: Any = argparse.SUPPRESS,
            help: str | None = None,
        ) -> None:
            super().__init__(option_strings, dest=dest, default=default, nargs=0, help=help)

        def __call__(
            self,
            parser: argparse.ArgumentParser,
            namespace: argparse.Namespace,
            values: Any,
            option_string: str | None = None,
        ) -> None:
            console.no_color = True
            namespace.no_color = True

    common = argparse.ArgumentParser(add_help=False, argument_default=argparse.SUPPRESS)
    common.add_argument("--no-color", action=NoColorAction, help="disable colored output")
    common.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        default=argparse.SUPPRESS,
        help="write debug details to the log",
    )

    parser = argparse.ArgumentParser(
        prog="lume",
        description="LUME - Linux Utility & Monitoring Engine",
        parents=[common],
        add_help=False,
    )
    parser.add_argument("-h", "--help", action=HelpAction, help="show this help and exit")
    parser.add_argument("--version", action="version", version=f"LUME {__version__}")

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    command_parsers: dict[str, argparse.ArgumentParser] = {}
    for command in commands:
        sub = subparsers.add_parser(
            command.name,
            help=command.summary,
            description=command.summary,
            prog=f"lume {command.name}",
            parents=[common],
        )
        if command.configure is not None:
            command.configure(sub)
        command_parsers[command.name] = sub
    return parser, command_parsers
