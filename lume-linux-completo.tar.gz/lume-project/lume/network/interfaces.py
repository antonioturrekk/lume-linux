"""Network interfaces and routes, from ``ip`` with a ``/sys``/``/proc`` fallback."""

from __future__ import annotations

import ipaddress
import json
import socket
import struct
from dataclasses import dataclass

from lume.core.environment import Environment
from lume.core.exceptions import LumeError


@dataclass(frozen=True, slots=True)
class Interface:
    """A network interface."""

    name: str
    kind: str  # loopback | ethernet | wifi | bridge | virtual
    state: str  # up | down | unknown
    mac: str = ""
    mtu: int | None = None
    ipv4: tuple[str, ...] = ()  # "address/prefix"
    ipv6: tuple[str, ...] = ()

    @property
    def ipv6_global(self) -> tuple[str, ...]:
        """IPv6 addresses that are not link-local."""
        return tuple(a for a in self.ipv6 if not a.lower().startswith("fe80"))

    @property
    def has_address(self) -> bool:
        """Whether the interface has any IPv4 or global IPv6 address."""
        return bool(self.ipv4 or self.ipv6_global)

    @property
    def active(self) -> bool:
        """Carrier up (virtual interfaces report ``unknown`` and count if addressed)."""
        if self.kind == "loopback":
            return False
        return self.state == "up" or (self.state == "unknown" and self.has_address)

    @property
    def addresses(self) -> tuple[str, ...]:
        """All addresses, IPv4 first."""
        return self.ipv4 + self.ipv6


@dataclass(frozen=True, slots=True)
class Route:
    """A routing table entry."""

    destination: str
    gateway: str | None
    device: str
    metric: int | None
    family: int = 4

    @property
    def is_default(self) -> bool:
        return self.destination == "default"


def classify(env: Environment, name: str, link_type: str | None = None) -> str:
    """Kind of interface, from its name and ``/sys`` entries."""
    if name == "lo" or link_type == "loopback":
        return "loopback"
    base = f"/sys/class/net/{name}"
    if env.exists(f"{base}/wireless") or env.exists(f"{base}/phy80211"):
        return "wifi"
    if env.exists(f"{base}/bridge"):
        return "bridge"
    if env.exists(f"/sys/devices/virtual/net/{name}"):
        return "virtual"
    return "ethernet"


def _state(value: str) -> str:
    value = value.strip().lower()
    if value == "up":
        return "up"
    if value in {"down", "lowerlayerdown", "notpresent", "dormant"}:
        return "down"
    return "unknown"


def _load_json(text: str) -> list[dict[str, object]] | None:
    try:
        data = json.loads(text)
    except ValueError:
        return None
    if not isinstance(data, list):
        return None
    return [item for item in data if isinstance(item, dict)]


def _interfaces_from_ip(env: Environment, items: list[dict[str, object]]) -> list[Interface]:
    result: list[Interface] = []
    for item in items:
        name = str(item.get("ifname", ""))
        if not name:
            continue
        ipv4: list[str] = []
        ipv6: list[str] = []
        info = item.get("addr_info")
        for addr in info if isinstance(info, list) else []:
            if not isinstance(addr, dict) or "local" not in addr:
                continue
            text = f"{addr['local']}/{addr.get('prefixlen', '')}".rstrip("/")
            (ipv4 if addr.get("family") == "inet" else ipv6).append(text)
        mtu = item.get("mtu")
        link_type = item.get("link_type")
        result.append(
            Interface(
                name=name,
                kind=classify(env, name, link_type if isinstance(link_type, str) else None),
                state=_state(str(item.get("operstate", ""))),
                mac="" if name == "lo" else str(item.get("address", "")),
                mtu=mtu if isinstance(mtu, int) else None,
                ipv4=tuple(ipv4),
                ipv6=tuple(ipv6),
            )
        )
    return result


def _ipv6_from_proc(env: Environment) -> dict[str, list[str]]:
    found: dict[str, list[str]] = {}
    for line in (env.read_text("/proc/net/if_inet6") or "").splitlines():
        fields = line.split()
        if len(fields) < 6 or len(fields[0]) != 32:
            continue
        try:
            address = ipaddress.IPv6Address(int(fields[0], 16))
            prefix = int(fields[2], 16)
        except ValueError:
            continue
        found.setdefault(fields[5], []).append(f"{address}/{prefix}")
    return found


def _interfaces_from_sysfs(env: Environment) -> list[Interface]:
    ipv6 = _ipv6_from_proc(env)
    result: list[Interface] = []
    for name in env.listdir("/sys/class/net"):
        base = f"/sys/class/net/{name}"
        operstate = (env.read_text(f"{base}/operstate") or "").strip()
        mac = (env.read_text(f"{base}/address") or "").strip()
        mtu_text = (env.read_text(f"{base}/mtu") or "").strip()
        v4 = env.interface_ipv4(name)
        result.append(
            Interface(
                name=name,
                kind=classify(env, name),
                state=_state(operstate),
                mac="" if name == "lo" else mac,
                mtu=int(mtu_text) if mtu_text.isdigit() else None,
                ipv4=(f"{v4[0]}/{v4[1]}",) if v4 else (),
                ipv6=tuple(ipv6.get(name, [])),
            )
        )
    return result


def list_interfaces(env: Environment) -> list[Interface]:
    """List interfaces using ``ip -j`` when available, otherwise ``/sys``."""
    try:
        completed = env.run(["ip", "-j", "addr", "show"])
    except LumeError:
        return _interfaces_from_sysfs(env)
    items = _load_json(completed.stdout) if completed.ok else None
    if items is None:
        return _interfaces_from_sysfs(env)
    return _interfaces_from_ip(env, items)


def _routes_from_ip(items: list[dict[str, object]], family: int) -> list[Route]:
    routes: list[Route] = []
    for item in items:
        gateway = item.get("gateway")
        metric = item.get("metric")
        routes.append(
            Route(
                destination=str(item.get("dst", "")),
                gateway=gateway if isinstance(gateway, str) else None,
                device=str(item.get("dev", "")),
                metric=metric if isinstance(metric, int) else None,
                family=family,
            )
        )
    return routes


def _routes_from_proc(env: Environment) -> list[Route]:
    routes: list[Route] = []
    for line in (env.read_text("/proc/net/route") or "").splitlines()[1:]:
        fields = line.split()
        if len(fields) < 8:
            continue
        try:
            destination = int(fields[1], 16)
            gateway = int(fields[2], 16)
            metric = int(fields[6])
        except ValueError:
            continue
        if destination != 0:
            continue
        routes.append(
            Route(
                "default",
                socket.inet_ntoa(struct.pack("<L", gateway)) if gateway else None,
                fields[0],
                metric,
            )
        )
    return routes


def list_routes(env: Environment) -> list[Route]:
    """List IPv4 routes (and IPv6 when ``ip`` is available)."""
    routes: list[Route] = []
    try:
        v4 = env.run(["ip", "-j", "route", "show"])
    except LumeError:
        return _routes_from_proc(env)
    items = _load_json(v4.stdout) if v4.ok else None
    if items is None:
        return _routes_from_proc(env)
    routes.extend(_routes_from_ip(items, 4))
    try:
        v6 = env.run(["ip", "-j", "-6", "route", "show"])
        items6 = _load_json(v6.stdout) if v6.ok else None
        if items6:
            routes.extend(_routes_from_ip(items6, 6))
    except LumeError:
        pass
    return routes


def default_routes(routes: list[Route]) -> list[Route]:
    """Only the default routes."""
    return [route for route in routes if route.is_default]
