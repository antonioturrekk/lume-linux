"""Read-only network diagnostics: interfaces, IP, Wi-Fi, DNS, gateway, connectivity.

LUME never changes network settings. Active probes (TCP connection, name
resolution) can be turned off with ``offline=True``.
"""

from __future__ import annotations

from lume.core import CheckResult, error, ok, skip, warn
from lume.core.environment import Environment
from lume.core.report import KeyValues, Report, Section, Table
from lume.network.connectivity import (
    DNS_TEST_HOST,
    DnsProbe,
    InternetProbe,
    ping_gateway,
    probe_dns,
    probe_internet,
)
from lume.network.dns import DnsConfig, read_dns
from lume.network.interfaces import Interface, Route, default_routes, list_interfaces, list_routes
from lume.network.wifi import RfkillSwitch, WifiSignal, parse_proc_net_wireless, read_rfkill

__all__ = ["analyze"]

OFFLINE_REASON = "skipped (--offline: no active network probes)"
NO_LINK_REASON = "no active network connection"
LINK_LOCAL_PREFIX = "169.254."


def _interfaces_check(interfaces: list[Interface]) -> CheckResult:
    if not interfaces:
        return skip(
            "network.interfaces", "Network interfaces", "no interface information available"
        )
    physical = [i for i in interfaces if i.kind in ("ethernet", "wifi")]
    if not physical:
        return warn(
            "network.interfaces",
            "Network interfaces",
            "no Ethernet or Wi-Fi interface found",
            [f"interfaces found: {', '.join(i.name for i in interfaces)}"],
        )
    active = [i for i in physical if i.active]
    return ok(
        "network.interfaces",
        "Network interfaces",
        f"{len(physical)} physical interface(s), {len(active)} active",
    )


def _addresses_check(physical: list[Interface], active: list[Interface]) -> CheckResult:
    if not physical:
        return skip("network.addresses", "IP address", "no Ethernet or Wi-Fi interface")
    if not active:
        return warn(
            "network.addresses",
            "IP address",
            "no network connection is active",
            [f"{i.name} ({i.kind}): link is {i.state}" for i in physical],
        )
    problems: list[str] = []
    for iface in active:
        if not iface.has_address:
            problems.append(f"{iface.name}: link is up but it has no IP address")
        elif iface.ipv4 and all(a.startswith(LINK_LOCAL_PREFIX) for a in iface.ipv4):
            problems.append(
                f"{iface.name}: only a self-assigned address ({', '.join(iface.ipv4)}); "
                "no DHCP server answered"
            )
    if problems:
        return warn(
            "network.addresses", "IP address", "an active interface has no usable address", problems
        )
    shown = "; ".join(f"{i.name}: {', '.join(i.ipv4 or i.ipv6_global)}" for i in active)
    return ok("network.addresses", "IP address", shown)


def _gateway_check(
    addressed: list[Interface],
    routes: list[Route],
    internet_ok: bool | None,
    env: Environment,
) -> CheckResult:
    if not addressed:
        return skip("network.gateway", "Gateway", NO_LINK_REASON)
    defaults = default_routes([r for r in routes if r.family == 4])
    if not defaults:
        return warn(
            "network.gateway",
            "Gateway",
            "no default route: traffic cannot leave the local network",
            [
                f"interfaces with an address: {', '.join(i.name for i in addressed)}",
                "the routing table has no default route",
            ],
        )
    metrics = [r.metric for r in defaults]
    if len(defaults) > 1 and len(set(metrics)) < len(metrics):
        return warn(
            "network.gateway",
            "Gateway",
            "several default routes have the same priority",
            [f"default via {r.gateway or '-'} dev {r.device} metric {r.metric}" for r in defaults],
        )
    best = min(defaults, key=lambda r: r.metric if r.metric is not None else 0)
    if not best.gateway:
        return ok("network.gateway", "Gateway", f"default route on {best.device} (point-to-point)")
    ping = ping_gateway(env, best.gateway)
    if ping is None:
        return ok("network.gateway", "Gateway", f"default via {best.gateway} on {best.device}")
    if ping.answered:
        suffix = f" ({ping.latency_ms:.0f} ms)" if ping.latency_ms is not None else ""
        return ok("network.gateway", "Gateway", f"{best.gateway} answers ping{suffix}")
    if internet_ok:
        return ok(
            "network.gateway",
            "Gateway",
            f"{best.gateway} does not answer ping, but the internet is reachable",
        )
    return warn(
        "network.gateway",
        "Gateway",
        f"gateway {best.gateway} did not answer",
        [ping.detail, "some routers ignore ping, so this alone is not proof of failure"],
    )


def _dns_config_check(dns: DnsConfig) -> CheckResult:
    if not dns.file_found:
        return error(
            "network.dns_config",
            "DNS configuration",
            "no DNS configuration found",
            ["/etc/resolv.conf does not exist"],
        )
    if not dns.servers:
        return error(
            "network.dns_config",
            "DNS configuration",
            "no DNS server is configured",
            ["/etc/resolv.conf has no 'nameserver' entry"],
        )
    if dns.local_stub:
        upstream = f" (upstream: {', '.join(dns.upstream)})" if dns.upstream else ""
        return ok(
            "network.dns_config",
            "DNS configuration",
            f"local resolver {', '.join(dns.servers)}{upstream}",
        )
    return ok("network.dns_config", "DNS configuration", f"servers: {', '.join(dns.servers)}")


def _internet_check(probe: InternetProbe | None, link_up: bool, offline: bool) -> CheckResult:
    if offline:
        return skip("network.internet", "Internet connectivity", OFFLINE_REASON)
    if not link_up or probe is None:
        return skip("network.internet", "Internet connectivity", NO_LINK_REASON)
    if probe.reachable:
        return ok(
            "network.internet",
            "Internet connectivity",
            f"reachable (TCP to {probe.target}, {probe.latency_ms:.0f} ms)",
        )
    return error(
        "network.internet",
        "Internet connectivity",
        "no internet access although the local network is up",
        probe.failures,
    )


def _dns_check(
    probe: DnsProbe | None, internet: InternetProbe | None, link_up: bool, offline: bool
) -> CheckResult:
    if offline:
        return skip("network.dns", "Name resolution", OFFLINE_REASON)
    if not link_up or probe is None:
        return skip("network.dns", "Name resolution", NO_LINK_REASON)
    if probe.resolved:
        return ok(
            "network.dns",
            "Name resolution",
            f"{DNS_TEST_HOST} resolved to {probe.addresses[0]}",
        )
    if internet is not None and internet.reachable:
        return error(
            "network.dns",
            "Name resolution",
            "names cannot be resolved although the internet is reachable",
            [probe.failure],
        )
    return warn(
        "network.dns",
        "Name resolution",
        "names cannot be resolved (the internet is also unreachable)",
        [probe.failure],
    )


def _wifi_check(
    wifi: list[Interface], signals: list[WifiSignal], switches: list[RfkillSwitch]
) -> CheckResult:
    if not wifi:
        return skip("network.wifi", "Wi-Fi", "no Wi-Fi interface found")
    blocked = [s for s in switches if s.type == "wlan" and s.blocked]
    if blocked:
        evidence = [
            f"{s.name}: {'hard' if s.hard_blocked else 'soft'} blocked"
            + (" (physical switch or airplane-mode key)" if s.hard_blocked else "")
            for s in blocked
        ]
        return warn("network.wifi", "Wi-Fi", "the Wi-Fi radio is blocked", evidence)
    by_name = {s.interface: s for s in signals}
    weak = [
        by_name[i.name] for i in wifi if i.name in by_name and by_name[i.name].quality == "poor"
    ]
    if weak:
        return warn(
            "network.wifi",
            "Wi-Fi",
            "the Wi-Fi signal is poor",
            [f"{s.interface}: {s.dbm} dBm" for s in weak],
        )
    described = []
    for iface in wifi:
        signal = by_name.get(iface.name)
        if signal and signal.dbm is not None:
            described.append(f"{iface.name}: {signal.dbm} dBm ({signal.quality})")
        else:
            described.append(f"{iface.name}: {iface.state}")
    return ok("network.wifi", "Wi-Fi", "; ".join(described))


def analyze(env: Environment, *, offline: bool = False) -> Report:
    """Diagnose the network (read-only). ``offline`` disables active probes."""
    interfaces = list_interfaces(env)
    routes = list_routes(env)
    dns = read_dns(env)
    switches = read_rfkill(env)
    signals = parse_proc_net_wireless(env.read_text("/proc/net/wireless") or "")

    physical = [i for i in interfaces if i.kind in ("ethernet", "wifi")]
    active = [i for i in physical if i.active]
    addressed = [i for i in active if i.has_address]

    internet = dns_probe = None
    if not offline and addressed:
        internet = probe_internet(env)
        dns_probe = probe_dns(env)

    checks: list[CheckResult] = [
        _interfaces_check(interfaces),
        _addresses_check(physical, active),
        _gateway_check(addressed, routes, internet.reachable if internet else None, env),
        _dns_config_check(dns),
        _internet_check(internet, bool(addressed), offline),
        _dns_check(dns_probe, internet, bool(addressed), offline),
        _wifi_check([i for i in interfaces if i.kind == "wifi"], signals, switches),
    ]

    sections: list[Section] = []
    if interfaces:
        sections.append(
            Table(
                "Interfaces",
                ("Name", "Type", "State", "MAC", "MTU", "Addresses"),
                tuple(
                    (
                        i.name,
                        i.kind,
                        i.state,
                        i.mac or "-",
                        str(i.mtu) if i.mtu else "-",
                        ", ".join(i.addresses) or "-",
                    )
                    for i in interfaces
                ),
            )
        )
    defaults = default_routes(routes)
    sections.append(
        KeyValues(
            "Routing and DNS",
            (
                (
                    "Default gateway",
                    ", ".join(f"{r.gateway or '-'} via {r.device}" for r in defaults) or "none",
                ),
                ("DNS servers", ", ".join(dns.servers) or "none"),
                ("DNS upstream", ", ".join(dns.upstream) or "-"),
                ("Search domains", ", ".join(dns.search) or "-"),
            ),
        )
    )
    return Report("network", "Network", tuple(sections), tuple(checks))
