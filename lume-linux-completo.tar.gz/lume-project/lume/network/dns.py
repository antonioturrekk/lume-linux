"""DNS configuration."""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass

from lume.core.environment import Environment
from lume.core.exceptions import LumeError

LOCAL_RESOLVERS = frozenset({"127.0.0.53", "127.0.0.1", "::1"})


@dataclass(frozen=True, slots=True)
class DnsConfig:
    """Resolver configuration as seen by applications."""

    servers: tuple[str, ...] = ()
    search: tuple[str, ...] = ()
    upstream: tuple[str, ...] = ()  # real servers behind a local stub (systemd-resolved)
    file_found: bool = True

    @property
    def local_stub(self) -> bool:
        """Whether applications talk to a local resolver (e.g. systemd-resolved)."""
        return bool(self.servers) and all(s in LOCAL_RESOLVERS for s in self.servers)


def parse_resolv_conf(text: str) -> DnsConfig:
    """Parse ``/etc/resolv.conf``."""
    servers: list[str] = []
    search: list[str] = []
    for raw in text.splitlines():
        parts = raw.split("#", 1)[0].split()
        if len(parts) >= 2 and parts[0] == "nameserver":
            servers.append(parts[1].split("%", 1)[0])
        elif len(parts) >= 2 and parts[0] in {"search", "domain"}:
            search.extend(parts[1:])
    return DnsConfig(tuple(servers), tuple(search))


def parse_resolvectl_dns(text: str) -> tuple[str, ...]:
    """Extract the DNS server addresses from ``resolvectl dns`` output."""
    found: list[str] = []
    for line in text.splitlines():
        _, _, rest = line.partition(":")
        for token in rest.split():
            try:
                address = ipaddress.ip_address(token.split("%", 1)[0])
            except ValueError:
                continue
            if str(address) not in found:
                found.append(str(address))
    return tuple(found)


def read_dns(env: Environment) -> DnsConfig:
    """Read the DNS configuration (and the upstream servers behind a local stub)."""
    text = env.read_text("/etc/resolv.conf")
    if text is None:
        return DnsConfig(file_found=False)
    config = parse_resolv_conf(text)
    if config.local_stub:
        try:
            completed = env.run(["resolvectl", "dns"])
        except LumeError:
            return config
        if completed.ok:
            upstream = tuple(
                s for s in parse_resolvectl_dns(completed.stdout) if s not in LOCAL_RESOLVERS
            )
            return DnsConfig(config.servers, config.search, upstream, True)
    return config
