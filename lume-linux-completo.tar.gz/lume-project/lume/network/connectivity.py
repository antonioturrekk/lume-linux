"""Active connectivity probes (disabled with ``--offline``).

Probes only open a TCP connection, resolve one name and ping the local gateway.
No data is sent or downloaded.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from lume.core.environment import Environment
from lume.core.exceptions import LumeError

TCP_TARGETS: tuple[tuple[str, int], ...] = (("1.1.1.1", 443), ("9.9.9.9", 443))
DNS_TEST_HOST = "example.com"
_PING_TIME_RE = re.compile(r"time[=<]([\d.]+)\s*ms")


@dataclass(frozen=True, slots=True)
class InternetProbe:
    """Result of the internet reachability test."""

    reachable: bool
    target: str = ""
    latency_ms: float = 0.0
    failures: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DnsProbe:
    """Result of the name resolution test."""

    resolved: bool
    addresses: tuple[str, ...] = ()
    failure: str = ""


@dataclass(frozen=True, slots=True)
class PingProbe:
    """Result of pinging the gateway (``None`` when ping is not available)."""

    answered: bool
    latency_ms: float | None = None
    detail: str = ""


def probe_internet(env: Environment) -> InternetProbe:
    """Try a TCP connection to well-known public addresses."""
    failures: list[str] = []
    for host, port in TCP_TARGETS:
        try:
            latency = env.tcp_connect(host, port, 3.0)
        except OSError as exc:
            failures.append(f"tcp {host}:{port}: {exc}")
            continue
        return InternetProbe(True, f"{host}:{port}", latency)
    return InternetProbe(False, failures=tuple(failures))


def probe_dns(env: Environment) -> DnsProbe:
    """Resolve one well-known name with the system resolver."""
    try:
        addresses = env.resolve_host(DNS_TEST_HOST, 4.0)
    except OSError as exc:
        return DnsProbe(False, failure=f"resolving {DNS_TEST_HOST}: {exc}")
    if not addresses:
        return DnsProbe(False, failure=f"resolving {DNS_TEST_HOST}: no address returned")
    return DnsProbe(True, tuple(addresses))


def ping_gateway(env: Environment, gateway: str) -> PingProbe | None:
    """Ping the gateway once. ``None`` if ``ping`` cannot be used."""
    try:
        completed = env.run(["ping", "-c", "1", "-W", "2", gateway], timeout=6)
    except LumeError:
        return None
    if completed.ok:
        match = _PING_TIME_RE.search(completed.stdout)
        return PingProbe(True, float(match.group(1)) if match else None)
    return PingProbe(False, detail=f"ping {gateway}: no answer (exit {completed.returncode})")
