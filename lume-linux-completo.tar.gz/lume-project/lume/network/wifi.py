"""Wi-Fi state: signal (``/proc/net/wireless``) and radio switches (``rfkill``)."""

from __future__ import annotations

from dataclasses import dataclass

from lume.core.environment import Environment


@dataclass(frozen=True, slots=True)
class WifiSignal:
    """Signal reported by the driver for an interface."""

    interface: str
    dbm: int | None

    @property
    def quality(self) -> str:
        """Plain-language quality."""
        if self.dbm is None:
            return "unknown"
        if self.dbm >= -60:
            return "excellent"
        if self.dbm >= -70:
            return "good"
        if self.dbm >= -80:
            return "fair"
        return "poor"


@dataclass(frozen=True, slots=True)
class RfkillSwitch:
    """A radio kill switch."""

    name: str
    type: str
    soft_blocked: bool
    hard_blocked: bool

    @property
    def blocked(self) -> bool:
        return self.soft_blocked or self.hard_blocked


def _dbm(raw: str) -> int | None:
    try:
        value = float(raw.rstrip("."))
    except ValueError:
        return None
    if value < 0:
        return int(value) if value >= -120 else None
    if 128 < value <= 255:  # unsigned byte representation of a negative dBm
        return int(value) - 256
    return None


def parse_proc_net_wireless(text: str) -> list[WifiSignal]:
    """Parse ``/proc/net/wireless``."""
    signals: list[WifiSignal] = []
    for line in text.splitlines():
        name, sep, rest = line.partition(":")
        fields = rest.split()
        if not sep or len(fields) < 3 or "|" in line:
            continue
        signals.append(WifiSignal(name.strip(), _dbm(fields[2])))
    return signals


def read_rfkill(env: Environment) -> list[RfkillSwitch]:
    """Read radio switches from ``/sys/class/rfkill``."""
    switches: list[RfkillSwitch] = []
    for entry in env.listdir("/sys/class/rfkill"):
        base = f"/sys/class/rfkill/{entry}"
        switches.append(
            RfkillSwitch(
                name=(env.read_text(f"{base}/name") or entry).strip(),
                type=(env.read_text(f"{base}/type") or "").strip(),
                soft_blocked=(env.read_text(f"{base}/soft") or "0").strip() == "1",
                hard_blocked=(env.read_text(f"{base}/hard") or "0").strip() == "1",
            )
        )
    return switches
