"""Per-process CPU and memory, from ``/proc/<pid>``."""

from __future__ import annotations

from dataclasses import dataclass

from lume.core.environment import Environment


@dataclass(frozen=True, slots=True)
class ProcessUsage:
    """CPU and memory use of one process over the sampling window."""

    pid: int
    name: str
    cpu_percent: float  # share of ONE core, like ``top``
    rss_bytes: int


def parse_proc_stat(text: str) -> tuple[str, int] | None:
    """Return ``(name, utime + stime)`` from ``/proc/<pid>/stat``.

    The process name sits between parentheses and may itself contain spaces or
    parentheses, so the *last* closing parenthesis ends it.
    """
    start, end = text.find("("), text.rfind(")")
    if start == -1 or end == -1 or end < start:
        return None
    fields = text[end + 1 :].split()
    try:
        return text[start + 1 : end], int(fields[11]) + int(fields[12])
    except (IndexError, ValueError):
        return None


def snapshot_ticks(env: Environment) -> dict[int, tuple[str, int]]:
    """CPU ticks consumed so far by every process: ``{pid: (name, ticks)}``."""
    snapshot: dict[int, tuple[str, int]] = {}
    for entry in env.listdir("/proc"):
        if not entry.isdigit():
            continue
        parsed = parse_proc_stat(env.read_text(f"/proc/{entry}/stat") or "")
        if parsed:
            snapshot[int(entry)] = parsed
    return snapshot


def compute_usage(
    env: Environment,
    before: dict[int, tuple[str, int]],
    after: dict[int, tuple[str, int]],
    total_delta_ticks: int,
    cpu_count: int,
) -> list[ProcessUsage]:
    """Combine two snapshots into per-process usage."""
    per_core_ticks = total_delta_ticks / max(cpu_count, 1)
    page = env.page_size()
    usages: list[ProcessUsage] = []
    for pid, (name, ticks) in after.items():
        previous = before.get(pid)
        delta = ticks - previous[1] if previous else ticks
        cpu = 100.0 * delta / per_core_ticks if per_core_ticks > 0 and delta > 0 else 0.0
        statm = (env.read_text(f"/proc/{pid}/statm") or "").split()
        rss = int(statm[1]) * page if len(statm) > 1 and statm[1].isdigit() else 0
        usages.append(ProcessUsage(pid, name, cpu, rss))
    return usages
