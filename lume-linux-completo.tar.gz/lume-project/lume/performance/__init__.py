"""Read-only performance analysis: CPU, RAM, swap, load, heavy processes.

Messages are written for beginners: they say what a number means for the user.
"""

from __future__ import annotations

from lume.core import CheckResult, error, ok, skip, warn
from lume.core.environment import Environment
from lume.core.kernel_log import OOM_RE, KernelLog, read_kernel_log
from lume.core.procfs import parse_loadavg, parse_meminfo, parse_stat
from lume.core.report import KeyValues, Report, Section, Table
from lume.core.units import format_bytes, format_percent, plural
from lume.performance.processes import (
    ProcessUsage,
    compute_usage,
    snapshot_ticks,
)
from lume.storage import measured_filesystems, space_check
from lume.storage.mounts import parse_mounts

__all__ = ["analyze"]

CPU_WARN = 90.0
LOAD_WARN_PER_CORE = 1.5
MEM_AVAILABLE_WARN, MEM_AVAILABLE_ERROR = 15.0, 5.0
SWAP_WARN = 80.0
TOP_N = 5


def _top_cpu_lines(processes: list[ProcessUsage]) -> list[str]:
    busiest = sorted(processes, key=lambda p: p.cpu_percent, reverse=True)[:3]
    return [
        f"{p.name} (pid {p.pid}): {p.cpu_percent:.0f}% of one core"
        for p in busiest
        if p.cpu_percent > 0
    ]


def _top_memory_lines(processes: list[ProcessUsage]) -> list[str]:
    biggest = sorted(processes, key=lambda p: p.rss_bytes, reverse=True)[:3]
    return [
        f"{p.name} (pid {p.pid}): {format_bytes(p.rss_bytes)}" for p in biggest if p.rss_bytes > 0
    ]


def _cpu_check(usage: float | None, cpus: int, processes: list[ProcessUsage]) -> CheckResult:
    if usage is None:
        return skip("performance.cpu", "CPU usage", "/proc/stat could not be sampled")
    if usage >= CPU_WARN:
        evidence = [f"CPU {format_percent(usage)} busy over the sampling window"]
        evidence += _top_cpu_lines(processes)
        return warn(
            "performance.cpu",
            "CPU usage",
            "the processor is almost fully busy; the computer may feel slow",
            evidence,
        )
    return ok(
        "performance.cpu", "CPU usage", f"{format_percent(usage)} busy ({plural(cpus, 'thread')})"
    )


def _load_check(load: tuple[float, float, float] | None, cpus: int) -> CheckResult:
    if load is None:
        return skip("performance.load", "System load", "/proc/loadavg is not readable")
    one, five, fifteen = load
    text = f"load {one:.2f} / {five:.2f} / {fifteen:.2f} on {plural(cpus, 'thread')}"
    if five / cpus >= LOAD_WARN_PER_CORE:
        return warn(
            "performance.load",
            "System load",
            "more work is waiting than the processor can handle",
            [text, f"5-minute load per thread: {five / cpus:.2f} (above {LOAD_WARN_PER_CORE})"],
        )
    return ok("performance.load", "System load", text)


def _memory_check(total: int, available: int, processes: list[ProcessUsage]) -> CheckResult:
    percent_available = 100.0 * available / total
    text = f"{format_bytes(available)} available of {format_bytes(total)}"
    if percent_available < MEM_AVAILABLE_WARN:
        evidence = [f"only {format_percent(percent_available)} of memory is available ({text})"]
        evidence += _top_memory_lines(processes)
        summary = "memory is almost full; programs may slow down or close unexpectedly"
        if percent_available < MEM_AVAILABLE_ERROR:
            return error("performance.memory", "Memory", summary, evidence)
        return warn("performance.memory", "Memory", "memory is running low", evidence)
    return ok(
        "performance.memory", "Memory", f"{text} ({format_percent(100 - percent_available)} in use)"
    )


def _swap_check(info: dict[str, int], available_percent: float) -> CheckResult:
    swap_total = info.get("SwapTotal", 0)
    if not swap_total:
        return ok("performance.swap", "Swap", "no swap configured")
    used = swap_total - info.get("SwapFree", 0)
    percent = 100.0 * used / swap_total
    text = f"{format_bytes(used)} of {format_bytes(swap_total)} used ({format_percent(percent)})"
    if percent >= SWAP_WARN:
        evidence = [text, f"memory available: {format_percent(available_percent)}"]
        if available_percent < MEM_AVAILABLE_WARN:
            return error(
                "performance.swap",
                "Swap",
                "swap is nearly full while memory is low; the system may freeze",
                evidence,
            )
        return warn("performance.swap", "Swap", "swap is nearly full", evidence)
    return ok("performance.swap", "Swap", text)


def _oom_check(kernel_log: KernelLog) -> CheckResult:
    if not kernel_log.available:
        return skip(
            "performance.oom", "Out-of-memory kills", kernel_log.unavailable_reason or "unavailable"
        )
    lines = kernel_log.matching(OOM_RE)
    if lines:
        return warn(
            "performance.oom",
            "Out-of-memory kills",
            "the kernel had to kill programs because memory ran out",
            lines[:3],
        )
    return ok("performance.oom", "Out-of-memory kills", "no program was killed for lack of memory")


def analyze(
    env: Environment,
    *,
    interval: float = 1.0,
    include_disk: bool = True,
    kernel_log: KernelLog | None = None,
) -> Report:
    """Measure CPU, memory, swap, load and the heaviest processes.

    Args:
        env: Machine access.
        interval: Seconds between the two CPU samples.
        include_disk: Also check free space of ``/`` (the ``storage`` command
            checks every filesystem; the overall diagnosis disables this to
            avoid duplicates).
        kernel_log: Pre-read kernel log (read on demand when ``None``).
    """
    checks: list[CheckResult] = []
    sections: list[Section] = []

    first_stat = parse_stat(env.read_text("/proc/stat") or "")
    before = snapshot_ticks(env) if first_stat else {}
    if first_stat:
        env.sleep(interval)
    second_stat = parse_stat(env.read_text("/proc/stat") or "") if first_stat else None

    usage: float | None = None
    processes: list[ProcessUsage] = []
    cpus = first_stat.cpu_count if first_stat else 1
    if first_stat and second_stat:
        total_delta = second_stat.total - first_stat.total
        idle_delta = second_stat.idle - first_stat.idle
        if total_delta > 0:
            usage = max(0.0, min(100.0, 100.0 * (total_delta - idle_delta) / total_delta))
            processes = compute_usage(env, before, snapshot_ticks(env), total_delta, cpus)

    load_avg = parse_loadavg(env.read_text("/proc/loadavg") or "")
    load = (load_avg.one, load_avg.five, load_avg.fifteen) if load_avg else None
    meminfo_text = env.read_text("/proc/meminfo")
    info = parse_meminfo(meminfo_text) if meminfo_text else {}

    checks.append(_cpu_check(usage, cpus, processes))
    checks.append(_load_check(load, cpus))
    cpu_items = [
        ("CPU usage", format_percent(usage) if usage is not None else "unknown"),
        ("Threads", str(cpus)),
    ]
    if load:
        cpu_items.append(
            ("Load average (1/5/15 min)", f"{load[0]:.2f} / {load[1]:.2f} / {load[2]:.2f}")
        )
    sections.append(KeyValues("CPU and load", tuple(cpu_items)))

    total, available = info.get("MemTotal", 0), info.get("MemAvailable", info.get("MemFree", 0))
    if total:
        available_percent = 100.0 * available / total
        checks.append(_memory_check(total, available, processes))
        checks.append(_swap_check(info, available_percent))
        swap_total = info.get("SwapTotal", 0)
        swap_used = swap_total - info.get("SwapFree", 0)
        swap_text = (
            f"{format_bytes(swap_used)} of {format_bytes(swap_total)}"
            if swap_total
            else "no swap configured"
        )
        sections.append(
            KeyValues(
                "Memory",
                (
                    ("Total", format_bytes(total)),
                    ("In use", format_bytes(total - available)),
                    ("Available", format_bytes(available)),
                    ("Swap used", swap_text),
                ),
            )
        )
    else:
        reason = "/proc/meminfo is not readable"
        checks += [
            skip("performance.memory", "Memory", reason),
            skip("performance.swap", "Swap", reason),
        ]

    checks.append(_oom_check(kernel_log if kernel_log is not None else read_kernel_log(env)))

    if include_disk:
        mounts_text = env.read_text("/proc/self/mounts") or env.read_text("/proc/mounts") or ""
        root = [
            (m, u)
            for m, u in measured_filesystems(env, parse_mounts(mounts_text))
            if m.target == "/"
        ]
        checks.append(space_check("performance.disk", "Disk space (/)", root))

    if processes:
        by_cpu = [
            p
            for p in sorted(processes, key=lambda p: p.cpu_percent, reverse=True)[:TOP_N]
            if p.cpu_percent >= 0.5
        ]
        by_memory = sorted(processes, key=lambda p: p.rss_bytes, reverse=True)[:TOP_N]
        if by_cpu:
            sections.append(
                Table(
                    "Top processes by CPU",
                    ("PID", "Process", "CPU (of one core)", "Memory"),
                    tuple(
                        (str(p.pid), p.name, f"{p.cpu_percent:.0f}%", format_bytes(p.rss_bytes))
                        for p in by_cpu
                    ),
                )
            )
        sections.append(
            Table(
                "Top processes by memory",
                ("PID", "Process", "Memory", "Share of RAM"),
                tuple(
                    (
                        str(p.pid),
                        p.name,
                        format_bytes(p.rss_bytes),
                        format_percent(100.0 * p.rss_bytes / total) if total else "-",
                    )
                    for p in by_memory
                ),
            )
        )
    return Report("performance", "Performance", tuple(sections), tuple(checks))
