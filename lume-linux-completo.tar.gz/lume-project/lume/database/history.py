"""History of diagnoses.

Only what is needed to compare runs is stored: the check id, its name and its
status. Summaries and evidence (which may contain addresses or other personal
data) are **never** written to the database.
"""

from __future__ import annotations

import sqlite3
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path

from lume.core import Status
from lume.core.log import get_logger
from lume.diagnostics.engine import Diagnosis

_log = get_logger("history")
KEEP_RUNS = 50
_PROBLEM = {Status.WARN.value, Status.ERROR.value}

_SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    lume_version TEXT NOT NULL,
    distro TEXT NOT NULL,
    ok INTEGER NOT NULL, warn INTEGER NOT NULL, error INTEGER NOT NULL, skip INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS findings (
    run_id INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    check_id TEXT NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL,
    PRIMARY KEY (run_id, check_id)
);
"""


@dataclass(frozen=True, slots=True)
class PreviousRun:
    """The last stored diagnosis."""

    run_id: int
    created_at: str
    statuses: dict[str, str]
    names: dict[str, str]


@dataclass(frozen=True, slots=True)
class Delta:
    """Differences between the previous run and the current one."""

    since: str
    new_problems: tuple[str, ...]
    resolved: tuple[str, ...]
    worsened: tuple[str, ...]

    @property
    def changed(self) -> bool:
        return bool(self.new_problems or self.resolved or self.worsened)


class HistoryStore:
    """Small SQLite store. Every failure is logged and never interrupts a diagnosis."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def _connect(self) -> sqlite3.Connection:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path)
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(_SCHEMA)
        return conn

    def latest(self) -> PreviousRun | None:
        """The most recent stored run, if any."""
        try:
            with closing(self._connect()) as conn:
                row = conn.execute(
                    "SELECT id, created_at FROM runs ORDER BY id DESC LIMIT 1"
                ).fetchone()
                if row is None:
                    return None
                rows = conn.execute(
                    "SELECT check_id, name, status FROM findings WHERE run_id = ?", (row[0],)
                ).fetchall()
        except (sqlite3.Error, OSError):
            _log.exception("could not read the history")
            return None
        return PreviousRun(row[0], row[1], {r[0]: r[2] for r in rows}, {r[0]: r[1] for r in rows})

    def record(self, diagnosis: Diagnosis) -> int | None:
        """Store a diagnosis and return its run id (``None`` if it could not be saved)."""
        counts = diagnosis.counts
        try:
            with closing(self._connect()) as conn, conn:
                cursor = conn.execute(
                    "INSERT INTO runs (created_at, lume_version, distro, ok, warn, error, skip)"
                    " VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        diagnosis.generated_at,
                        diagnosis.lume_version,
                        diagnosis.distro.id,
                        counts[Status.OK],
                        counts[Status.WARN],
                        counts[Status.ERROR],
                        counts[Status.SKIP],
                    ),
                )
                run_id = cursor.lastrowid
                conn.executemany(
                    "INSERT OR REPLACE INTO findings (run_id, check_id, name, status)"
                    " VALUES (?, ?, ?, ?)",
                    [
                        (run_id, c.check_id, c.name, c.status.value)
                        for c in diagnosis.checks
                        if c.check_id
                    ],
                )
                conn.execute(
                    "DELETE FROM runs WHERE id NOT IN"
                    " (SELECT id FROM runs ORDER BY id DESC LIMIT ?)",
                    (KEEP_RUNS,),
                )
                return run_id
        except (sqlite3.Error, OSError):
            _log.exception("could not save the history")
            return None


def compare(previous: PreviousRun, diagnosis: Diagnosis) -> Delta:
    """What changed between ``previous`` and ``diagnosis``."""
    new: list[str] = []
    resolved: list[str] = []
    worsened: list[str] = []
    current = {c.check_id: c for c in diagnosis.checks if c.check_id}
    for check_id, check in current.items():
        before = previous.statuses.get(check_id)
        if check.status.value in _PROBLEM:
            if before not in _PROBLEM:
                new.append(check.name)
            elif before == Status.WARN.value and check.status is Status.ERROR:
                worsened.append(check.name)
        elif before in _PROBLEM and check.status is Status.OK:
            resolved.append(check.name)
    return Delta(previous.created_at, tuple(new), tuple(resolved), tuple(worsened))
