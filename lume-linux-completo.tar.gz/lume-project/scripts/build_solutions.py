"""Regenerates lume/solutions/data/solutions.json from the entries below.

Run:  python scripts/build_solutions.py
The generated file is validated by LUME itself when it loads (see tests).
"""

import json
from pathlib import Path

T = True


def step(description, command=None, root=False):
    out = {"description": description}
    if command:
        out["command"] = command
        out["needs_root"] = root
    return out


def sol(id_, name, description, symptoms, causes, diag, summary, steps, distros, risk, related):
    return {
        "id": f"SOL-{id_:04d}",
        "name": name,
        "description": description,
        "symptoms": symptoms,
        "causes": causes,
        "diagnostic_commands": diag,
        "solution": {"summary": summary, "steps": steps},
        "compatible_distros": distros,
        "risk": risk,
        "related_checks": related,
    }


SOLUTIONS = [
    sol(
        1,
        "Free up disk space",
        "The disk is almost full, so programs cannot save files and updates may fail.",
        ["Low disk space warnings", "Updates or downloads fail", "Programs crash when saving"],
        [
            "Old package downloads kept in the cache",
            "Unused packages and old kernels",
            "A very large system journal",
            "Large files in the home folder",
        ],
        [
            "df -h",
            "sudo du -xh --max-depth=1 /var | sort -h | tail -n 10",
            "journalctl --disk-usage",
        ],
        "Remove what the system can safely recreate, then look for big personal files.",
        [
            step(
                "See which folders use the most space",
                "sudo du -xh --max-depth=1 /var | sort -h | tail -n 10",
                T,
            ),
            step("Clear the downloaded package cache", "sudo apt clean", T),
            step(
                "Remove packages that are no longer needed (read the list before confirming)",
                "sudo apt autoremove --purge",
                T,
            ),
            step("Limit the system journal to 200 MB", "sudo journalctl --vacuum-size=200M", T),
            step(
                "Look through your own folders (Downloads, videos) for large files you no longer need"
            ),
        ],
        ["debian"],
        "medium",
        ["storage.space", "performance.disk"],
    ),
    sol(
        2,
        "Repair broken or half-configured packages",
        "The package database reports packages that were not installed completely.",
        ["apt prints dependency errors", "Updates stop halfway", "'dpkg was interrupted' messages"],
        [
            "An update was interrupted (power loss, closed terminal)",
            "A package failed while configuring",
        ],
        ["dpkg --audit", "apt-get check"],
        "Finish the interrupted configuration, then let apt fix dependencies.",
        [
            step(
                "Finish configuring packages that were left half-installed",
                "sudo dpkg --configure -a",
                T,
            ),
            step("Let apt repair missing dependencies", "sudo apt --fix-broken install", T),
            step("Refresh the package lists", "sudo apt update", T),
        ],
        ["debian"],
        "medium",
        ["system.packages"],
    ),
    sol(
        3,
        "Names do not resolve (DNS problem)",
        "The internet works by number but websites cannot be opened by name.",
        [
            "Browser says the server cannot be found",
            "ping 1.1.1.1 works but ping example.com fails",
        ],
        [
            "Wrong or unreachable DNS server",
            "systemd-resolved cache in a bad state",
            "Router DNS failure",
        ],
        [
            "resolvectl status",
            "cat /etc/resolv.conf",
            "ping -c 3 1.1.1.1",
            "getent hosts example.com",
        ],
        "Clear the resolver cache; if it persists, change the DNS server in the network settings.",
        [
            step("Clear the DNS cache", "sudo resolvectl flush-caches", T),
            step("Restart the local resolver", "sudo systemctl restart systemd-resolved", T),
            step("Reboot your router, or set another DNS server in the connection settings"),
        ],
        ["ubuntu"],
        "low",
        ["network.dns", "network.dns_config"],
    ),
    sol(
        4,
        "No default route (no gateway)",
        "The computer has an address but no route to leave the local network.",
        [
            "Local devices respond but no website opens",
            "Network icon shows connected without internet",
        ],
        [
            "The connection profile lost its gateway",
            "A VPN replaced or removed the route",
            "DHCP gave no router",
        ],
        ["ip route", "nmcli device status"],
        "Reconnect so the router can hand out the gateway again.",
        [
            step(
                "List the connections and note the name of the active one", "nmcli connection show"
            ),
            step("Reconnect (replace NAME with the connection name)", "nmcli connection up NAME"),
            step(
                "If it persists, restart the network service",
                "sudo systemctl restart NetworkManager",
                T,
            ),
        ],
        ["ubuntu"],
        "low",
        ["network.gateway"],
    ),
    sol(
        5,
        "Self-assigned address (169.254.x.x): DHCP did not answer",
        "The computer could not get an address from the router and invented one.",
        ["Connected but no internet", "IP address starts with 169.254"],
        ["Router DHCP is off or overloaded", "Bad cable or weak Wi-Fi", "Router needs a restart"],
        ["ip -brief address", "nmcli device status"],
        "Check the physical link, then renew the connection.",
        [
            step("Check the cable or move closer to the Wi-Fi router"),
            step(
                "Disconnect and reconnect (replace NAME with the connection name)",
                "nmcli connection down NAME",
            ),
            step("Reconnect", "nmcli connection up NAME"),
            step("Restart the router if other devices also have no address"),
        ],
        ["ubuntu"],
        "low",
        ["network.addresses"],
    ),
    sol(
        6,
        "Wi-Fi is blocked (airplane mode / rfkill)",
        "The Wi-Fi radio is switched off by software or by a hardware switch.",
        ["No Wi-Fi networks are listed", "Wi-Fi toggle is greyed out"],
        [
            "Airplane mode key (Fn) pressed",
            "Soft block by the desktop",
            "Hardware switch on the laptop",
        ],
        ["rfkill list"],
        "Switch the radio back on.",
        [
            step("Check the laptop's physical switch and the airplane-mode key"),
            step("Remove a software block on Wi-Fi", "sudo rfkill unblock wifi", T),
            step("Check the result", "rfkill list"),
        ],
        ["*"],
        "low",
        ["network.wifi"],
    ),
    sol(
        7,
        "Poor Wi-Fi signal",
        "The signal is so weak that the connection will be slow or drop.",
        ["Slow or dropping connection", "Signal bars low"],
        [
            "Distance or walls from the router",
            "Interference from other networks",
            "2.4 GHz congestion",
        ],
        ["cat /proc/net/wireless"],
        "Improve the signal path before changing software settings.",
        [
            step("Move closer to the router or remove obstacles between you and it"),
            step("Prefer the 5 GHz network if the router offers one"),
            step("Change the router channel in its settings page"),
        ],
        ["*"],
        "low",
        ["network.wifi"],
    ),
    sol(
        8,
        "Local network works but there is no internet",
        "The computer reaches the router, but nothing beyond it.",
        ["Websites do not load on this device", "Other devices may or may not work"],
        ["Internet provider outage", "Router or modem needs a restart", "Proxy or VPN settings"],
        ["ip route", "ping -c 3 1.1.1.1", "env | grep -i proxy"],
        "Find out whether the problem is this computer or the connection itself.",
        [
            step("Check whether another device on the same network has internet"),
            step("Restart the router and the modem"),
            step(
                "Check whether a VPN or proxy is active and disable it to test",
                "env | grep -i proxy",
            ),
        ],
        ["*"],
        "low",
        ["network.internet"],
    ),
    sol(
        9,
        "Memory is almost full",
        "Programs use nearly all RAM, so the computer slows down or closes programs.",
        ["Computer freezes or becomes very slow", "Programs close by themselves"],
        [
            "Too many programs or browser tabs",
            "A program leaking memory",
            "Not enough RAM for the workload",
        ],
        ["free -h", "ps aux --sort=-%mem | head -n 10"],
        "Close what is not needed; consider compressed swap in RAM (zram) for small-memory machines.",
        [
            step("Find the heaviest programs", "ps aux --sort=-%mem | head -n 10"),
            step("Close the heaviest program you do not need, or restart it"),
            step("Optionally enable compressed swap in memory", "sudo apt install zram-tools", T),
        ],
        ["debian"],
        "medium",
        ["performance.memory", "performance.swap", "performance.oom"],
    ),
    sol(
        10,
        "The processor is overloaded",
        "A program keeps the processor busy, making everything else slow.",
        ["Fans run loudly", "Computer is slow", "A program says 'not responding'"],
        ["A runaway program", "Background indexing or updates", "Malware or a crypto-miner"],
        ["top -b -n 1 | head -n 15", "ps aux --sort=-%cpu | head -n 10"],
        "Identify the busiest process before deciding what to stop.",
        [
            step("List the processes using the most CPU", "ps aux --sort=-%cpu | head -n 10"),
            step("Wait a few minutes if it is an update or indexing job, then check again"),
            step("Close the program normally; force-quit only if it does not respond"),
        ],
        ["*"],
        "low",
        ["performance.cpu", "performance.load"],
    ),
    sol(
        11,
        "Failed system services",
        "One or more background services did not start.",
        ["Some feature does not work after boot", "systemctl reports 'degraded'"],
        ["Bad configuration file", "A missing dependency", "A failed update"],
        ["systemctl --failed", "systemctl status SERVICE", "journalctl -u SERVICE -b"],
        "Read why the service failed before restarting it.",
        [
            step("List failed services", "systemctl --failed"),
            step(
                "Read the reason (replace SERVICE with the unit name)", "systemctl status SERVICE"
            ),
            step(
                "Try starting it again after fixing the cause", "sudo systemctl restart SERVICE", T
            ),
            step("Clear the failed state once it works", "sudo systemctl reset-failed", T),
        ],
        ["*"],
        "medium",
        ["system.services", "system.essential"],
    ),
    sol(
        12,
        "A restart is pending",
        "Updates were installed that only take effect after restarting.",
        ["'Restart required' notice", "New kernel installed but not running"],
        ["Kernel or core library updated"],
        ["cat /var/run/reboot-required.pkgs"],
        "Restart when convenient.",
        [step("Save your work and restart the computer from the system menu")],
        ["debian"],
        "low",
        ["system.reboot"],
    ),
    sol(
        13,
        "Graphics card is not using its proper driver",
        "The graphics card works in a basic mode, with poor performance or missing features.",
        ["Slow desktop animations", "Low resolution or wrong refresh rate", "Games run poorly"],
        [
            "Proprietary driver not installed",
            "Secure Boot blocks the driver",
            "Driver failed after a kernel update",
        ],
        [
            "lspci -nnk | grep -A3 -E 'VGA|3D'",
            "ubuntu-drivers devices",
            "lsmod | grep -E 'nvidia|nouveau|amdgpu|i915'",
        ],
        "Install the recommended driver, then restart.",
        [
            step("See which driver Ubuntu recommends", "ubuntu-drivers devices"),
            step(
                "Install the recommended driver (a restart is needed afterwards)",
                "sudo ubuntu-drivers install",
                T,
            ),
            step("If Secure Boot is on, follow the prompt to enroll the key at the next start"),
        ],
        ["ubuntu"],
        "medium",
        ["hardware.gpu"],
    ),
    sol(
        14,
        "Disk errors or read-only filesystem",
        "The kernel reported disk errors or remounted the disk read-only to protect data.",
        ["Cannot save files", "'Read-only file system' messages", "I/O errors in the kernel log"],
        ["Failing disk", "Loose or bad cable", "File system corruption after a power loss"],
        [
            "sudo dmesg --level=err,crit,alert,emerg",
            "mount | grep ' ro,'",
            "sudo smartctl -H /dev/sda",
        ],
        "Back up first. Disk errors can mean the disk is dying; repair only from a live USB.",
        [
            step("Copy your important files to another disk NOW, before anything else"),
            step("Check the disk health (smartmontools)", "sudo smartctl -H /dev/sda", T),
            step(
                "Boot from a live USB and run a check on the UNMOUNTED partition "
                "(replace PARTITION, for example sda2)",
                "sudo fsck -f /dev/PARTITION",
                T,
            ),
            step("Replace the disk if the health check reports failures"),
        ],
        ["*"],
        "high",
        ["storage.readonly", "storage.kernel_errors"],
    ),
    sol(
        15,
        "Out of inodes",
        "The disk has space left, but no more room for new file entries (inodes).",
        ["'No space left on device' although df shows free space"],
        ["Millions of tiny files (caches, mail queues, sessions)"],
        ["df -i", "sudo du --inodes -x -d 2 /var | sort -n | tail -n 10"],
        "Find the folder holding the tiny files, then clean it using its owner program's tool.",
        [
            step(
                "Find where the inodes go",
                "sudo du --inodes -x -d 2 /var | sort -n | tail -n 10",
                T,
            ),
            step("Clear the package cache", "sudo apt clean", T),
            step("Clean the program that owns the busy folder using its own cleanup option"),
        ],
        ["debian"],
        "medium",
        ["storage.inodes"],
    ),
    sol(
        16,
        "Components are too hot",
        "A sensor reports a temperature above its safe range; the computer may slow down or shut off.",
        ["Loud fans", "Sudden slowdowns", "Unexpected shutdowns"],
        ["Dust blocking vents", "Dried thermal paste", "Heavy load on a hot day"],
        ["sensors", "cat /sys/class/thermal/thermal_zone*/temp"],
        "Improve cooling first; software only helps a little.",
        [
            step("Place the computer on a hard, flat surface and keep the vents free"),
            step("Clean dust from the vents (computer off, unplugged)"),
            step("On Intel laptops, install the thermal daemon", "sudo apt install thermald", T),
        ],
        ["ubuntu"],
        "low",
        ["hardware.temperature"],
    ),
    sol(
        17,
        "Hardware errors in the kernel log",
        "The kernel logged machine-check, thermal or PCIe errors.",
        ["Random freezes or reboots", "Messages about 'Hardware Error'"],
        ["Failing RAM or CPU", "Overheating", "Outdated firmware"],
        ["sudo dmesg | grep -i -E 'mce|hardware error'", "fwupdmgr get-updates"],
        "Update firmware, test memory and check temperatures.",
        [
            step("Look for firmware updates", "fwupdmgr get-updates"),
            step("Test the memory with memtest86+ from the boot menu"),
            step("Check temperatures with 'lume hardware'"),
        ],
        ["*"],
        "medium",
        ["hardware.errors"],
    ),
    sol(
        18,
        "No network interface found",
        "The system sees no Ethernet or Wi-Fi adapter.",
        ["No network options in settings"],
        ["Missing firmware or driver", "Adapter disabled in firmware", "Unplugged USB adapter"],
        ["ip link", "lspci -nnk | grep -i -A3 net"],
        "Check that the adapter is detected and has its firmware.",
        [
            step("Check that the adapter appears", "lspci -nnk | grep -i -A3 net"),
            step("Install the firmware package", "sudo apt install linux-firmware", T),
            step("Check the firmware (BIOS/UEFI) settings for a disabled adapter"),
        ],
        ["debian"],
        "low",
        ["network.interfaces"],
    ),
    sol(
        19,
        "Out-of-memory kills",
        "The kernel closed programs because memory ran out.",
        ["A program disappears without warning", "'Killed' appears in the terminal"],
        ["More programs than memory can hold", "A memory leak"],
        ["sudo dmesg | grep -i -E 'out of memory|oom'", "free -h"],
        "Reduce memory use or add swap.",
        [
            step("Find the biggest memory users", "ps aux --sort=-%mem | head -n 10"),
            step("Close programs you are not using"),
            step("Consider more RAM or compressed swap", "sudo apt install zram-tools", T),
        ],
        ["debian"],
        "medium",
        ["performance.oom"],
    ),
]

if __name__ == "__main__":
    target = (
        Path(__file__).resolve().parent.parent / "lume" / "solutions" / "data" / "solutions.json"
    )
    document = {"schema_version": 1, "solutions": SOLUTIONS}
    target.write_text(json.dumps(document, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"wrote {len(SOLUTIONS)} solutions to {target}")
