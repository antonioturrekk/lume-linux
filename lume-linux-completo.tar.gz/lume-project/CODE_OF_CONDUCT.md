# Code of conduct

Be respectful and constructive. Welcome newcomers, assume good faith, give and accept technical
criticism gracefully, and keep discussions about the work, not the person. Harassment,
discrimination and personal attacks are not tolerated. Maintainers may remove content and block
participants who violate these rules. Report problems to the maintainers privately.
