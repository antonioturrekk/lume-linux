# Changelog

All notable changes to this project are documented here.
Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versioning follows [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added
- **Commands:** `lume diagnose`, `hardware`, `network`, `performance`, `storage`, `solutions`,
  `report`, `version`, `help` and an interactive menu.
- **Diagnostics:** distribution/kernel/platform support, privileges, kernel taint, pending
  restart, systemd state and essential services, package database (Debian family); CPU, memory,
  GPU driver, PCI, USB, disks, temperatures, hardware errors; interfaces, IP, gateway, DNS, Wi-Fi
  (rfkill, signal), internet reachability; CPU/load/memory/swap/OOM and heaviest processes; free
  space, inodes, read-only mounts, disk errors in the kernel log.
- **Solutions:** validated local JSON database (19 entries), distribution filtering, search,
  command safety screen.
- **Reports:** HTML (self-contained), Markdown and JSON, with recommendations and `--anonymize`.
- **History:** SQLite comparison with the previous diagnosis (check ids and statuses only).
- **Safety:** command allowlist with exact arguments, audit log of executed commands, sanitized
  environment, no-overwrite and `0600` report files, static security tests.
- `Status.SKIP` for checks that could not run, with the reason.
- Project foundation: packaging, GPL-3.0-or-later license, XDG paths, logging, CI workflow,
  documentation (English and pt-BR README).
