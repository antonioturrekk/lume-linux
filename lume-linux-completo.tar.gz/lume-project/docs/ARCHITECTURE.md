# LUME architecture

## Layers

Dependencies point downwards only.

```
cli ──► reports ──► diagnostics (engine) ──► system │ hardware │ network │ performance │ storage
 │          │                                              │
 │          └──► solutions                                 ▼
 └──► database (history)                                 core
```

| Package | Responsibility |
|---------|----------------|
| `lume.core` | Result model (`Status`, `CheckResult`), report model, **`Environment`** (access to the machine), safe command runner, audit log, distro detection, kernel-log access, `/proc` parsers, paths, logging |
| `lume.hardware` | CPU (`lscpu`/`/proc/cpuinfo`), memory, PCI/GPU (`lspci`), USB (`lsusb`), disks (`lsblk`), temperatures (`/sys/class/hwmon`, `thermal`) |
| `lume.network` | Interfaces and routes (`ip -j` with `/sys` + `/proc/net` fallback), DNS, Wi-Fi (`/proc/net/wireless`, rfkill), active probes |
| `lume.performance` | CPU sampling from `/proc/stat`, per-process usage from `/proc/<pid>`, load, memory, swap, OOM |
| `lume.storage` | Mounts, usage (`statvfs`), inodes, read-only mounts, partitions, disk errors in the kernel log |
| `lume.diagnostics` | `system` checks (distribution support, kernel taint, services, packages, privileges, pending restart) and the **engine** that runs every domain |
| `lume.solutions` | Data model, strict validator, command safety screen, loader, search; JSON data in `solutions/data/` |
| `lume.reports` | HTML / Markdown / JSON renderers, recommendations, anonymizer, safe writer |
| `lume.database` | SQLite history (check ids and statuses) and run comparison |
| `lume.cli` | Parser, command registry, handlers, menu, Rich rendering, exit codes |

Domain modules **return data** (`Report`); only `cli` and `reports` render it.

## Key design decisions

1. **One door to the machine.** Analyzers receive an `Environment` and never open files or start
   processes themselves. `SystemEnvironment` is the real machine; tests use `FakeEnvironment`
   with captured command output, so parsers and rules are verified without depending on the host.
2. **Prefer the kernel's own interfaces.** `/proc` and `/sys` are read directly when possible;
   tools are used when they add information (`lspci`, `lsusb`, `lsblk`, `ip`) and always checked
   first. A missing tool produces `SKIP`, never `ERROR`.
3. **Evidence is mandatory.** `CheckResult` refuses `WARN`/`ERROR` without evidence.
4. **Four statuses.** `OK`, `WARN`, `ERROR` as specified, plus `SKIP` for "could not be checked" so
   a limitation is never presented as a verdict about the system.
5. **Distribution-aware.** Commands specific to a package family (`dpkg --audit`, the
   `reboot-required` marker) run only when `Distro.family` matches; other families get `SKIP`.
6. **Failure isolation.** A bug in one analyzer is logged with its traceback and shown as a `SKIP`
   with a pointer to the log; the other domains still report.
7. **JSON for knowledge, SQLite for user data.** Solutions are reviewable in pull requests and carry
   no executable logic; the history database stores only what is needed to compare runs.
8. **Duplicates are avoided by id.** The overall diagnosis disables the per-domain disk check and
   de-duplicates by `check_id`.

## Data flow of `lume diagnose`

```
main ─► run_command ─► cmd_diagnose
          │
          ├─ run_diagnosis(env) ─► read_kernel_log ─► system / hardware / network / performance / storage
          │                                           (each returns a Report; errors are contained)
          ├─ render overview + checks (Rich)
          ├─ solutions: related_to(problem check ids, distro) ─► suggestions
          └─ history: latest() ─► record() ─► compare() ─► "new / worse / resolved"
```

## Check ids

Stable identifiers link checks, solutions and history: `system.*`, `hardware.*`, `network.*`,
`performance.*`, `storage.*`. A test ensures that every id referenced by a solution is produced by
an analyzer.

## Exit codes and errors

`ExitCode` is stable (`0` ok, `1` error, `2` usage, `4` problems found, `130` interrupted).
Expected errors derive from `LumeError`; unexpected ones are logged with a traceback and reported
with the log path.

## Extending

- **New distribution family:** extend `Distro.family`/`matches`, then add family-specific checks
  guarded by it. Add fixtures under `tests/fixtures/`.
- **New check:** return a `CheckResult` with a stable id from the domain analyzer, test it with
  `FakeEnvironment`, and (optionally) add a solution that lists the id in `related_checks`.
- **New command:** add the exact arguments to the runner allowlist with allowed/forbidden tests.
