# Using LUME

## Commands

| Command | What it does |
|---------|--------------|
| `lume` | Interactive menu (only in a terminal; otherwise prints help) |
| `lume diagnose [--offline] [--interval S] [--no-history]` | Full diagnosis: system, hardware, network, performance, storage |
| `lume hardware` | CPU, memory, GPU and driver, PCI, USB, disks, network cards, temperatures |
| `lume network [--offline]` | Interfaces, IP, Wi-Fi, gateway, DNS, connectivity |
| `lume performance [--interval S]` | CPU, RAM, swap, load, heaviest processes |
| `lume storage` | Partitions, filesystems, free space, inodes, read-only mounts, disk errors |
| `lume solutions [ID] [-s TEXT] [--all]` | Browse verified solutions |
| `lume report [-f FORMAT] [-o FILE] [--anonymize] [--offline] [--force] [--stdout]` | Export a diagnosis |
| `lume version`, `lume help [command]` | Information |

Global options (before or after the command): `--no-color` (also honors `NO_COLOR`), `-v/--verbose`
(debug details in the log), `-h/--help`, `--version`.

## Result labels

| Label | Meaning |
|-------|---------|
| `[OK]` | Normal operation |
| `[WARN]` | Possible problem — evidence is shown with `↳` |
| `[ERROR]` | Identified problem — evidence is shown with `↳` |
| `[SKIP]` | Could not be checked (missing tool, no permission, `--offline`); the reason is shown. This is **not** a verdict about your system |

## Exit codes

| Code | Meaning |
|-----:|---------|
| 0 | Success (warnings do not change the exit code) |
| 1 | Error while running (for example, a report file could not be written) |
| 2 | Invalid command line |
| 4 | The analysis finished and identified at least one `ERROR` |
| 130 | Interrupted with Ctrl+C |

## Reports

```bash
lume report                               # lume-report-<date>.html in the current folder
lume report -f markdown -o issue.md --anonymize
lume report -f json --stdout | jq .summary
```

- An existing file is **never** overwritten unless you pass `--force`.
- Files are created readable only by you (`0600`).
- `--anonymize` masks IP addresses (private ranges keep their first two numbers), MAC addresses
  (the vendor prefix is kept), IPv6, the host name, UUIDs and `/home/<user>` paths.
- HTML reports are self-contained: no scripts, no external resources.

## Permissions

LUME never asks for or uses elevated privileges and warns if run as root. Some data needs them
(for example the kernel log when `kernel.dmesg_restrict=1`). Those checks show `[SKIP]` and tell you
the command to run yourself.

## Files LUME writes

| File | Content |
|------|---------|
| `$XDG_STATE_HOME/lume/lume.log` | Application log (default `~/.local/state/lume/`) |
| `$XDG_STATE_HOME/lume/operations.log` | Audit log: every command LUME ran (JSON lines) |
| `$XDG_DATA_HOME/lume/lume.db` | History: check ids and statuses only, no evidence |
| Report files | Only where you ask |

## What changed since the last run

`lume diagnose` stores a compact history and tells you what is new, worse or resolved. Disable with
`--no-history`; delete `lume.db` any time.
