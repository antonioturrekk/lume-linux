# Security model

LUME is a **diagnostic** tool. Its promise: it does not change your system.

## Guarantees and how they are enforced

| Guarantee | Enforcement | Verified by |
|-----------|-------------|-------------|
| Only read-only commands run | Allowlist of programs **and exact argument patterns** in `lume/core/runner.py`; anything else raises `SafetyError` | `tests/test_core_runner.py` |
| No shell, no injection | Commands are argument lists; `shell=True` never used; program must be a bare name (no paths) | runner tests + `tests/test_security_static.py` |
| Only the runner starts processes | No other module imports `subprocess`/`pty` or calls `os.system`/`exec*` | static test |
| Environment is sanitized | Fixed `PATH`, `LC_ALL=C`, no `LD_PRELOAD` etc., stdin closed, output size limited, timeout | runner tests |
| Solutions are never executed | Their commands are text; the runner never receives them | `test_only_allowlisted_read_only_commands_are_requested` |
| Unsafe solution text cannot ship | Each entry is validated on load; destructive patterns (`rm`, `dd`, `mkfs`, `curl \| sh`, shutdown...) reject it | `tests/test_solutions.py` |
| No privilege escalation | LUME never runs `sudo`; unreadable data becomes `SKIP` with a hint | system checks |
| Everything is auditable | Every executed command is logged to `operations.log` | runner tests |
| Reports leak nothing by accident | Text from the system is escaped in HTML and never parsed as markup in the terminal; strict CSP in HTML; files created `0600`; no overwrite | report tests |
| Privacy | No telemetry; no serial numbers, user names or SSIDs collected; history stores no evidence; `--anonymize` | anonymizer + history tests |
| Files are written only by known modules | Log, audit log, history, report writer | static test |
| The network is touched only by the environment layer | Two bounded probes, disabled by `--offline` | static test |

## Allowed commands

`lscpu`, `lsblk -J -b -o <known columns>`, `lspci -nnk`, `lsusb`, `free`, `ip -j {addr|route} show`,
`dpkg --audit`, `dmesg --level=...`, `journalctl -k -b -p err ...`, `resolvectl dns`,
`systemctl {is-system-running | --failed ... | show --property=...}`, `ping -c 1 -W 2 <IPv4>`.

To add a command, extend `lume/core/runner.py` with the **exact** arguments, add allowed and
forbidden cases to `tests/test_core_runner.py`, and justify it in the pull request.

## Known limitations

- The allowlist protects LUME itself; it cannot protect you from commands you copy from the
  solutions list. Read them first — each step states whether it needs `sudo`, and each solution
  declares a risk level.
- Active probes reveal to the network that this machine contacted `1.1.1.1:443`, `9.9.9.9:443` and
  resolved `example.com`. Use `--offline` to avoid them.
- Anonymization is pattern-based: review a report before publishing it.

## Reporting a vulnerability

See [SECURITY.md](../SECURITY.md).
