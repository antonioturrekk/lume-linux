# Adding a solution

Solutions live in `scripts/build_solutions.py` (readable Python) and are exported to
`lume/solutions/data/solutions.json`, which LUME validates on every load.

1. Add an entry with `sol(...)` using the next free number.
2. Run `python scripts/build_solutions.py`.
3. Run `pytest tests/test_solutions.py` — it loads the JSON with the real validator.

## Fields

| Field | Rule |
|-------|------|
| `id` | `SOL-0001` format, unique |
| `name`, `description` | Plain language, for a beginner |
| `symptoms`, `causes` | At least one each |
| `diagnostic_commands` | Read-only commands the user can run to confirm the problem |
| `solution.summary`, `solution.steps` | At least one step. A step may have only a description (physical actions) |
| step `command` | Shown, never executed. If it starts with `sudo `, set `needs_root` to true (and only then) |
| `compatible_distros` | `*`, `ubuntu`, `debian`, `ubuntu>=24.04`... `debian` also matches Ubuntu and Mint; versioned expressions only match the distribution itself |
| `risk` | `low` (harmless), `medium` (changes configuration or packages), `high` (data at risk) |
| `related_checks` | Check ids (for example `storage.space`) that trigger the suggestion in `lume diagnose` and in reports |

## Rules

- No destructive commands: `rm`, `dd`, `mkfs`, `fdisk`, `curl | sh`, reboot/shutdown, recursive
  `chmod`/`chown`... are rejected automatically.
- Prefer the official, distribution-supported way (`apt`, `systemctl`, `nmcli`).
- Put "back up first" as the first step whenever data may be at risk.
- Only claim compatibility with distributions where the commands exist.
