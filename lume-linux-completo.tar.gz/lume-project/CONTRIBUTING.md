# Contributing to LUME

Thank you for helping! Please read the rules below before opening a pull request.

## Ground rules

1. **LUME diagnoses; it does not change the system.** Nothing may modify, delete or install anything.
2. **No problem without evidence.** `WARN`/`ERROR` results must include the facts that justify them
   (`CheckResult` enforces this). If a check cannot run, return `SKIP` with the reason.
3. **Only allowlisted read-only commands**, with exact arguments, through `lume/core/runner.py`.
   Never use `shell=True`, `eval`, `exec`; never execute text read from files.
4. **Read the machine only through `Environment`**, so your code can be tested with fixtures.
5. **Check tools before using them** and degrade gracefully (`ToolUnavailableError` → `SKIP`).
6. **Do not run a distribution-specific command on another distribution** — guard with `Distro`.
7. **Keep dependencies minimal.** New runtime dependencies need a strong justification.
8. **No fake functionality** and no declared feature without tests.

## Workflow

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -e ".[dev]"
pytest && ruff check . && ruff format --check . && mypy && bandit -q -r lume
```

- Type-annotate new code and add docstrings.
- Parsers must be tested with **real captured output** stored in `tests/fixtures/`.
- Add allowed *and* forbidden cases when touching the runner allowlist.
- Describe user-visible changes in `CHANGELOG.md`.
- Adding a solution? See [docs/ADDING_SOLUTIONS.md](docs/ADDING_SOLUTIONS.md).
- Security issues: see [SECURITY.md](SECURITY.md); do not open a public issue.

## Help wanted

- Validation on Ubuntu 26.04 / 26.10 hardware and on Debian, Mint, Pop!_OS.
- Fixtures of `lspci`, `lsusb`, `lsblk`, `ip -j` output from real machines.
- Support for Arch, Fedora and openSUSE package-family checks.
- Translations of the interface and the solutions database.

By contributing you agree that your work is licensed under GPL-3.0-or-later.
