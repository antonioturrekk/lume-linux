# Security policy

## Reporting a vulnerability

Please **do not open a public issue** for security problems. Report privately through the
repository's "Report a vulnerability" feature (GitHub Security Advisories) or by e-mail to the
maintainers listed in the repository profile.

Include the LUME version, the distribution, and steps to reproduce. You will get an acknowledgement
within a few days. Fixes are released with a note in `CHANGELOG.md`.

## In scope

- Any way to make LUME run a command outside the read-only allowlist.
- Any way to make LUME modify, delete or overwrite files other than its own log, audit log,
  history database and the report file the user asked for.
- Injection through data read from the system (device names, hostnames...) or from the solutions
  database into the terminal, HTML or Markdown output.
- Personal data surviving `--anonymize` in a report.

The design and its tests are described in [docs/SECURITY_MODEL.md](docs/SECURITY_MODEL.md).
