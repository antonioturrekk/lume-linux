import argparse

import pytest

from lume.cli.commands import Command
from lume.cli.registry import COMMANDS, find_command

EXPECTED_NAMES = [
    "diagnose",
    "hardware",
    "network",
    "performance",
    "storage",
    "solutions",
    "report",
    "version",
    "help",
]


def test_all_specified_commands_are_registered() -> None:
    assert [c.name for c in COMMANDS] == EXPECTED_NAMES


def test_every_specified_command_is_implemented() -> None:
    for command in COMMANDS:
        assert command.summary.strip()
        assert command.implemented and command.planned_phase is None


def test_find_command() -> None:
    assert find_command("version") is not None
    assert find_command("nope") is None


def test_command_without_handler_needs_a_phase() -> None:
    with pytest.raises(ValueError, match="planned_phase"):
        Command("x", "no handler and no phase")


@pytest.mark.parametrize("name", ["", "two words"])
def test_invalid_command_name(name: str) -> None:
    with pytest.raises(ValueError, match="invalid command name"):
        Command(name, "x", handler=lambda a, c: 0)


def test_handler_signature_is_callable() -> None:
    command = Command("x", "x", handler=lambda args, ctx: 0)
    assert command.handler is not None
    assert command.handler(argparse.Namespace(), None) == 0  # type: ignore[arg-type]
