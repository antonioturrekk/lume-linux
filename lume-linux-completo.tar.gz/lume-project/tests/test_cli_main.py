import argparse
import subprocess
import sys

import pytest

from lume import __version__
from lume.cli.commands import Command
from lume.cli.context import AppContext
from lume.cli.exit_codes import ExitCode
from lume.cli.main import main
from lume.cli.registry import COMMANDS
from lume.core import LumeError, paths


def test_version_command(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["version"]) == 0
    out = capsys.readouterr().out
    assert "LUME" in out and __version__ in out


def test_version_flag(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--version"]) == 0
    assert capsys.readouterr().out.strip() == f"LUME {__version__}"


def test_help_flag_lists_commands(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--help"]) == 0
    out = capsys.readouterr().out
    assert all(command.name in out for command in COMMANDS)


def test_help_command_without_topic(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["help"]) == 0
    assert "Usage: lume" in capsys.readouterr().out


def test_help_for_one_command(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["help", "storage"]) == 0
    assert "usage: lume storage" in capsys.readouterr().out


def test_help_for_unknown_command(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["help", "nope"]) == ExitCode.USAGE
    assert "Unknown command: nope" in capsys.readouterr().err


def test_invalid_command_is_a_usage_error(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["bogus"]) == ExitCode.USAGE
    assert "invalid choice" in capsys.readouterr().err


def test_a_registered_command_without_handler_is_honest(
    capsys: pytest.CaptureFixture[str],
) -> None:
    commands = (Command("future", "not built yet", planned_phase=12),)
    assert main(["future"], commands=commands) == ExitCode.NOT_IMPLEMENTED
    captured = capsys.readouterr()
    assert captured.out == ""  # nothing that looks like a result
    assert "not implemented yet" in captured.err and "phase 12" in captured.err


@pytest.mark.parametrize(
    "argv",
    [
        ["--no-color", "version"],
        ["version", "--no-color"],
        ["-v", "version"],
        ["version", "--verbose"],
    ],
)
def test_global_options_work_before_and_after_the_command(
    argv: list[str], capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(argv) == 0
    assert __version__ in capsys.readouterr().out


def test_verbose_enables_debug_logging(isolated_xdg: object) -> None:
    assert main(["--verbose", "version"]) == 0
    assert "DEBUG" in paths.log_file().read_text(encoding="utf-8")


def test_no_command_and_not_interactive_shows_help(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main([], interactive=False) == 0
    assert "Usage: lume" in capsys.readouterr().out


def test_no_command_and_interactive_opens_menu(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert main([], interactive=True, input_fn=lambda prompt: "q") == 0
    assert "Select an option" not in capsys.readouterr().err  # prompt goes through input_fn
    # menu banner was printed
    # (captured above is only stderr; stdout checked below)


def test_menu_content_is_printed(capsys: pytest.CaptureFixture[str]) -> None:
    main([], interactive=True, input_fn=lambda prompt: "q")
    out = capsys.readouterr().out
    assert "diagnose" in out and "q  quit" in out


def _failing(exc: BaseException) -> tuple[Command, ...]:
    def handler(args: argparse.Namespace, ctx: AppContext) -> int:
        raise exc

    return (Command("boom", "always fails", handler=handler),)


def test_expected_errors_are_reported_without_traceback(
    capsys: pytest.CaptureFixture[str],
) -> None:
    code = main(["boom"], commands=_failing(LumeError("tool exploded")))
    assert code == ExitCode.ERROR
    err = capsys.readouterr().err
    assert "Error: tool exploded" in err and "Traceback" not in err


def test_unexpected_errors_are_logged_and_not_hidden(
    capsys: pytest.CaptureFixture[str],
) -> None:
    code = main(["boom"], commands=_failing(RuntimeError("bug here")))
    assert code == ExitCode.ERROR
    err = capsys.readouterr().err
    assert "Unexpected error" in err and str(paths.log_file()) in err
    log_text = paths.log_file().read_text(encoding="utf-8")
    assert "RuntimeError: bug here" in log_text and "Traceback" in log_text


def test_keyboard_interrupt(capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["boom"], commands=_failing(KeyboardInterrupt())) == ExitCode.INTERRUPTED
    assert "Interrupted." in capsys.readouterr().err


def test_handler_exit_code_is_propagated() -> None:
    commands = (Command("two", "returns 7", handler=lambda args, ctx: 7),)
    assert main(["two"], commands=commands) == 7


def test_real_process_via_python_dash_m() -> None:
    ok = subprocess.run(
        [sys.executable, "-m", "lume", "version"], capture_output=True, text=True, check=False
    )
    assert ok.returncode == 0 and __version__ in ok.stdout
    solutions = subprocess.run(
        [sys.executable, "-m", "lume", "solutions"], capture_output=True, text=True, check=False
    )
    assert solutions.returncode == 0 and "SOL-" in solutions.stdout


def test_exit_code_conversion() -> None:
    from lume.cli.main import _exit_code

    assert _exit_code(None) == 0
    assert _exit_code(5) == 5
    assert _exit_code("some message") == ExitCode.ERROR


def test_entrypoint_exits_with_the_command_code(monkeypatch: pytest.MonkeyPatch) -> None:
    from lume.cli import main as main_module

    monkeypatch.setattr(main_module, "main", lambda: 42)
    with pytest.raises(SystemExit) as info:
        main_module.entrypoint()
    assert info.value.code == 42


def test_run_command_with_unknown_name(capsys: pytest.CaptureFixture[str]) -> None:
    from lume.cli.parser import build_parser
    from lume.cli.registry import run_command
    from lume.cli.theme import make_console

    console, err = make_console(), make_console(stderr=True)
    parser, subs = build_parser(console, COMMANDS)
    ctx = AppContext(console, err, parser, subs, COMMANDS)
    assert run_command("ghost", argparse.Namespace(), ctx) == ExitCode.USAGE
    assert "Unknown command: ghost" in capsys.readouterr().err
