from lume.core import units
from lume.core.distro import Distro, detect, is_valid_spec, parse_os_release
from lume.core.exceptions import ToolUnavailableError
from lume.core.kernel_log import STORAGE_RE, read_kernel_log
from lume.core.procfs import parse_loadavg, parse_meminfo, parse_stat, parse_uptime
from tests.helpers import FakeEnvironment, result

UBUNTU = """NAME="Ubuntu"
VERSION="26.04 LTS (Resolute Raccoon)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 26.04 LTS"
VERSION_ID="26.04"
VERSION_CODENAME=resolute
UBUNTU_CODENAME=resolute
"""
MINT = """NAME="Linux Mint"
ID=linuxmint
ID_LIKE="ubuntu debian"
PRETTY_NAME="Linux Mint 22"
VERSION_ID="22"
UBUNTU_CODENAME=noble
"""


def test_parse_ubuntu() -> None:
    d = parse_os_release(UBUNTU)
    assert (d.id, d.version_id, d.version_codename, d.family) == (
        "ubuntu",
        "26.04",
        "resolute",
        "debian",
    )
    assert d.is_ubuntu_based and d.pretty_name == "Ubuntu 26.04 LTS"


def test_derivatives_and_families() -> None:
    mint = parse_os_release(MINT)
    assert mint.is_ubuntu_based and mint.family == "debian" and mint.version_codename == "noble"
    assert parse_os_release("ID=arch").family == "arch"
    assert parse_os_release("ID=fedora").family == "fedora"
    assert parse_os_release('ID=opensuse-tumbleweed\nID_LIKE="opensuse suse"').family == "suse"
    assert parse_os_release("ID=gentoo").family == "unknown"


def test_spec_matching() -> None:
    ubuntu, mint, arch = (
        parse_os_release(UBUNTU),
        parse_os_release(MINT),
        parse_os_release("ID=arch"),
    )
    assert ubuntu.matches("*") and ubuntu.matches("ubuntu") and ubuntu.matches("debian")
    assert ubuntu.matches("ubuntu>=24.04") and not ubuntu.matches("ubuntu<24.04")
    assert ubuntu.matches("ubuntu=26.04") and not ubuntu.matches("ubuntu>26.04")
    assert mint.matches("ubuntu") and mint.matches("debian")
    assert not mint.matches("ubuntu>=24.04")  # derivative version numbers are not Ubuntu's
    assert not arch.matches("ubuntu") and not ubuntu.matches("garbage spec!")
    assert ubuntu.matches_any(["fedora", "ubuntu"]) and not ubuntu.matches_any([])


def test_spec_validation() -> None:
    assert all(is_valid_spec(s) for s in ("*", "ubuntu", "ubuntu>=24.04", "debian"))
    assert not any(is_valid_spec(s) for s in ("", "Ubuntu >= x", "ubuntu>=", "a b"))


def test_detect_reads_fallback_and_defaults() -> None:
    assert detect(FakeEnvironment({"/usr/lib/os-release": UBUNTU})).id == "ubuntu"
    assert detect(FakeEnvironment()) == Distro()


def test_procfs_parsers() -> None:
    mem = parse_meminfo("MemTotal:  1000 kB\nMemAvailable:   250 kB\nHugePages_Total:  0\nbad\n")
    assert mem["MemTotal"] == 1_024_000 and mem["HugePages_Total"] == 0
    load = parse_loadavg("0.52 1.00 2.50 1/300 999")
    assert load is not None and (load.one, load.five, load.fifteen) == (0.52, 1.0, 2.5)
    assert parse_loadavg("garbage") is None
    stat = parse_stat(
        "cpu  10 0 20 100 5 0 0 0 0 0\ncpu0 5 0 10 50 2 0 0 0\ncpu1 5 0 10 50 3 0 0 0\nintr 1"
    )
    assert stat is not None and stat.total == 135 and stat.idle == 105 and stat.cpu_count == 2
    assert parse_stat("nothing") is None
    assert parse_uptime("12345.67 999.0") == 12345.67 and parse_uptime("") is None


def test_units() -> None:
    assert units.format_bytes(512) == "512 B"
    assert units.format_bytes(1536) == "1.5 KiB"
    assert units.format_bytes(8 * 1024**3) == "8.0 GiB"
    assert units.format_percent(92.4) == "92%"
    assert units.format_duration(90_000) == "1 d 1 h"
    assert units.format_duration(7500) == "2 h 5 min"
    assert units.format_duration(600) == "10 min"


def test_kernel_log_available_empty_and_denied() -> None:
    dmesg = ("dmesg", "--level=err,crit,alert,emerg")
    journal = ("journalctl", "-k", "-b", "-p", "err", "--no-pager", "-q", "-n", "200")
    env = FakeEnvironment(
        commands={dmesg: result("[1.0] EXT4-fs error (device sda1): bad\n[2.0] other\n")}
    )
    log = read_kernel_log(env)
    assert log.available and len(log.lines) == 2 and len(log.matching(STORAGE_RE)) == 1

    assert read_kernel_log(FakeEnvironment(commands={dmesg: result("")})).lines == ()

    denied = FakeEnvironment(commands={dmesg: result("", 1, "Operation not permitted")})
    log = read_kernel_log(denied)
    assert not log.available and "sudo dmesg" in (log.unavailable_reason or "")

    fallback = FakeEnvironment(
        commands={dmesg: ToolUnavailableError("dmesg"), journal: result("Nov 1 kernel: oom-kill\n")}
    )
    assert read_kernel_log(fallback).lines == ("Nov 1 kernel: oom-kill",)

    nothing = read_kernel_log(FakeEnvironment())
    assert not nothing.available and "neither dmesg nor journalctl" in (
        nothing.unavailable_reason or ""
    )
