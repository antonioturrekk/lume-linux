import pytest

from lume.core import paths
from lume.core.exceptions import SafetyError, ToolUnavailableError
from lume.core.runner import run_command, validate_command

ALLOWED = [
    ["lscpu"],
    ["lsblk", "-J", "-b", "-o", "NAME,TYPE,SIZE,MODEL,ROTA,RM,TRAN,FSTYPE,MOUNTPOINT"],
    ["lspci", "-nnk"],
    ["lsusb"],
    ["free", "-b"],
    ["ip", "-j", "addr", "show"],
    ["ip", "-j", "route", "show"],
    ["dpkg", "--audit"],
    ["dmesg", "--level=err,crit,alert,emerg"],
    ["systemctl", "is-system-running"],
    ["systemctl", "--failed", "--no-legend", "--plain", "--no-pager"],
    [
        "systemctl",
        "show",
        "--no-pager",
        "--property=LoadState,ActiveState,SubState",
        "dbus.service",
    ],
    ["ping", "-c", "1", "-W", "2", "192.168.0.1"],
    ["resolvectl", "dns"],
]

FORBIDDEN = [
    [],
    ["rm", "-rf", "/"],
    ["/bin/ls"],
    ["./lscpu"],
    ["sudo", "lscpu"],
    ["sh", "-c", "lscpu"],
    ["lscpu", "--something"],
    ["ip", "-j", "link", "set", "eth0", "down"],
    ["ip", "addr", "add", "10.0.0.1/24", "dev", "eth0"],
    ["systemctl", "restart", "ssh.service"],
    ["systemctl", "show", "--no-pager", "--property=LoadState,ActiveState,SubState", "x; rm -rf /"],
    ["systemctl", "show", "--no-pager", "--property=LoadState,ActiveState,SubState", "../x"],
    ["ping", "-c", "100", "-W", "2", "8.8.8.8"],
    ["ping", "-c", "1", "-W", "2", "example.com"],
    ["ping", "-c", "1", "-W", "2", "999.1.1.1"],
    ["lsblk", "-J", "-b", "-o", "NAME;rm"],
    ["lspci", "-q"],
    ["dpkg", "--configure", "-a"],
    ["apt-get", "install", "x"],
    ["lscpu\n"],
]


@pytest.mark.parametrize("argv", ALLOWED)
def test_allowed_commands_pass_validation(argv: list[str]) -> None:
    validate_command(argv)


@pytest.mark.parametrize("argv", FORBIDDEN)
def test_everything_else_is_blocked(argv: list[str]) -> None:
    with pytest.raises(SafetyError):
        validate_command(argv)


def test_forbidden_commands_never_reach_the_system() -> None:
    with pytest.raises(SafetyError):
        run_command(["rm", "-rf", "/tmp/whatever"])


def test_missing_tool_raises_tool_unavailable(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("lume.core.runner.shutil.which", lambda name: None)
    with pytest.raises(ToolUnavailableError):
        run_command(["lspci", "-nnk"])


def test_real_command_runs_and_is_audited() -> None:
    result = run_command(["lscpu"])
    assert result.ok and result.stdout.strip()
    text = paths.audit_log_file().read_text(encoding="utf-8")
    assert '"action": "command"' in text and '"lscpu"' in text
