from lume.core import (
    LumeError,
    SafetyError,
    ToolUnavailableError,
    UnsupportedPlatformError,
)


def test_all_errors_share_a_base_class() -> None:
    for exc in (SafetyError, UnsupportedPlatformError):
        assert issubclass(exc, LumeError)
    assert issubclass(ToolUnavailableError, LumeError)


def test_tool_unavailable_keeps_tool_name() -> None:
    error = ToolUnavailableError("lspci")
    assert error.tool == "lspci"
    assert "lspci" in str(error)
