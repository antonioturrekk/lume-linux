"""Test doubles: a fake machine fed with captured files and command output."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path

from lume.core.environment import DiskUsage
from lume.core.exceptions import ToolUnavailableError
from lume.core.runner import CommandResult

FIXTURES = Path(__file__).parent / "fixtures"


def fixture(name: str) -> str:
    """Return the text of ``tests/fixtures/<name>``."""
    return (FIXTURES / name).read_text(encoding="utf-8")


def result(stdout: str = "", returncode: int = 0, stderr: str = "") -> CommandResult:
    return CommandResult(("fake",), returncode, stdout, stderr)


class FakeEnvironment:
    """An in-memory machine.

    Attributes:
        files: path -> text.
        commands: argv tuple -> CommandResult or exception to raise.
        sleep_updates: file updates applied, in order, each time ``sleep`` is called.
    """

    def __init__(
        self,
        files: dict[str, str] | None = None,
        commands: dict[tuple[str, ...], CommandResult | Exception] | None = None,
        *,
        euid: int = 1000,
        disks: dict[str, DiskUsage] | None = None,
        ipv4: dict[str, tuple[str, int]] | None = None,
        resolve: dict[str, list[str] | Exception] | None = None,
        tcp: dict[tuple[str, int], float | Exception] | None = None,
        sleep_updates: list[dict[str, str]] | None = None,
        machine: str = "x86_64",
    ) -> None:
        self.files = dict(files or {})
        self.commands = dict(commands or {})
        self.euid = euid
        self.disks = dict(disks or {})
        self.ipv4 = dict(ipv4 or {})
        self.resolve = dict(resolve or {})
        self.tcp = dict(tcp or {})
        self.sleep_updates = list(sleep_updates or [])
        self.arch = machine
        self.executed: list[tuple[str, ...]] = []
        self.slept: list[float] = []

    def read_text(self, path: str) -> str | None:
        return self.files.get(path)

    def listdir(self, path: str) -> list[str]:
        prefix = path.rstrip("/") + "/"
        names = {p[len(prefix) :].split("/")[0] for p in self.files if p.startswith(prefix)}
        return sorted(names)

    def exists(self, path: str) -> bool:
        if path in self.files:
            return True
        prefix = path.rstrip("/") + "/"
        return any(p.startswith(prefix) for p in self.files)

    def run(self, argv: Sequence[str], *, timeout: float = 10.0) -> CommandResult:
        key = tuple(argv)
        self.executed.append(key)
        outcome = self.commands.get(key)
        if outcome is None:
            raise ToolUnavailableError(key[0])
        if isinstance(outcome, Exception):
            raise outcome
        return outcome

    def disk_usage(self, path: str) -> DiskUsage | None:
        return self.disks.get(path)

    def sleep(self, seconds: float) -> None:
        self.slept.append(seconds)
        if self.sleep_updates:
            self.files.update(self.sleep_updates.pop(0))

    def geteuid(self) -> int:
        return self.euid

    def machine(self) -> str:
        return self.arch

    def page_size(self) -> int:
        return 4096

    def now(self) -> datetime:
        return datetime(2026, 11, 15, 12, 0, 0, tzinfo=UTC)

    def interface_ipv4(self, name: str) -> tuple[str, int] | None:
        return self.ipv4.get(name)

    def resolve_host(self, host: str, timeout: float) -> list[str]:
        outcome = self.resolve.get(host)
        if outcome is None:
            raise OSError("Name or service not known")
        if isinstance(outcome, Exception):
            raise outcome
        return outcome

    def tcp_connect(self, host: str, port: int, timeout: float) -> float:
        outcome = self.tcp.get((host, port))
        if outcome is None:
            raise OSError("Network is unreachable")
        if isinstance(outcome, Exception):
            raise outcome
        return outcome
