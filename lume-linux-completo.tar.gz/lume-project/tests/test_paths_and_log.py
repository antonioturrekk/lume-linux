import logging
from pathlib import Path

import pytest

from lume.core import log, paths


def test_xdg_variables_are_respected(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "cfg"))
    assert paths.log_file() == tmp_path / "state" / "lume" / "lume.log"
    assert paths.audit_log_file() == tmp_path / "state" / "lume" / "operations.log"
    assert paths.database_file() == tmp_path / "data" / "lume" / "lume.db"
    assert paths.config_dir() == tmp_path / "cfg" / "lume"


def test_relative_xdg_value_is_ignored(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XDG_STATE_HOME", "relative/path")
    assert paths.state_dir() == Path.home() / ".local" / "state" / "lume"


def test_paths_do_not_create_anything(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
    paths.log_file()
    assert not (tmp_path / "state").exists()


def test_setup_logging_writes_to_file(tmp_path: Path) -> None:
    target = tmp_path / "logs" / "lume.log"
    logger = log.setup_logging(logging.INFO, target)
    log.get_logger("test").info("hello phase one")
    for handler in logger.handlers:
        handler.flush()
    assert "hello phase one" in target.read_text(encoding="utf-8")
    log.setup_logging(logging.INFO, tmp_path / "other.log")  # closes the handler above


def test_setup_logging_is_idempotent(tmp_path: Path) -> None:
    log.setup_logging(logging.INFO, tmp_path / "a.log")
    logger = log.setup_logging(logging.INFO, tmp_path / "b.log")
    assert len(logger.handlers) == 1


def test_setup_logging_survives_unwritable_location(tmp_path: Path) -> None:
    blocker = tmp_path / "file"
    blocker.write_text("not a directory")
    logger = log.setup_logging(logging.INFO, blocker / "lume.log")
    assert isinstance(logger.handlers[0], logging.NullHandler)
    log.get_logger("x").error("must not crash")
