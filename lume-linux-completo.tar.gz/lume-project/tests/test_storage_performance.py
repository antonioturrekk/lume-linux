import json

from lume.core import Status
from lume.core.environment import DiskUsage
from lume.core.kernel_log import KernelLog
from lume.performance import analyze as analyze_performance
from lume.performance.processes import parse_proc_stat
from lume.storage import analyze as analyze_storage
from lume.storage.mounts import parse_mounts, real_mounts
from tests.helpers import FakeEnvironment, fixture, result

GIB = 1024**3
CLEAN = KernelLog(())
LSBLK = ("lsblk", "-J", "-b", "-o", "NAME,TYPE,SIZE,MODEL,ROTA,RM,TRAN,FSTYPE,MOUNTPOINT")

MOUNTS = """sysfs /sys sysfs rw,nosuid 0 0
proc /proc proc rw 0 0
/dev/nvme0n1p2 / ext4 rw,relatime 0 0
tmpfs /run tmpfs rw 0 0
/dev/nvme0n1p1 /boot/efi vfat rw 0 0
/dev/sda1 /mnt/my\\040data fuseblk rw 0 0
/dev/loop0 /snap/core/1 squashfs ro 0 0
gvfsd-fuse /run/user/1000/gvfs fuse.gvfsd-fuse rw 0 0
/dev/nvme0n1p2 /var/lib/docker/bind ext4 rw 0 0
"""


def usage(total_gib: float, used_percent: float, inodes_percent: float = 10.0) -> DiskUsage:
    total = int(total_gib * GIB)
    used = int(total * used_percent / 100)
    inodes = 1_000_000
    return DiskUsage(total, used, total - used, inodes, int(inodes * (1 - inodes_percent / 100)))


def check(report, check_id):
    return next(c for c in report.checks if c.check_id == check_id)


def storage_env(root_percent=40.0, mounts=MOUNTS, **kw):
    return FakeEnvironment(
        {"/proc/self/mounts": mounts},
        {LSBLK: result(fixture("lsblk_laptop.json"))},
        disks={
            "/": usage(100, root_percent, kw.get("inodes", 10.0)),
            "/boot/efi": usage(1, 8),
            "/mnt/my data": usage(900, 55),
        },
    )


# ---------- storage ----------
def test_mount_parsing_and_filtering() -> None:
    mounts = parse_mounts(MOUNTS)
    assert next(m for m in mounts if m.fstype == "fuseblk").target == "/mnt/my data"
    real = {m.target for m in real_mounts(mounts)}
    assert real == {"/", "/boot/efi", "/mnt/my data"}  # no pseudo/snap/fuse; bind mount deduped


def test_healthy_storage() -> None:
    report = analyze_storage(storage_env(), kernel_log=CLEAN)
    assert all(c.status is Status.OK for c in report.checks)
    assert check(report, "storage.partitions").summary == "3 partition(s) on 3 disk(s)"
    assert "fullest: /mnt/my data at 55%" in check(report, "storage.space").summary
    titles = [s.title for s in report.sections]
    assert titles == ["Partitions", "Filesystems"]
    json.dumps(report.to_dict())


def test_space_thresholds() -> None:
    warn = check(analyze_storage(storage_env(92), kernel_log=CLEAN), "storage.space")
    assert warn.status is Status.WARN and warn.evidence[0].startswith("/: 92% used")
    err = check(analyze_storage(storage_env(98), kernel_log=CLEAN), "storage.space")
    assert err.status is Status.ERROR and "almost full" in err.summary
    edge = check(analyze_storage(storage_env(89.9), kernel_log=CLEAN), "storage.space")
    assert edge.status is Status.OK


def test_inode_exhaustion_with_free_space() -> None:
    report = analyze_storage(storage_env(30, inodes=98.0), kernel_log=CLEAN)
    assert check(report, "storage.space").status is Status.OK
    assert check(report, "storage.inodes").status is Status.ERROR


def test_readonly_root_is_an_error_but_readonly_data_disk_is_a_warning() -> None:
    root_ro = MOUNTS.replace("/ ext4 rw,relatime", "/ ext4 ro,relatime")
    found = check(
        analyze_storage(storage_env(mounts=root_ro), kernel_log=CLEAN), "storage.readonly"
    )
    assert found.status is Status.ERROR and "/dev/nvme0n1p2" in found.evidence[0]
    data_ro = MOUNTS.replace("fuseblk rw", "fuseblk ro")
    found = check(
        analyze_storage(storage_env(mounts=data_ro), kernel_log=CLEAN), "storage.readonly"
    )
    assert found.status is Status.WARN


def test_snap_images_being_readonly_is_not_a_problem() -> None:
    assert (
        check(analyze_storage(storage_env(), kernel_log=CLEAN), "storage.readonly").status
        is Status.OK
    )


def test_kernel_log_storage_errors() -> None:
    warn = KernelLog(("blk_update_request: I/O error, dev sdb, sector 0",))
    found = check(analyze_storage(storage_env(), kernel_log=warn), "storage.kernel_errors")
    assert found.status is Status.WARN and "sdb" in found.evidence[0]
    critical = KernelLog(("EXT4-fs error (device nvme0n1p2): bad block",))
    assert (
        check(analyze_storage(storage_env(), kernel_log=critical), "storage.kernel_errors").status
        is Status.ERROR
    )
    denied = KernelLog(unavailable_reason="needs permission (sudo dmesg)")
    assert (
        check(analyze_storage(storage_env(), kernel_log=denied), "storage.kernel_errors").status
        is Status.SKIP
    )


def test_storage_without_tools_or_proc() -> None:
    report = analyze_storage(FakeEnvironment(), kernel_log=CLEAN)
    assert {c.status for c in report.checks if c.check_id != "storage.kernel_errors"} == {
        Status.SKIP
    }


# ---------- performance ----------
def proc_stat(name: str, utime: int, stime: int = 0) -> str:
    return f"1 ({name}) S 0 1 1 0 -1 4194304 0 0 0 0 {utime} {stime} 0 0 20 0 1 0 1 0 0"


def perf_env(
    *, busy: bool = False, mem_available_kb=4_000_000, swap_free_kb=2_000_000, load="0.5 0.5 0.5"
):
    first = {
        "/proc/stat": "cpu  1000 0 500 8000 500 0 0 0\ncpu0 500 0 250 4000 250 0 0 0\ncpu1 500 0 250 4000 250 0 0 0\n",
        "/proc/loadavg": f"{load} 1/100 5\n",
        "/proc/meminfo": (
            f"MemTotal: 8000000 kB\nMemAvailable: {mem_available_kb} kB\n"
            f"SwapTotal: 2000000 kB\nSwapFree: {swap_free_kb} kB\n"
        ),
        "/proc/100/stat": proc_stat("firefox", 100),
        "/proc/100/statm": "1000 250000 0 0 0 0 0",
        "/proc/200/stat": proc_stat("idle (daemon)", 5, 5),
        "/proc/200/statm": "10 500 0 0 0 0 0",
        "/proc/self/mounts": "/dev/vda1 / ext4 rw 0 0\n",
    }
    # 1 second later: 200 ticks elapsed on 2 CPUs => 100 ticks per CPU
    if busy:
        second = {
            "/proc/stat": "cpu  1190 0 600 8010 500 0 0 0\ncpu0 595 0 300 4005 250 0 0 0\ncpu1 595 0 300 4005 250 0 0 0\n",
            "/proc/100/stat": proc_stat("firefox", 190),
        }
    else:
        second = {
            "/proc/stat": "cpu  1010 0 510 8180 500 0 0 0\ncpu0 505 0 255 4090 250 0 0 0\ncpu1 505 0 255 4090 250 0 0 0\n",
            "/proc/100/stat": proc_stat("firefox", 110),
        }
    return FakeEnvironment(first, sleep_updates=[second], disks={"/": usage(50, 40)})


def test_parse_proc_stat_handles_odd_names() -> None:
    assert parse_proc_stat(proc_stat("a b) (c", 7, 3)) == ("a b) (c", 10)
    assert parse_proc_stat("garbage") is None
    assert parse_proc_stat("1 (x) S 0") is None


def test_idle_system_is_ok_and_samples_after_sleeping() -> None:
    env = perf_env()
    report = analyze_performance(env, interval=2.0, kernel_log=CLEAN)
    assert env.slept == [2.0]
    assert all(c.status is Status.OK for c in report.checks), [
        c for c in report.checks if c.status is not Status.OK
    ]
    assert check(report, "performance.cpu").summary == "10% busy (2 threads)"
    cpu_table = next(s for s in report.sections if s.title == "Top processes by CPU")
    assert cpu_table.rows[0][:2] == ("100", "firefox") and cpu_table.rows[0][2] == "10%"
    mem_table = next(s for s in report.sections if s.title == "Top processes by memory")
    assert mem_table.rows[0][2] == "976.6 MiB"


def test_busy_cpu_names_the_culprit() -> None:
    report = analyze_performance(perf_env(busy=True), kernel_log=CLEAN)
    found = check(report, "performance.cpu")
    assert found.status is Status.WARN
    assert any("firefox" in e and "60% of one core" in e for e in found.evidence)


def test_memory_and_swap_thresholds() -> None:
    low = analyze_performance(perf_env(mem_available_kb=1_000_000), kernel_log=CLEAN)
    assert check(low, "performance.memory").status is Status.WARN
    assert any("firefox" in e for e in check(low, "performance.memory").evidence)
    critical = analyze_performance(perf_env(mem_available_kb=200_000), kernel_log=CLEAN)
    assert check(critical, "performance.memory").status is Status.ERROR
    swapping = analyze_performance(perf_env(swap_free_kb=200_000), kernel_log=CLEAN)
    assert check(swapping, "performance.swap").status is Status.WARN  # plenty of RAM left
    worst = analyze_performance(
        perf_env(mem_available_kb=500_000, swap_free_kb=200_000), kernel_log=CLEAN
    )
    assert check(worst, "performance.swap").status is Status.ERROR


def test_load_is_judged_per_thread() -> None:
    assert (
        check(
            analyze_performance(perf_env(load="1.0 1.0 1.0"), kernel_log=CLEAN), "performance.load"
        ).status
        is Status.OK
    )
    heavy = analyze_performance(perf_env(load="4.0 4.0 3.0"), kernel_log=CLEAN)
    assert check(heavy, "performance.load").status is Status.WARN


def test_oom_kills_are_reported() -> None:
    log = KernelLog(("Out of memory: Killed process 1234 (chrome)",))
    found = check(analyze_performance(perf_env(), kernel_log=log), "performance.oom")
    assert found.status is Status.WARN and "chrome" in found.evidence[0]


def test_disk_check_can_be_excluded() -> None:
    assert (
        check(analyze_performance(perf_env(), kernel_log=CLEAN), "performance.disk").status
        is Status.OK
    )
    ids = {
        c.check_id
        for c in analyze_performance(perf_env(), include_disk=False, kernel_log=CLEAN).checks
    }
    assert "performance.disk" not in ids


def test_performance_without_proc_is_skipped_not_failed() -> None:
    report = analyze_performance(FakeEnvironment(), kernel_log=CLEAN)
    assert {c.status for c in report.checks if c.check_id != "performance.oom"} == {Status.SKIP}
