import pytest

from lume.core import CheckResult, Status, summarize


def test_ok_result_needs_no_evidence() -> None:
    result = CheckResult("Memory analysis", Status.OK, "8 GiB available")
    assert result.status is Status.OK


@pytest.mark.parametrize("status", [Status.WARN, Status.ERROR])
def test_problem_without_evidence_is_rejected(status: Status) -> None:
    with pytest.raises(ValueError, match="requires evidence"):
        CheckResult("Graphics driver", status, "something is wrong")


def test_problem_with_evidence_is_accepted() -> None:
    result = CheckResult(
        "Graphics driver", Status.WARN, "Using generic driver", ("lspci: driver=vesafb",)
    )
    assert result.evidence == ("lspci: driver=vesafb",)


def test_empty_name_is_rejected() -> None:
    with pytest.raises(ValueError):
        CheckResult("  ", Status.OK, "x")


def test_result_is_immutable() -> None:
    result = CheckResult("a", Status.OK, "x")
    with pytest.raises(AttributeError):
        result.status = Status.ERROR  # type: ignore[misc]


def test_to_dict_is_json_friendly() -> None:
    import json

    result = CheckResult("Disk", Status.ERROR, "full", ("df: 100%",))
    assert json.loads(json.dumps(result.to_dict()))["status"] == "ERROR"


def test_summarize_counts_every_status() -> None:
    results = [
        CheckResult("a", Status.OK, "x"),
        CheckResult("b", Status.WARN, "x", ("e",)),
        CheckResult("c", Status.WARN, "x", ("e",)),
    ]
    assert summarize(results) == {Status.OK: 1, Status.WARN: 2, Status.ERROR: 0, Status.SKIP: 0}
    assert summarize([]) == dict.fromkeys(Status, 0)


def test_skip_needs_no_evidence_and_helpers_build_results() -> None:
    from lume.core import error, ok, skip, warn

    assert skip("x.y", "Thing", "lspci not installed").status is Status.SKIP
    assert ok("a.b", "A", "fine").check_id == "a.b"
    assert warn("a.c", "A", "hmm", ["proof"]).status is Status.WARN
    with pytest.raises(ValueError):
        error("a.d", "A", "bad", [])
