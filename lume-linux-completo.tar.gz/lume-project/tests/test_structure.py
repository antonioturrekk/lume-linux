"""PHASE 1: the project skeleton matches the documented architecture."""

import importlib
import re
import tomllib
from pathlib import Path

import pytest

import lume

ROOT = Path(__file__).resolve().parent.parent

SUBPACKAGES = [
    "core",
    "diagnostics",
    "hardware",
    "network",
    "performance",
    "storage",
    "solutions",
    "reports",
    "database",
    "cli",
]


@pytest.mark.parametrize("name", SUBPACKAGES)
def test_subpackage_is_importable_and_documented(name: str) -> None:
    module = importlib.import_module(f"lume.{name}")
    assert module.__doc__ and module.__doc__.strip(), f"lume.{name} needs a docstring"


@pytest.mark.parametrize(
    "relative",
    [
        "README.md",
        "LICENSE",
        "CONTRIBUTING.md",
        "CHANGELOG.md",
        "pyproject.toml",
        ".gitignore",
        "docs/ARCHITECTURE.md",
        "docs/USAGE.md",
        "docs/SECURITY_MODEL.md",
        "docs/ADDING_SOLUTIONS.md",
        "SECURITY.md",
        "README.pt-BR.md",
        ".github/workflows/ci.yml",
        "scripts/build_solutions.py",
        "lume/solutions/data/solutions.json",
        "lume/solutions/data",
    ],
)
def test_required_project_files_exist(relative: str) -> None:
    assert (ROOT / relative).exists(), f"missing: {relative}"


def test_version_has_a_single_source_of_truth() -> None:
    assert re.fullmatch(r"\d+\.\d+\.\d+(\.dev\d+)?", lume.__version__)
    data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert "version" in data["project"]["dynamic"]
    assert "version" not in data["project"]


def test_runtime_dependencies_stay_minimal() -> None:
    data = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    deps = data["project"]["dependencies"]
    assert len(deps) == 1 and deps[0].startswith("rich")


def test_license_is_gpl3() -> None:
    text = (ROOT / "LICENSE").read_text(encoding="utf-8")
    assert "GNU GENERAL PUBLIC LICENSE" in text and "Version 3" in text
