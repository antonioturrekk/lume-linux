import json

from lume.core import Status
from lume.core.exceptions import CommandTimeoutError
from lume.core.kernel_log import KernelLog
from lume.hardware import analyze
from lume.hardware.cpu import parse_cpuinfo, parse_lscpu, read_cpu
from lume.hardware.disks import parse_lsblk, real_devices
from lume.hardware.pci import parse_lspci
from lume.hardware.sensors import read_temperatures
from lume.hardware.usb import parse_lsusb
from tests.helpers import FakeEnvironment, fixture, result

LSBLK = ("lsblk", "-J", "-b", "-o", "NAME,TYPE,SIZE,MODEL,ROTA,RM,TRAN,FSTYPE,MOUNTPOINT")
MEMINFO = "MemTotal: 16384000 kB\nMemAvailable: 8192000 kB\nSwapTotal: 2097152 kB\n"
CLEAN_LOG = KernelLog(())


def check(report, check_id):
    return next(c for c in report.checks if c.check_id == check_id)


def laptop_env(**extra):
    commands = {
        ("lscpu",): result(fixture("lscpu_i5.txt")),
        ("lspci", "-nnk"): result(fixture("lspci_laptop.txt")),
        ("lsusb",): result(fixture("lsusb.txt")),
        LSBLK: result(fixture("lsblk_laptop.json")),
    }
    files = {"/proc/meminfo": MEMINFO, "/sys/class/net/enp3s0/operstate": "up\n"}
    files.update(extra.pop("files", {}))
    return FakeEnvironment(files, commands, **extra)


def test_parse_lscpu_desktop_and_vm() -> None:
    cpu = parse_lscpu(fixture("lscpu_i5.txt"))
    assert cpu is not None
    assert cpu.model == "11th Gen Intel(R) Core(TM) i5-1135G7 @ 2.40GHz"
    assert (cpu.cores, cpu.logical, cpu.sockets, cpu.max_mhz) == (4, 8, 1, 4200.0)
    vm = parse_lscpu(fixture("lscpu_vm.txt"))
    assert vm is not None and vm.hypervisor == "KVM" and vm.cores == 1
    assert parse_lscpu("nothing useful") is None


def test_parse_cpuinfo_fallbacks() -> None:
    x86 = parse_cpuinfo(fixture("cpuinfo_x86.txt"), "x86_64")
    assert x86 is not None and (x86.logical, x86.cores) == (2, 6) and "Ryzen" in x86.model
    arm = parse_cpuinfo(fixture("cpuinfo_arm.txt"), "aarch64")
    assert (
        arm is not None
        and arm.logical == 4
        and arm.model == "BCM2711 (Raspberry Pi 4 Model B Rev 1.4)"
    )
    assert parse_cpuinfo("", "x86_64") is None


def test_read_cpu_falls_back_when_lscpu_is_missing() -> None:
    env = FakeEnvironment({"/proc/cpuinfo": fixture("cpuinfo_x86.txt")})
    cpu = read_cpu(env)
    assert cpu is not None and "Ryzen" in cpu.model


def test_parse_lspci() -> None:
    devices = parse_lspci(fixture("lspci_laptop.txt"))
    assert len(devices) == 5
    intel = next(d for d in devices if d.slot == "00:02.0")
    assert intel.is_gpu and intel.driver == "i915" and intel.ids == "8086:9a49"
    nvidia = next(d for d in devices if d.slot == "01:00.0")
    assert nvidia.is_gpu and nvidia.driver is None and "nvidia" in nvidia.modules
    assert not next(d for d in devices if d.slot == "00:14.3").is_gpu


def test_parse_lsusb_skips_root_hubs_in_report() -> None:
    devices = parse_lsusb(fixture("lsusb.txt"))
    assert len(devices) == 4 and sum(d.is_root_hub for d in devices) == 2
    assert parse_lsusb("garbage") == []


def test_parse_lsblk_handles_old_and_new_formats() -> None:
    devices = parse_lsblk(fixture("lsblk_laptop.json"))
    assert devices is not None
    by_name = {d.name: d for d in devices}
    assert by_name["nvme0n1"].kind == "NVMe SSD"
    assert by_name["sda"].kind == "HDD"  # old util-linux reports "1" strings
    assert by_name["sdb"].kind == "USB / removable"
    assert by_name["nvme0n1p2"].parent == "nvme0n1" and by_name["nvme0n1p2"].mountpoint == "/"
    assert {d.name for d in real_devices(devices)}.isdisjoint({"loop0", "zram0"})
    assert parse_lsblk("not json") is None and parse_lsblk('{"x": 1}') is None


def test_read_temperatures_from_hwmon_and_thermal() -> None:
    env = FakeEnvironment(
        {
            "/sys/class/hwmon/hwmon2/name": "coretemp\n",
            "/sys/class/hwmon/hwmon2/temp1_input": "54000\n",
            "/sys/class/hwmon/hwmon2/temp1_label": "Package id 0\n",
            "/sys/class/hwmon/hwmon2/temp1_max": "100000\n",
            "/sys/class/hwmon/hwmon2/temp1_crit": "105000\n",
            "/sys/class/hwmon/hwmon2/temp2_input": "0\n",  # bogus, ignored
            "/sys/class/thermal/thermal_zone0/type": "acpitz\n",
            "/sys/class/thermal/thermal_zone0/temp": "47000\n",
        }
    )
    temps = read_temperatures(env)
    assert [(t.sensor, t.label, t.celsius) for t in temps] == [
        ("coretemp", "Package id 0", 54.0),
        ("thermal", "acpitz", 47.0),
    ]
    assert temps[0].high == 100.0 and temps[0].critical == 105.0


def test_full_report_for_a_laptop() -> None:
    report = analyze(laptop_env(), kernel_log=CLEAN_LOG)
    assert report.fact("cpu").startswith("11th Gen Intel")
    assert report.fact("memory") == "15.6 GiB"
    assert "Iris Xe" in report.fact("gpu") and "RTX 3050" in report.fact("gpu")
    titles = [s.title for s in report.sections]
    assert titles[:2] == ["Processor", "Memory"]
    assert {"Graphics", "PCI devices", "USB devices", "Disks"} <= set(titles)
    assert check(report, "hardware.cpu").summary.endswith("(4 cores / 8 threads)")
    assert check(report, "hardware.disks").summary == "3 disk(s), 1.4 TiB in total"
    assert check(report, "hardware.usb").summary.startswith("2 device(s)")
    json.dumps(report.to_dict())  # serializable


def test_nvidia_without_driver_is_a_warning_with_evidence() -> None:
    gpu = check(analyze(laptop_env(), kernel_log=CLEAN_LOG), "hardware.gpu")
    assert gpu.status is Status.WARN
    assert any("GeForce RTX 3050" in e and "no kernel driver in use" in e for e in gpu.evidence)


def test_generic_framebuffer_driver_is_a_warning() -> None:
    env = laptop_env()
    env.commands[("lspci", "-nnk")] = result(fixture("lspci_fallback.txt"))
    gpu = check(analyze(env, kernel_log=CLEAN_LOG), "hardware.gpu")
    assert gpu.status is Status.WARN and "vesafb" in gpu.evidence[0]


def test_virtual_gpus_with_their_drivers_are_fine() -> None:
    env = laptop_env()
    env.commands[("lspci", "-nnk")] = result(fixture("lspci_vm.txt"))
    assert check(analyze(env, kernel_log=CLEAN_LOG), "hardware.gpu").status is Status.OK


def test_missing_tools_are_skipped_not_errors() -> None:
    report = analyze(FakeEnvironment({"/proc/meminfo": MEMINFO}), kernel_log=CLEAN_LOG)
    for check_id in ("hardware.gpu", "hardware.pci", "hardware.usb", "hardware.disks"):
        found = check(report, check_id)
        assert found.status is Status.SKIP
    assert "pciutils" in check(report, "hardware.pci").summary
    assert "usbutils" in check(report, "hardware.usb").summary
    assert not any(c.status in (Status.WARN, Status.ERROR) for c in report.checks)


def test_failing_or_timing_out_tools_are_skipped() -> None:
    env = FakeEnvironment(
        commands={
            ("lspci", "-nnk"): result("", 1),
            ("lsusb",): CommandTimeoutError(("lsusb",), 10),
            LSBLK: result("<<not json>>"),
        }
    )
    report = analyze(env, kernel_log=CLEAN_LOG)
    assert check(report, "hardware.pci").status is Status.SKIP
    assert check(report, "hardware.usb").status is Status.SKIP
    assert check(report, "hardware.disks").status is Status.SKIP


def test_temperature_rules() -> None:
    def with_temp(value: str, **limits: str):
        files = {
            "/sys/class/hwmon/hwmon0/name": "coretemp",
            "/sys/class/hwmon/hwmon0/temp1_input": value,
            "/sys/class/hwmon/hwmon0/temp1_label": "Package",
        }
        files.update({f"/sys/class/hwmon/hwmon0/temp1_{k}": v for k, v in limits.items()})
        return check(analyze(FakeEnvironment(files), kernel_log=CLEAN_LOG), "hardware.temperature")

    assert with_temp("45000").status is Status.OK
    assert with_temp("92000").status is Status.WARN
    assert with_temp("101000").status is Status.ERROR
    assert (
        with_temp("95000", max="100000", crit="105000").status is Status.OK
    )  # below its own limit
    assert with_temp("101000", max="100000", crit="105000").status is Status.WARN
    assert with_temp("106000", max="100000", crit="105000").status is Status.ERROR
    assert (
        check(analyze(FakeEnvironment(), kernel_log=CLEAN_LOG), "hardware.temperature").status
        is Status.SKIP
    )


def test_kernel_log_hardware_errors() -> None:
    env = FakeEnvironment()
    bad = KernelLog(("mce: [Hardware Error]: Machine check events logged", "unrelated"))
    found = check(analyze(env, kernel_log=bad), "hardware.errors")
    assert found.status is Status.WARN and len(found.evidence) == 1
    assert check(analyze(env, kernel_log=CLEAN_LOG), "hardware.errors").status is Status.OK
    denied = KernelLog(unavailable_reason="not readable (sudo dmesg)")
    assert check(analyze(env, kernel_log=denied), "hardware.errors").status is Status.SKIP
