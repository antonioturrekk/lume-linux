import argparse
from collections.abc import Callable, Iterator

import pytest

from lume import __version__
from lume.cli.commands import Command
from lume.cli.context import AppContext
from lume.cli.menu import resolve_choice, run_menu
from lume.cli.parser import build_parser
from lume.cli.registry import COMMANDS
from lume.cli.theme import make_console


def _ctx() -> AppContext:
    console, err = make_console(), make_console(stderr=True)
    parser, subs = build_parser(console, COMMANDS)
    return AppContext(console, err, parser, subs, COMMANDS)


def _script(*answers: str) -> Callable[[str], str]:
    iterator: Iterator[str] = iter(answers)

    def read(prompt: str) -> str:
        try:
            return next(iterator)
        except StopIteration:
            raise EOFError from None

    return read


def test_resolve_choice_by_number_and_name() -> None:
    assert resolve_choice("1", COMMANDS) is COMMANDS[0]
    assert resolve_choice(" Version ", COMMANDS) is COMMANDS[7]
    assert resolve_choice("99", COMMANDS) is None
    assert resolve_choice("0", COMMANDS) is None
    assert resolve_choice("xyz", COMMANDS) is None


def test_menu_runs_a_command_then_quits(capsys: pytest.CaptureFixture[str]) -> None:
    assert run_menu(_ctx(), _script("version", "", "q")) == 0
    assert __version__ in capsys.readouterr().out


def test_menu_selects_by_number(capsys: pytest.CaptureFixture[str]) -> None:
    number = str([c.name for c in COMMANDS].index("version") + 1)
    run_menu(_ctx(), _script(number, "", "q"))
    assert __version__ in capsys.readouterr().out


def test_menu_unavailable_command_reports_clearly(
    capsys: pytest.CaptureFixture[str],
) -> None:
    commands = (Command("future", "not built yet", planned_phase=12),)
    console, err = make_console(), make_console(stderr=True)
    parser, subs = build_parser(console, commands)
    ctx = AppContext(console, err, parser, subs, commands)
    run_menu(ctx, _script("future", "", "q"))
    assert "not implemented yet" in capsys.readouterr().err


def test_menu_rejects_invalid_option_and_keeps_going(
    capsys: pytest.CaptureFixture[str],
) -> None:
    assert run_menu(_ctx(), _script("banana", "q")) == 0
    assert "Invalid option" in capsys.readouterr().out


@pytest.mark.parametrize("word", ["q", "quit", "exit", "0", "Q"])
def test_menu_quit_words(word: str) -> None:
    assert run_menu(_ctx(), _script(word)) == 0


def test_menu_exits_cleanly_on_end_of_input() -> None:
    assert run_menu(_ctx(), _script()) == 0


def test_menu_exits_cleanly_on_ctrl_c() -> None:
    def read(prompt: str) -> str:
        raise KeyboardInterrupt

    assert run_menu(_ctx(), read) == 0


def test_menu_help_entry_works(capsys: pytest.CaptureFixture[str]) -> None:
    run_menu(_ctx(), _script("help", "", "q"))
    assert "Usage: lume" in capsys.readouterr().out


def test_menu_with_custom_commands(capsys: pytest.CaptureFixture[str]) -> None:
    def hello(args: argparse.Namespace, ctx: AppContext) -> int:
        ctx.console.print("hello from custom command")
        return 0

    commands = (Command("hello", "says hello", handler=hello),)
    console, err = make_console(), make_console(stderr=True)
    parser, subs = build_parser(console, commands)
    ctx = AppContext(console, err, parser, subs, commands)
    run_menu(ctx, _script("1", "", "q"))
    assert "hello from custom command" in capsys.readouterr().out


def test_menu_exits_cleanly_if_input_ends_at_the_pause_prompt() -> None:
    assert run_menu(_ctx(), _script("version")) == 0
