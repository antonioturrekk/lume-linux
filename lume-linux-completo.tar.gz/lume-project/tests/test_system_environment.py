"""The real machine access layer, exercised against the machine running the tests."""

import socket
import subprocess
import threading

import pytest

from lume.core import paths
from lume.core.environment import DiskUsage, SystemEnvironment
from lume.core.exceptions import CommandTimeoutError, SafetyError, ToolUnavailableError
from lume.core.runner import run_command

ENV = SystemEnvironment()


def test_read_text_and_missing_files() -> None:
    assert "MemTotal" in (ENV.read_text("/proc/meminfo") or "")
    assert ENV.read_text("/definitely/not/here") is None
    assert ENV.read_text("/proc/self/mem") is None or isinstance(
        ENV.read_text("/proc/self/mem"), str
    )


def test_listdir_and_exists() -> None:
    assert "meminfo" in ENV.listdir("/proc")
    assert ENV.listdir("/definitely/not/here") == []
    assert ENV.exists("/proc") and not ENV.exists("/definitely/not/here")


def test_disk_usage_matches_df_math() -> None:
    usage = ENV.disk_usage("/")
    assert usage is not None and usage.total > 0
    assert 0 <= usage.percent_used <= 100
    assert ENV.disk_usage("/definitely/not/here") is None


def test_disk_usage_edge_cases() -> None:
    empty = DiskUsage(0, 0, 0, 0, 0)
    assert empty.percent_used == 0.0 and empty.inodes_percent_used == 0.0


def test_basic_facts() -> None:
    assert ENV.geteuid() >= 0 and ENV.machine() and ENV.page_size() >= 4096
    assert ENV.now().tzinfo is not None


def test_tcp_connect_against_a_local_server() -> None:
    server = socket.socket()
    server.bind(("127.0.0.1", 0))
    server.listen(1)
    port = server.getsockname()[1]
    accepted: list[socket.socket] = []

    def accept_one() -> None:
        try:
            connection, _ = server.accept()
            accepted.append(connection)
        except OSError:
            pass  # the server was closed before anyone connected

    thread = threading.Thread(target=accept_one, daemon=True)
    thread.start()
    try:
        assert ENV.tcp_connect("127.0.0.1", port, 2.0) >= 0
    finally:
        thread.join(2)
        for connection in accepted:
            connection.close()
        server.close()
    with pytest.raises(OSError):
        ENV.tcp_connect("127.0.0.1", port, 0.5)  # now closed


def test_resolve_host() -> None:
    assert "127.0.0.1" in ENV.resolve_host("localhost", 3.0) or ENV.resolve_host("localhost", 3.0)
    with pytest.raises(OSError):
        ENV.resolve_host("this-name-does-not-exist.invalid", 3.0)


def test_resolve_host_times_out(monkeypatch: pytest.MonkeyPatch) -> None:
    release = threading.Event()

    def slow(*args, **kwargs):
        release.wait(5)
        return []

    monkeypatch.setattr("lume.core.environment.socket.getaddrinfo", slow)
    with pytest.raises(TimeoutError):
        ENV.resolve_host("slow.example", 0.2)
    release.set()


def test_resolve_host_turns_unexpected_failures_into_network_errors(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def broken(*args, **kwargs):
        raise RuntimeError("resolver bug")

    monkeypatch.setattr("lume.core.environment.socket.getaddrinfo", broken)
    with pytest.raises(OSError, match="resolver bug"):
        ENV.resolve_host("example.com", 1.0)


def test_interface_ipv4_of_loopback() -> None:
    assert ENV.interface_ipv4("lo") == ("127.0.0.1", 8)
    assert ENV.interface_ipv4("no-such-if") is None


# ---------- runner failure modes ----------
def test_timeout_is_reported(monkeypatch: pytest.MonkeyPatch) -> None:
    def slow(*args, **kwargs):
        raise subprocess.TimeoutExpired("lscpu", 1)

    monkeypatch.setattr("lume.core.runner.subprocess.run", slow)
    with pytest.raises(CommandTimeoutError, match="timed out"):
        run_command(["lscpu"], timeout=1)
    assert '"result": "timeout"' in paths.audit_log_file().read_text(encoding="utf-8")


def test_unexecutable_program_is_reported_as_unavailable(monkeypatch: pytest.MonkeyPatch) -> None:
    def broken(*args, **kwargs):
        raise PermissionError("not executable")

    monkeypatch.setattr("lume.core.runner.subprocess.run", broken)
    with pytest.raises(ToolUnavailableError):
        run_command(["lscpu"])


def test_environment_is_sanitized_and_no_shell_is_used(monkeypatch: pytest.MonkeyPatch) -> None:
    captured = {}

    def fake_run(command, **kwargs):
        captured.update(kwargs, command=command)
        return subprocess.CompletedProcess(command, 0, b"ok\xff", b"")

    monkeypatch.setenv("LD_PRELOAD", "/tmp/evil.so")
    monkeypatch.setattr("lume.core.runner.subprocess.run", fake_run)
    result = run_command(["lscpu"])
    assert result.stdout == "ok\ufffd"  # invalid bytes never raise
    assert captured["command"] == ("lscpu",) and "shell" not in captured
    assert captured["env"]["LC_ALL"] == "C" and "LD_PRELOAD" not in captured["env"]
    assert captured["stdin"] == subprocess.DEVNULL


def test_oversized_output_is_truncated(monkeypatch: pytest.MonkeyPatch) -> None:
    from lume.core import runner

    monkeypatch.setattr(
        "lume.core.runner.subprocess.run",
        lambda command, **kw: subprocess.CompletedProcess(command, 0, b"x" * 3_000_000, b""),
    )
    assert len(run_command(["lscpu"]).stdout) == runner.MAX_OUTPUT_BYTES


def test_blocked_command_is_not_even_audited_as_executed() -> None:
    with pytest.raises(SafetyError):
        run_command(["rm", "-rf", "/"])
    log = paths.audit_log_file()
    assert not log.exists() or '"rm"' not in log.read_text(encoding="utf-8")


def test_audit_log_rotates(monkeypatch: pytest.MonkeyPatch) -> None:
    from lume.core import audit

    monkeypatch.setattr(audit, "MAX_BYTES", 200)
    for index in range(30):
        audit.record("command", argv=["lscpu"], n=index)
    assert paths.audit_log_file().with_suffix(".log.1").exists()


def test_audit_failure_never_raises(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:
    from lume.core import audit

    blocker = tmp_path / "file"
    blocker.write_text("x")
    monkeypatch.setenv("XDG_STATE_HOME", str(blocker))  # a file where a directory is needed
    audit.record("command", argv=["lscpu"])  # must not raise
