"""The analysis commands, run through ``main`` against a fake machine."""

import json
import os
from pathlib import Path

import pytest

from lume.cli.exit_codes import ExitCode
from lume.cli.main import main
from lume.core import paths
from lume.core.environment import DiskUsage
from lume.core.kernel_log import STORAGE_RE  # noqa: F401  (documented dependency)
from tests.test_system_engine import full_env

GIB = 1024**3


def run(argv, capsys, env=None, **kwargs):
    code = main(argv, env=env or full_env(), **kwargs)
    captured = capsys.readouterr()
    return code, captured.out, captured.err


def full_disk_env():
    env = full_env()
    env.disks["/"] = DiskUsage(100 * GIB, 98 * GIB, 2 * GIB, 1000, 900)
    return env


# ---------- diagnose ----------
def test_diagnose_overview_and_groups(capsys) -> None:
    code, out, _ = run(["diagnose"], capsys)
    assert code == ExitCode.OK
    assert "System Analysis" in out and "Ubuntu 26.04 LTS" in out and "SYSTEM STATUS" in out
    for group in ("System", "Hardware", "Network", "Performance", "Storage"):
        assert f"\n{group}\n" in out
    assert "[OK]" in out and "No problems detected." in out
    assert "Linux 6.18.0-generic" in out and "11th Gen Intel" in out


def test_diagnose_reports_errors_with_evidence_and_suggests_solutions(capsys) -> None:
    code, out, _ = run(["diagnose"], capsys, env=full_disk_env())
    assert code == ExitCode.PROBLEMS
    assert "[ERROR]" in out and "1 error" in out
    assert "↳ /: 98% used" in out
    assert "Suggested solutions" in out and "SOL-0001" in out and "lume solutions <ID>" in out


def test_diagnose_warning_alone_exits_zero(capsys) -> None:
    env = full_env()
    env.disks["/"] = DiskUsage(100 * GIB, 92 * GIB, 8 * GIB, 1000, 900)
    code, out, _ = run(["diagnose"], capsys, env=env)
    assert code == ExitCode.OK and "[WARN]" in out and "1 warning detected." in out


def test_offline_flag_skips_active_probes(capsys) -> None:
    _, online, _ = run(["diagnose"], capsys)
    _, offline, _ = run(["diagnose", "--offline"], capsys)
    assert "reachable (TCP to 1.1.1.1:443" in online
    assert "skipped (--offline" in offline and "reachable (TCP" not in offline


def test_history_between_runs(capsys) -> None:
    code, out, _ = run(["diagnose"], capsys)
    assert "previous diagnosis" not in out  # first run: nothing to compare
    _, out, _ = run(["diagnose"], capsys)
    assert "No changes since the previous diagnosis" in out
    _, out, _ = run(["diagnose"], capsys, env=full_disk_env())
    assert "Since the previous diagnosis" in out and "new: Disk space" in out
    assert paths.database_file().exists()


def test_no_history_flag_stores_nothing(capsys) -> None:
    run(["diagnose", "--no-history"], capsys)
    assert not paths.database_file().exists()


def test_invalid_interval_is_a_usage_error(capsys) -> None:
    code, _, err = run(["diagnose", "--interval", "0"], capsys)
    assert code == ExitCode.USAGE and "between 0.2 and 10" in err
    code, _, err = run(["performance", "--interval", "abc"], capsys)
    assert code == ExitCode.USAGE and "not a number" in err


def test_interval_is_passed_to_the_sampler(capsys) -> None:
    env = full_env()
    run(["diagnose", "--interval", "2.5"], capsys, env=env)
    assert env.slept == [2.5]


# ---------- single-domain commands ----------
@pytest.mark.parametrize(
    ("command", "heading", "expected"),
    [
        ("hardware", "HARDWARE", "Processor"),
        ("network", "NETWORK", "Routing and DNS"),
        ("performance", "PERFORMANCE", "CPU and load"),
        ("storage", "STORAGE", "Filesystems"),
    ],
)
def test_domain_commands_render_details_and_checks(command, heading, expected, capsys) -> None:
    code, out, _ = run([command], capsys)
    assert code == ExitCode.OK
    assert heading in out and expected in out and "CHECKS" in out and "[OK]" in out


def test_network_offline_option(capsys) -> None:
    _, out, _ = run(["network", "--offline"], capsys)
    assert "[SKIP]" in out and "skipped (--offline" in out


def test_storage_error_gives_exit_code_4(capsys) -> None:
    code, out, _ = run(["storage"], capsys, env=full_disk_env())
    assert code == ExitCode.PROBLEMS and "almost full" in out


def test_commands_never_crash_without_tools_or_proc(capsys) -> None:
    from tests.helpers import FakeEnvironment

    for command in ("diagnose", "hardware", "network", "performance", "storage", "report"):
        argv = [command, "--stdout"] if command == "report" else [command]
        code, out, err = run(argv, capsys, env=FakeEnvironment())
        assert code in (ExitCode.OK, ExitCode.PROBLEMS), (command, code, err)
        assert "Traceback" not in out + err


# ---------- solutions ----------
def test_solutions_list_is_filtered_for_the_distribution(capsys) -> None:
    code, out, _ = run(["solutions"], capsys)
    assert code == ExitCode.OK and "solutions for Ubuntu 26.04 LTS (19)" in out
    assert "SOL-0001" in out and "SOL-0003" in out


def test_solution_details(capsys) -> None:
    code, out, _ = run(["solutions", "sol-0001"], capsys)
    assert code == ExitCode.OK
    for part in ("Symptoms", "Possible causes", "Diagnostic commands", "Recommended solution"):
        assert part in out
    assert "$ sudo apt clean" in out and "LUME does not run these commands" in out


def test_solution_search(capsys) -> None:
    _, out, _ = run(["solutions", "--search", "dns"], capsys)
    assert "SOL-0003" in out and "SOL-0001" not in out
    _, out, _ = run(["solutions", "-s", "zzzz"], capsys)
    assert "No solutions found." in out


def test_unknown_solution_is_a_usage_error(capsys) -> None:
    code, _, err = run(["solutions", "SOL-9999"], capsys)
    assert code == ExitCode.USAGE and "No solution called SOL-9999" in err


def test_incompatible_solutions_are_not_presented_unless_forced(capsys) -> None:
    fedora = full_env()
    fedora.files["/etc/os-release"] = 'ID=fedora\nPRETTY_NAME="Fedora Linux 41"\n'
    code, out, err = run(["solutions", "SOL-0001"], capsys, env=fedora)
    assert code == ExitCode.USAGE and out == "" and "not verified for Fedora Linux 41" in err
    code, out, _ = run(["solutions", "SOL-0001", "--all"], capsys, env=fedora)
    assert code == ExitCode.OK and "Not verified for this distribution" in out
    _, out, _ = run(["solutions"], capsys, env=fedora)
    assert "SOL-0001" not in out and "SOL-0006" in out  # the universal one remains
    _, out, _ = run(["solutions", "--all"], capsys, env=fedora)
    assert "SOL-0001" in out


# ---------- report ----------
def test_report_writes_a_private_file_in_the_current_directory(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys
) -> None:
    monkeypatch.chdir(tmp_path)
    code, out, _ = run(["report", "--offline"], capsys)
    target = tmp_path / "lume-report-20261115-120000.html"
    assert code == ExitCode.OK and target.exists() and "Report saved to" in out
    assert "Use --anonymize" in out
    assert oct(os.stat(target).st_mode & 0o777) == "0o600"
    assert target.read_text(encoding="utf-8").startswith("<!DOCTYPE html>")


@pytest.mark.parametrize(("fmt", "ext"), [("html", "html"), ("markdown", "md"), ("json", "json")])
def test_report_formats(fmt, ext, tmp_path: Path, capsys) -> None:
    target = tmp_path / f"out.{ext}"
    code, _, _ = run(["report", "-f", fmt, "-o", str(target), "--offline"], capsys)
    assert code == ExitCode.OK and target.stat().st_size > 500


def test_report_refuses_to_overwrite_unless_forced(tmp_path: Path, capsys) -> None:
    target = tmp_path / "r.md"
    target.write_text("precious")
    code, _, err = run(["report", "-f", "markdown", "-o", str(target)], capsys)
    assert code == ExitCode.ERROR and "already exists" in err
    assert target.read_text() == "precious"
    code, _, _ = run(["report", "-f", "markdown", "-o", str(target), "--force"], capsys)
    assert code == ExitCode.OK and target.read_text().startswith("# LUME diagnostic report")


def test_report_to_stdout_is_pure_json(capsys) -> None:
    code, out, _ = run(["report", "-f", "json", "--stdout", "--offline"], capsys)
    assert code == ExitCode.OK
    data = json.loads(out)  # nothing else may be mixed into stdout
    assert data["summary"]["ERROR"] == 0 and data["offline"] is True


def test_report_anonymize(capsys) -> None:
    for fmt in ("json", "markdown", "html"):
        code, out, _ = run(["report", "-f", fmt, "--stdout", "--anonymize"], capsys)
        assert code == ExitCode.OK
        for secret in ("192.168.1.20", "dc:41:a9:12:34:56", "mybox"):
            assert secret not in out, (fmt, secret)
    _, out, _ = run(["report", "-f", "json", "--stdout"], capsys)
    assert "192.168.1.20" in out  # without the flag the data is kept


def test_report_with_problems_includes_recommendations(capsys) -> None:
    _, out, _ = run(["report", "-f", "markdown", "--stdout"], capsys, env=full_disk_env())
    assert "SOL-0001" in out and "[ERROR] Disk space" in out


def test_report_to_unwritable_place(tmp_path: Path, capsys) -> None:
    code, _, err = run(["report", "-o", str(tmp_path / "nope" / "r.html")], capsys)
    assert code == ExitCode.ERROR and "cannot write" in err


# ---------- menu ----------
def test_menu_runs_the_real_commands_with_default_options(capsys) -> None:
    answers = iter(["hardware", "", "solutions", "", "q"])
    code = main([], env=full_env(), interactive=True, input_fn=lambda prompt: next(answers))
    out = capsys.readouterr().out
    assert code == 0 and "HARDWARE" in out and "Known problems" in out


# ---------- safety: nothing outside the allowlist is ever executed ----------
def test_only_allowlisted_read_only_commands_are_requested(capsys) -> None:
    from lume.core.runner import validate_command

    env = full_env()
    run(["diagnose"], capsys, env=env)
    run(["report", "--stdout"], capsys, env=full_env())
    assert env.executed, "the diagnosis should have used system tools"
    for argv in env.executed:
        validate_command(argv)  # raises SafetyError if anything else was requested
