import json
from pathlib import Path

from lume.core import Status
from lume.core.environment import DiskUsage
from lume.core.exceptions import ToolUnavailableError
from lume.database import HistoryStore, compare
from lume.diagnostics import run_diagnosis
from lume.diagnostics import system as system_checks
from tests.helpers import FakeEnvironment, fixture, result
from tests.test_hardware import LSBLK
from tests.test_network import IP_ADDR, IP_ROUTE, IP_ROUTE6, PING

UBUNTU = (
    'NAME="Ubuntu"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME="Ubuntu 26.04 LTS"\nVERSION_ID="26.04"\n'
)
SHOW = ("systemctl", "show", "--no-pager", "--property=LoadState,ActiveState,SubState")
RUNNING = "LoadState=loaded\nActiveState=active\nSubState=running\n"


def check(report, check_id):
    return next(c for c in report.checks if c.check_id == check_id)


def sys_env(files=None, commands=None, **kw):
    base = {
        "/etc/os-release": UBUNTU,
        "/proc/sys/kernel/osrelease": "6.18.0-generic\n",
        "/proc/sys/kernel/tainted": "0\n",
        "/proc/uptime": "93784.2 1.0\n",
        "/proc/sys/kernel/hostname": "mybox\n",
    }
    base.update(files or {})
    cmds = {("dpkg", "--audit"): result("")}
    cmds.update(commands or {})
    return FakeEnvironment(base, cmds, euid=1000, **kw)


def systemd_env(state="running", failed="", units=None):
    commands = {
        ("systemctl", "is-system-running"): result(state + "\n", 0 if state == "running" else 1),
        ("systemctl", "--failed", "--no-legend", "--plain", "--no-pager"): result(failed),
    }
    for unit in (
        "dbus.service",
        "systemd-journald.service",
        "systemd-logind.service",
        "systemd-udevd.service",
        "NetworkManager.service",
    ):
        commands[(*SHOW, unit)] = result((units or {}).get(unit, RUNNING))
    commands[(*SHOW, "systemd-networkd.service")] = result(
        "LoadState=not-found\nActiveState=inactive\n"
    )
    return sys_env({"/run/systemd/system/x": ""}, commands)


def test_system_overview_for_ubuntu_2604() -> None:
    report = system_checks.analyze(sys_env())
    items = dict(report.sections[0].items)
    assert items["Distribution"] == "Ubuntu 26.04 LTS" and items["Kernel"] == "Linux 6.18.0-generic"
    assert items["Uptime"] == "1 d 2 h" and items["Family"] == "debian"
    assert check(report, "system.platform").summary == "Ubuntu 26.04 LTS is officially supported"
    assert check(report, "system.privileges").status is Status.OK
    assert check(report, "system.packages").status is Status.OK
    assert check(report, "system.reboot").status is Status.OK


def test_platform_support_levels() -> None:
    older = system_checks.analyze(sys_env({"/etc/os-release": UBUNTU.replace("26.04", "24.04")}))
    assert check(older, "system.platform").status is Status.OK
    assert "only Ubuntu 26.04+" in check(older, "system.platform").summary
    mint = system_checks.analyze(
        sys_env(
            {
                "/etc/os-release": 'ID=linuxmint\nID_LIKE="ubuntu debian"\nPRETTY_NAME="Linux Mint 22"\n'
            }
        )
    )
    assert check(mint, "system.platform").status is Status.OK
    arch = system_checks.analyze(
        sys_env({"/etc/os-release": 'ID=arch\nPRETTY_NAME="Arch Linux"\n'})
    )
    assert check(arch, "system.platform").status is Status.WARN
    unknown = system_checks.analyze(FakeEnvironment())
    assert check(unknown, "system.platform").status is Status.SKIP
    assert check(unknown, "system.identification").status is Status.SKIP


def test_debian_specific_commands_never_run_on_other_families() -> None:
    env = sys_env({"/etc/os-release": 'ID=fedora\nPRETTY_NAME="Fedora Linux 41"\n'})
    report = system_checks.analyze(env)
    assert ("dpkg", "--audit") not in env.executed
    assert check(report, "system.packages").status is Status.SKIP
    assert check(report, "system.reboot").status is Status.SKIP
    assert "fedora" in check(report, "system.packages").summary


def test_broken_packages_are_an_error() -> None:
    audit = "The following packages are only half configured:\n libfoo\n"
    report = system_checks.analyze(sys_env(commands={("dpkg", "--audit"): result(audit)}))
    found = check(report, "system.packages")
    assert found.status is Status.ERROR and "libfoo" in found.evidence[1]
    missing = system_checks.analyze(
        sys_env(commands={("dpkg", "--audit"): ToolUnavailableError("dpkg")})
    )
    assert check(missing, "system.packages").status is Status.SKIP


def test_root_is_flagged_and_reboot_pending() -> None:
    env = sys_env(
        {
            "/var/run/reboot-required": "",
            "/var/run/reboot-required.pkgs": "linux-image-6.18\nlibc6\n",
        }
    )
    env.euid = 0
    report = system_checks.analyze(env)
    assert check(report, "system.privileges").status is Status.WARN
    reboot = check(report, "system.reboot")
    assert reboot.status is Status.WARN and "libc6" in reboot.evidence[1]


def test_kernel_taint_flags() -> None:
    benign = system_checks.analyze(
        sys_env({"/proc/sys/kernel/tainted": "4097\n"})
    )  # P + out-of-tree
    assert check(benign, "system.kernel_taint").status is Status.OK
    assert "proprietary module loaded" in check(benign, "system.kernel_taint").summary
    serious = system_checks.analyze(sys_env({"/proc/sys/kernel/tainted": str(1 << 7)}))
    assert check(serious, "system.kernel_taint").status is Status.WARN
    assert (
        check(system_checks.analyze(FakeEnvironment()), "system.kernel_taint").status is Status.SKIP
    )


def test_systemd_states() -> None:
    assert check(system_checks.analyze(systemd_env()), "system.services").status is Status.OK
    degraded = system_checks.analyze(
        systemd_env("degraded", "snapd.service loaded failed failed Snap Daemon\n")
    )
    found = check(degraded, "system.services")
    assert found.status is Status.WARN and "snapd.service" in found.evidence[0]
    assert (
        check(system_checks.analyze(systemd_env("maintenance")), "system.services").status
        is Status.ERROR
    )
    assert (
        check(system_checks.analyze(systemd_env("starting")), "system.services").status is Status.OK
    )
    assert (
        check(system_checks.analyze(sys_env()), "system.services").status is Status.SKIP
    )  # container


def test_essential_services() -> None:
    assert check(system_checks.analyze(systemd_env()), "system.essential").status is Status.OK
    down = systemd_env(
        units={"dbus.service": "LoadState=loaded\nActiveState=failed\nSubState=failed\n"}
    )
    found = check(system_checks.analyze(down), "system.essential")
    assert found.status is Status.ERROR and "dbus.service: failed" in found.evidence[0]
    no_nm = systemd_env(
        units={"NetworkManager.service": "LoadState=loaded\nActiveState=inactive\nSubState=dead\n"}
    )
    assert check(system_checks.analyze(no_nm), "system.essential").status is Status.WARN
    not_installed = systemd_env(
        units={"NetworkManager.service": "LoadState=not-found\nActiveState=inactive\n"}
    )
    assert check(system_checks.analyze(not_installed), "system.essential").status is Status.OK


# ---------- engine ----------
def full_env() -> FakeEnvironment:
    env = systemd_env()
    env.files.update(
        {
            "/proc/meminfo": "MemTotal: 8000000 kB\nMemAvailable: 5000000 kB\nSwapTotal: 0 kB\n",
            "/proc/stat": "cpu  100 0 50 800 50 0 0 0\ncpu0 100 0 50 800 50 0 0 0\n",
            "/proc/loadavg": "0.1 0.1 0.1 1/10 5\n",
            "/proc/self/mounts": "/dev/nvme0n1p2 / ext4 rw 0 0\n",
            "/etc/resolv.conf": "nameserver 192.168.1.1\n",
            "/sys/class/net/wlp2s0/wireless/x": "",
        }
    )
    env.commands.update(
        {
            ("lscpu",): result(fixture("lscpu_i5.txt")),
            LSBLK: result(fixture("lsblk_laptop.json")),
            IP_ADDR: result(fixture("ip_addr_wifi.json")),
            IP_ROUTE: result(fixture("ip_route.json")),
            IP_ROUTE6: result("[]"),
            PING: result("time=1.0 ms"),
            ("dmesg", "--level=err,crit,alert,emerg"): result(""),
        }
    )
    env.disks["/"] = DiskUsage(100 * 1024**3, 40 * 1024**3, 60 * 1024**3, 1000, 900)
    env.resolve["example.com"] = ["93.184.216.34"]
    env.tcp[("1.1.1.1", 443)] = 12.0
    env.sleep_updates = [{"/proc/stat": "cpu  110 0 55 880 55 0 0 0\ncpu0 110 0 55 880 55 0 0 0\n"}]
    return env


def test_full_diagnosis_aggregates_every_domain() -> None:
    diagnosis = run_diagnosis(full_env())
    assert [r.id for r in diagnosis.reports] == [
        "system",
        "hardware",
        "network",
        "performance",
        "storage",
    ]
    assert diagnosis.generated_at == "2026-11-15T12:00:00+00:00"
    assert diagnosis.fact("os") == "Ubuntu 26.04 LTS" and diagnosis.fact("root_usage").startswith(
        "40% used"
    )
    assert "performance.disk" not in {c.check_id for c in diagnosis.checks}
    assert diagnosis.counts[Status.ERROR] == 0
    ids = [c.check_id for c in diagnosis.checks if c.check_id]
    assert len(ids) == len(set(ids))  # no duplicates
    json.dumps(diagnosis.to_dict())


def test_offline_flag_is_propagated() -> None:
    diagnosis = run_diagnosis(full_env(), offline=True)
    net = diagnosis.report("network")
    assert net is not None and check(net, "network.internet").status is Status.SKIP
    assert diagnosis.to_dict()["offline"] is True


def test_a_crashing_domain_is_reported_and_does_not_hide_the_others(monkeypatch) -> None:
    def boom(*args, **kwargs):
        raise RuntimeError("bug in analyzer")

    monkeypatch.setattr("lume.diagnostics.engine.analyze_network", boom)
    diagnosis = run_diagnosis(full_env())
    net = diagnosis.report("network")
    assert net is not None and net.checks[0].status is Status.SKIP
    assert "internal error" in net.checks[0].summary
    assert diagnosis.report("storage") is not None and len(diagnosis.report("storage").checks) > 1


def test_progress_callback_is_called_for_each_domain() -> None:
    messages: list[str] = []
    run_diagnosis(full_env(), progress=messages.append)
    assert len(messages) == 6


# ---------- history ----------
def test_history_roundtrip_and_comparison(tmp_path: Path) -> None:
    store = HistoryStore(tmp_path / "data" / "lume.db")
    assert store.latest() is None

    first = run_diagnosis(full_env())
    assert store.record(first) == 1
    previous = store.latest()
    assert previous is not None and previous.statuses["storage.space"] == "OK"

    bad = full_env()
    bad.disks["/"] = DiskUsage(100 * 1024**3, 95 * 1024**3, 5 * 1024**3, 1000, 900)
    second = run_diagnosis(bad)
    delta = compare(previous, second)
    assert delta.changed and "Disk space" in delta.new_problems
    store.record(second)

    previous = store.latest()
    assert previous is not None and previous.statuses["storage.space"] == "WARN"
    delta = compare(previous, run_diagnosis(full_env()))
    assert delta.resolved == ("Disk space",) and not delta.new_problems


def test_history_detects_worsening_and_stores_no_evidence(tmp_path: Path) -> None:
    store = HistoryStore(tmp_path / "lume.db")
    warn_env = full_env()
    warn_env.disks["/"] = DiskUsage(100 * 1024**3, 92 * 1024**3, 8 * 1024**3, 1000, 900)
    store.record(run_diagnosis(warn_env))
    error_env = full_env()
    error_env.disks["/"] = DiskUsage(100 * 1024**3, 99 * 1024**3, 1 * 1024**3, 1000, 900)
    previous = store.latest()
    assert previous is not None
    assert compare(previous, run_diagnosis(error_env)).worsened == ("Disk space",)
    raw = (tmp_path / "lume.db").read_bytes()
    assert b"192.168.1.20" not in raw and b"mybox" not in raw  # no personal data persisted


def test_history_keeps_a_bounded_number_of_runs(tmp_path: Path) -> None:
    import sqlite3

    from lume.database import history

    store = HistoryStore(tmp_path / "lume.db")
    diagnosis = run_diagnosis(full_env())
    for _ in range(history.KEEP_RUNS + 5):
        store.record(diagnosis)
    with sqlite3.connect(tmp_path / "lume.db") as conn:
        assert conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0] == history.KEEP_RUNS
        assert conn.execute("SELECT COUNT(*) FROM findings").fetchone()[0] > 0


def test_history_failures_never_raise(tmp_path: Path) -> None:
    blocker = tmp_path / "file"
    blocker.write_text("x")
    store = HistoryStore(blocker / "lume.db")  # parent is a file: cannot be created
    assert store.latest() is None
    assert store.record(run_diagnosis(full_env())) is None
