import json
import os
import stat
from dataclasses import replace
from pathlib import Path

import pytest

from lume.core.environment import DiskUsage
from lume.core.report import KeyValues, Report
from lume.diagnostics import run_diagnosis
from lume.reports import (
    FORMATS,
    Anonymizer,
    ReportWriteError,
    build_recommendations,
    default_filename,
    generate,
    write_report,
)
from lume.solutions import load_builtin
from tests.test_system_engine import full_env

BASE = load_builtin()


def problem_diagnosis(**kw):
    env = full_env()
    env.disks["/"] = DiskUsage(100 * 1024**3, 93 * 1024**3, 7 * 1024**3, 1000, 900)
    return run_diagnosis(env, **kw)


# ---------- anonymizer ----------
@pytest.mark.parametrize(
    ("original", "expected"),
    [
        ("dc:41:a9:12:34:56", "dc:41:a9:xx:xx:xx"),
        ("192.168.1.20/24", "192.168.x.x/24"),
        ("10.1.2.3", "10.1.x.x"),
        ("172.17.0.1", "172.17.x.x"),
        ("169.254.8.9", "169.254.x.x"),
        ("93.184.216.34", "<public-ip>"),
        ("127.0.0.1", "127.0.0.1"),
        ("0.0.0.0", "0.0.0.0"),
        ("2804:1b3:a:1::20/64", "<ipv6>/64"),
        ("fe80::de41:a9ff:fe12:3456", "fe80::xxxx"),
        ("::1", "::1"),
        ("id 3f2b8c1e-1a2b-4c3d-8e9f-0123456789ab", "id <uuid>"),
        ("/home/maria/Documents", "/home/<user>/Documents"),
        ("/run/user/1000/gvfs", "/run/user/<uid>/gvfs"),
        ("host mybox is up", "host <hostname> is up"),
    ],
)
def test_anonymizer_masks_personal_data(original: str, expected: str) -> None:
    assert Anonymizer(hostname="mybox").text(original) == expected


@pytest.mark.parametrize(
    "harmless",
    [
        "Ubuntu 26.04 LTS",
        "6.18.0-generic",
        "00:02.0",
        "8086:9a49",
        "12:30:45",
        "4.2 GiB",
        "enp3s0: 54 °C",
    ],
)
def test_anonymizer_leaves_useful_text_alone(harmless: str) -> None:
    assert Anonymizer(hostname="mybox").text(harmless) == harmless


def test_common_hostnames_do_not_break_the_distribution_name() -> None:
    assert (
        Anonymizer(hostname="ubuntu").text("Ubuntu 26.04 LTS on ubuntu")
        == "Ubuntu 26.04 LTS on ubuntu"
    )
    assert Anonymizer(hostname="ab").text("ab cab") == "ab cab"  # too short to mask safely


def test_hostname_match_is_whole_word() -> None:
    assert Anonymizer(hostname="mybox").text("mybox-2 and mybox.lan and notmybox") == (
        "mybox-2 and <hostname>.lan and notmybox"
    )


def test_anonymized_diagnosis_has_no_personal_data_in_any_format() -> None:
    diagnosis = Anonymizer(hostname="mybox").diagnosis(problem_diagnosis())
    assert diagnosis.anonymized
    for report_format in FORMATS:
        output = generate(diagnosis, report_format, BASE)
        for secret in (
            "192.168.1.20",
            "dc:41:a9:12:34:56",
            "mybox",
            "2804:1b3",
            "aa:bb:cc:11:22:33",
        ):
            assert secret not in output, (report_format, secret)


def test_the_hostname_row_is_always_masked() -> None:
    diagnosis = Anonymizer(hostname="ubuntu").diagnosis(run_diagnosis(full_env()))
    system = diagnosis.report("system")
    assert system is not None
    assert dict(system.sections[0].items)["Hostname"] == "<hostname>"


def test_not_anonymized_report_keeps_details_and_says_so() -> None:
    output = generate(problem_diagnosis(), "markdown", BASE)
    assert "192.168.1.20" in output and "Personal data:** included" in output


# ---------- recommendations ----------
def test_recommendations_follow_the_problems() -> None:
    diagnosis = problem_diagnosis()
    recs = build_recommendations(diagnosis, BASE)
    assert [r.solution.id for r in recs] == ["SOL-0001"]
    assert recs[0].because_of == ("Disk space",)
    healthy = run_diagnosis(full_env())
    assert all(r.because_of for r in build_recommendations(healthy, BASE))


def test_no_recommendation_for_an_incompatible_distribution() -> None:
    from lume.core.distro import parse_os_release

    diagnosis = replace(problem_diagnosis(), distro=parse_os_release("ID=fedora"))
    assert build_recommendations(diagnosis, BASE) == ()


# ---------- formats ----------
def test_markdown_report_structure() -> None:
    text = generate(problem_diagnosis(), "markdown", BASE)
    assert text.startswith("# LUME diagnostic report")
    for heading in (
        "## Summary",
        "## Problems found",
        "## Recommendations",
        "## Hardware",
        "## Network",
    ):
        assert heading in text
    assert "**[WARN] Disk space**" in text and "SOL-0001" in text
    assert "```bash" in text and "sudo apt clean" in text
    assert "LUME does not run these commands" in text
    assert "2026-11-15T12:00:00+00:00" in text and "LUME version:** 0.1.0.dev0" in text
    assert "## Checks that could not run" in text


def test_markdown_escapes_table_pipes() -> None:
    diagnosis = run_diagnosis(full_env())
    report = Report("x", "Extra", (KeyValues("T", (("a|b", "c|d"),)),))
    text = generate(replace(diagnosis, reports=(*diagnosis.reports, report)), "markdown", BASE)
    assert "| a\\|b | c\\|d |" in text


def test_json_report_is_valid_and_complete() -> None:
    data = json.loads(generate(problem_diagnosis(), "json", BASE))
    assert data["schema_version"] == 1 and data["lume_version"] == "0.1.0.dev0"
    assert data["generated_at"] == "2026-11-15T12:00:00+00:00"
    assert data["summary"]["WARN"] == 1 and "verdict" in data
    assert [r["id"] for r in data["reports"]] == [
        "system",
        "hardware",
        "network",
        "performance",
        "storage",
    ]
    assert data["recommendations"][0]["id"] == "SOL-0001"
    assert data["system"]["family"] == "debian"
    checks = {c["id"]: c for r in data["reports"] for c in r["checks"]}
    assert checks["storage.space"]["status"] == "WARN" and checks["storage.space"]["evidence"]


def test_html_report_is_self_contained() -> None:
    text = generate(problem_diagnosis(), "html", BASE)
    assert text.startswith("<!DOCTYPE html>") and "<title>LUME diagnostic report</title>" in text
    assert "default-src 'none'" in text  # no external resource can load
    for forbidden in ("<script", "http://", "https://", "src=", "<link", "@import"):
        assert forbidden not in text, forbidden
    assert 'class="badge WARN"' in text and "SOL-0001" in text


def test_html_escapes_text_coming_from_the_system() -> None:
    evil = '<script>alert(1)</script> & "quotes"'
    diagnosis = run_diagnosis(full_env())
    report = Report("x", evil, (KeyValues(evil, ((evil, evil),)),))
    text = generate(replace(diagnosis, reports=(*diagnosis.reports, report)), "html", BASE)
    assert "<script>" not in text and "&lt;script&gt;alert(1)&lt;/script&gt;" in text


def test_unknown_format_is_rejected() -> None:
    with pytest.raises(ValueError):
        generate(run_diagnosis(full_env()), "pdf", BASE)


def test_healthy_system_report_says_so() -> None:
    text = generate(run_diagnosis(full_env()), "markdown", BASE)
    assert "No problems were found." in text


# ---------- writer ----------
def test_default_filename_uses_the_diagnosis_time() -> None:
    diagnosis = run_diagnosis(full_env())
    assert default_filename(diagnosis, "html") == "lume-report-20261115-120000.html"
    assert default_filename(diagnosis, "markdown").endswith(".md")
    assert (
        default_filename(replace(diagnosis, generated_at="oops"), "json")
        == "lume-report-report.json"
    )


def test_write_report_is_private_and_never_overwrites(tmp_path: Path) -> None:
    target = tmp_path / "r.md"
    assert write_report("hello ✦", target) == target
    assert target.read_text(encoding="utf-8") == "hello ✦"
    assert stat.S_IMODE(os.stat(target).st_mode) == 0o600
    with pytest.raises(ReportWriteError, match="already exists"):
        write_report("other", target)
    assert target.read_text(encoding="utf-8") == "hello ✦"  # untouched
    write_report("replaced", target, overwrite=True)
    assert target.read_text(encoding="utf-8") == "replaced"


def test_write_report_to_a_missing_directory(tmp_path: Path) -> None:
    with pytest.raises(ReportWriteError, match="cannot write"):
        write_report("x", tmp_path / "missing" / "r.md")
