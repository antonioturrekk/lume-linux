"""Static guarantees about the source code (the read-only promise)."""

import ast
import re
from pathlib import Path

LUME = Path(__file__).resolve().parent.parent / "lume"
SOURCES = sorted(LUME.rglob("*.py"))


def _calls(tree: ast.AST):
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            yield node


def test_only_the_runner_can_start_processes() -> None:
    offenders = []
    for path in SOURCES:
        text = path.read_text(encoding="utf-8")
        imports_process_api = re.search(
            r"^\s*(import|from)\s+(subprocess|pty)\b", text, re.MULTILINE
        )
        if imports_process_api and path.name != "runner.py":
            offenders.append(str(path.relative_to(LUME)))
        if re.search(r"\bos\.(system|popen|exec\w*|spawn\w*|fork)\b", text):
            offenders.append(str(path.relative_to(LUME)))
    assert offenders == []


def test_no_shell_eval_or_dynamic_code() -> None:
    forbidden = {"eval", "exec", "compile", "__import__"}
    for path in SOURCES:
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for call in _calls(tree):
            name = getattr(call.func, "id", None)
            assert name not in forbidden, f"{path.name}: {name}()"
            for keyword in call.keywords:
                assert not (
                    keyword.arg == "shell"
                    and isinstance(keyword.value, ast.Constant)
                    and keyword.value.value is True
                ), f"{path.name}: shell=True"


def test_no_unsafe_deserialization() -> None:
    for path in SOURCES:
        text = path.read_text(encoding="utf-8")
        assert not re.search(r"\b(pickle|marshal|yaml\.load)\b", text), path.name


def test_files_are_only_written_by_the_expected_modules() -> None:
    """Writes happen in: log, audit log, history database and the report writer."""
    allowed = {"log.py", "audit.py", "history.py", "writer.py"}
    for path in SOURCES:
        text = path.read_text(encoding="utf-8")
        writes = re.search(r"\.write_text\(|\.mkdir\(|os\.open\(|open\([^)]*['\"][wax]", text)
        if writes:
            assert path.name in allowed, f"{path.name} writes to disk"


def test_the_network_is_only_touched_by_the_environment_layer() -> None:
    for path in SOURCES:
        text = path.read_text(encoding="utf-8")
        if re.search(
            r"^\s*(import|from)\s+(socket|urllib|http|requests|ssl)\b", text, re.MULTILINE
        ):
            assert path.name in {"environment.py", "interfaces.py"}, path.name


def test_no_telemetry_or_remote_resources_in_reports() -> None:
    for name in ("html.py", "markdown.py", "json_report.py"):
        text = (LUME / "reports" / name).read_text(encoding="utf-8")
        assert not re.search(r"https?://", text.replace("http://www.w3.org", "")), name
