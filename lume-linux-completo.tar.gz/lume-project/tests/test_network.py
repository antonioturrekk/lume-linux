import json

from lume.core import Status
from lume.network import analyze
from lume.network.dns import parse_resolv_conf, parse_resolvectl_dns, read_dns
from lume.network.interfaces import list_interfaces, list_routes
from lume.network.wifi import parse_proc_net_wireless, read_rfkill
from tests.helpers import FakeEnvironment, fixture, result

IP_ADDR = ("ip", "-j", "addr", "show")
IP_ROUTE = ("ip", "-j", "route", "show")
IP_ROUTE6 = ("ip", "-j", "-6", "route", "show")
PING = ("ping", "-c", "1", "-W", "2", "192.168.1.1")


def healthy(**overrides):
    files = {
        "/etc/resolv.conf": "nameserver 192.168.1.1\nsearch lan\n",
        "/proc/net/wireless": fixture("proc_net_wireless.txt"),
        "/sys/class/net/wlp2s0/wireless/x": "",
        "/sys/class/net/enp3s0/operstate": "down",
        "/sys/devices/virtual/net/docker0/x": "",
    }
    files.update(overrides.pop("files", {}))
    commands = {
        IP_ADDR: result(fixture("ip_addr_wifi.json")),
        IP_ROUTE: result(fixture("ip_route.json")),
        IP_ROUTE6: result("[]"),
        PING: result("64 bytes from 192.168.1.1: icmp_seq=1 ttl=64 time=2.31 ms\n"),
    }
    commands.update(overrides.pop("commands", {}))
    kwargs = {
        "resolve": {"example.com": ["93.184.216.34"]},
        "tcp": {("1.1.1.1", 443): 18.0},
    }
    kwargs.update(overrides)
    return FakeEnvironment(files, commands, **kwargs)


def check(report, check_id):
    return next(c for c in report.checks if c.check_id == check_id)


def statuses(report):
    return {c.check_id: c.status for c in report.checks}


def test_interfaces_from_ip_json() -> None:
    interfaces = {i.name: i for i in list_interfaces(healthy())}
    assert interfaces["lo"].kind == "loopback" and not interfaces["lo"].active
    assert interfaces["wlp2s0"].kind == "wifi" and interfaces["wlp2s0"].active
    assert interfaces["wlp2s0"].ipv4 == ("192.168.1.20/24",)
    assert interfaces["wlp2s0"].ipv6_global == ("2804:1b3:a:1::20/64",)
    assert interfaces["enp3s0"].kind == "ethernet" and interfaces["enp3s0"].state == "down"
    assert interfaces["docker0"].kind == "virtual"


def test_routes_from_ip_json() -> None:
    routes = list_routes(healthy())
    assert routes[0].is_default and routes[0].gateway == "192.168.1.1" and routes[0].metric == 600


def test_sysfs_fallback_when_ip_is_missing() -> None:
    env = FakeEnvironment(
        {
            "/sys/class/net/lo/operstate": "unknown\n",
            "/sys/class/net/eth0/operstate": "up\n",
            "/sys/class/net/eth0/address": "52:54:00:aa:bb:cc\n",
            "/sys/class/net/eth0/mtu": "1500\n",
            "/proc/net/if_inet6": "fe800000000000005054ff0faabbccdd 02 40 20 80 eth0\n",
            "/proc/net/route": (
                "Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\n"
                "eth0\t00000000\t0100000A\t0003\t0\t0\t100\t00000000\n"
                "eth0\t0000000A\t00000000\t0001\t0\t0\t100\t00FFFFFF\n"
            ),
        },
        ipv4={"eth0": ("10.0.0.15", 24)},
    )
    interfaces = {i.name: i for i in list_interfaces(env)}
    assert interfaces["eth0"].ipv4 == ("10.0.0.15/24",) and interfaces["eth0"].active
    assert interfaces["eth0"].ipv6 == ("fe80::5054:ff0f:aabb:ccdd/64",)
    assert interfaces["lo"].kind == "loopback"
    routes = list_routes(env)
    assert len(routes) == 1 and routes[0].gateway == "10.0.0.1" and routes[0].device == "eth0"


def test_invalid_ip_output_falls_back() -> None:
    env = FakeEnvironment(
        {"/sys/class/net/eth0/operstate": "up"},
        {IP_ADDR: result("not json")},
        ipv4={"eth0": ("1.2.3.4", 8)},
    )
    assert [i.name for i in list_interfaces(env)] == ["eth0"]


def test_dns_parsers() -> None:
    config = parse_resolv_conf(
        "# c\nnameserver 8.8.8.8\nnameserver fe80::1%eth0\nsearch a.lan b.lan\n"
    )
    assert config.servers == ("8.8.8.8", "fe80::1") and config.search == ("a.lan", "b.lan")
    assert not config.local_stub and parse_resolv_conf("nameserver 127.0.0.53").local_stub
    assert parse_resolvectl_dns("Global: 1.1.1.1\nLink 2 (enp3s0): 10.0.2.3 fe80::1\n") == (
        "1.1.1.1",
        "10.0.2.3",
        "fe80::1",
    )
    env = FakeEnvironment(
        {"/etc/resolv.conf": "nameserver 127.0.0.53\n"},
        {("resolvectl", "dns"): result("Global:\nLink 2 (eth0): 10.0.2.3\n")},
    )
    assert read_dns(env).upstream == ("10.0.2.3",)
    assert not read_dns(FakeEnvironment()).file_found


def test_wifi_parsers() -> None:
    signals = parse_proc_net_wireless(fixture("proc_net_wireless.txt"))
    assert len(signals) == 1 and signals[0].dbm == -52 and signals[0].quality == "excellent"
    unsigned = parse_proc_net_wireless("wlan0: 0000 40 216 0\n")
    assert unsigned[0].dbm == -40
    assert parse_proc_net_wireless("Inter-| sta-|\n face | tus |")[:] == []
    env = FakeEnvironment(
        {
            "/sys/class/rfkill/rfkill0/name": "phy0",
            "/sys/class/rfkill/rfkill0/type": "wlan",
            "/sys/class/rfkill/rfkill0/soft": "1",
            "/sys/class/rfkill/rfkill0/hard": "0",
        }
    )
    assert read_rfkill(env)[0].blocked


def test_healthy_connection_is_all_ok() -> None:
    report = analyze(healthy())
    assert all(c.status is Status.OK for c in report.checks if c.check_id != "network.wifi")
    assert "192.168.1.20" in check(report, "network.addresses").summary
    assert "answers ping (2 ms)" in check(report, "network.gateway").summary
    assert check(report, "network.internet").summary.startswith("reachable (TCP to 1.1.1.1:443")
    assert check(report, "network.wifi").summary == "wlp2s0: -52 dBm (excellent)"
    json.dumps(report.to_dict())


def test_offline_mode_runs_no_active_probe() -> None:
    env = healthy()
    report = analyze(env, offline=True)
    assert check(report, "network.internet").status is Status.SKIP
    assert check(report, "network.dns").status is Status.SKIP
    assert "--offline" in check(report, "network.dns").summary


def test_self_assigned_address_means_dhcp_failed() -> None:
    addr = json.loads(fixture("ip_addr_wifi.json"))
    addr[2]["addr_info"] = [
        {"family": "inet", "local": "169.254.8.9", "prefixlen": 16, "scope": "link"}
    ]
    report = analyze(healthy(commands={IP_ADDR: result(json.dumps(addr))}), offline=True)
    found = check(report, "network.addresses")
    assert found.status is Status.WARN and "no DHCP server answered" in found.evidence[0]


def test_link_up_without_address() -> None:
    addr = json.loads(fixture("ip_addr_wifi.json"))
    addr[2]["addr_info"] = []
    report = analyze(healthy(commands={IP_ADDR: result(json.dumps(addr))}))
    assert check(report, "network.addresses").status is Status.WARN
    assert check(report, "network.internet").status is Status.SKIP  # nothing to test


def test_no_active_interface() -> None:
    addr = json.loads(fixture("ip_addr_wifi.json"))
    addr[2]["operstate"] = "DOWN"
    report = analyze(healthy(commands={IP_ADDR: result(json.dumps(addr))}))
    found = check(report, "network.addresses")
    assert found.status is Status.WARN and any("enp3s0" in e for e in found.evidence)
    assert check(report, "network.gateway").status is Status.SKIP


def test_missing_default_route() -> None:
    report = analyze(healthy(commands={IP_ROUTE: result("[]")}), offline=True)
    assert check(report, "network.gateway").status is Status.WARN


def test_duplicate_default_routes_with_same_metric() -> None:
    routes = [
        {"dst": "default", "gateway": "192.168.1.1", "dev": "wlp2s0", "metric": 100},
        {"dst": "default", "gateway": "10.0.0.1", "dev": "enp3s0", "metric": 100},
    ]
    report = analyze(healthy(commands={IP_ROUTE: result(json.dumps(routes))}), offline=True)
    assert check(report, "network.gateway").status is Status.WARN


def test_gateway_ignoring_ping_is_not_an_error_if_internet_works() -> None:
    env = healthy(commands={PING: result("", 1)})
    assert check(analyze(env), "network.gateway").status is Status.OK
    env = healthy(commands={PING: result("", 1)}, tcp={})
    assert check(analyze(env), "network.gateway").status is Status.WARN


def test_missing_ping_does_not_fail_the_gateway_check() -> None:
    env = healthy()
    del env.commands[PING]
    found = check(analyze(env), "network.gateway")
    assert found.status is Status.OK and "default via 192.168.1.1" in found.summary


def test_dns_failure_with_working_internet_is_an_error() -> None:
    report = analyze(healthy(resolve={}))
    found = check(report, "network.dns")
    assert found.status is Status.ERROR and "although the internet is reachable" in found.summary
    assert check(report, "network.internet").status is Status.OK


def test_no_internet_is_an_error_with_evidence() -> None:
    report = analyze(healthy(tcp={}, resolve={}))
    internet = check(report, "network.internet")
    assert internet.status is Status.ERROR and len(internet.evidence) == 2
    assert check(report, "network.dns").status is Status.WARN  # cannot blame DNS alone


def test_second_target_is_used_when_first_fails() -> None:
    report = analyze(healthy(tcp={("9.9.9.9", 443): 30.0}))
    assert "9.9.9.9:443" in check(report, "network.internet").summary


def test_dns_configuration_problems() -> None:
    missing = analyze(healthy(files={"/etc/resolv.conf": "# empty\n"}), offline=True)
    assert check(missing, "network.dns_config").status is Status.ERROR
    env = healthy()
    del env.files["/etc/resolv.conf"]
    assert check(analyze(env, offline=True), "network.dns_config").status is Status.ERROR
    stub = analyze(healthy(files={"/etc/resolv.conf": "nameserver 127.0.0.53\n"}), offline=True)
    assert check(stub, "network.dns_config").summary.startswith("local resolver 127.0.0.53")


def test_wifi_blocked_and_weak_signal() -> None:
    blocked = analyze(
        healthy(
            files={
                "/sys/class/rfkill/rfkill0/name": "phy0",
                "/sys/class/rfkill/rfkill0/type": "wlan",
                "/sys/class/rfkill/rfkill0/hard": "1",
            }
        ),
        offline=True,
    )
    found = check(blocked, "network.wifi")
    assert found.status is Status.WARN and "hard blocked" in found.evidence[0]
    weak = analyze(
        healthy(files={"/proc/net/wireless": "wlp2s0: 0000 20. -86. -256 0 0 0 0 0 0\n"}),
        offline=True,
    )
    assert check(weak, "network.wifi").status is Status.WARN


def test_without_wifi_or_interfaces_everything_degrades_gracefully() -> None:
    report = analyze(FakeEnvironment(), offline=True)
    assert statuses(report)["network.wifi"] is Status.SKIP
    assert statuses(report)["network.interfaces"] is Status.SKIP
    assert not any(
        c.status is Status.ERROR for c in report.checks if c.check_id != "network.dns_config"
    )


def test_only_virtual_interfaces_is_a_warning() -> None:
    addr = [json.loads(fixture("ip_addr_wifi.json"))[0]]
    report = analyze(healthy(commands={IP_ADDR: result(json.dumps(addr))}), offline=True)
    assert check(report, "network.interfaces").status is Status.WARN
