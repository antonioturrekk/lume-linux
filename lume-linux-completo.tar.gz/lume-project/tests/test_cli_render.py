import io

from rich.console import Console

from lume.cli.commands import Command
from lume.cli.registry import COMMANDS
from lume.cli.render import print_main_help, render_results, summary_line
from lume.cli.theme import make_console
from lume.core import CheckResult, Status, summarize


class _Buffer(io.StringIO):
    """In-memory output that pretends to have a given terminal encoding."""

    def __init__(self, encoding: str) -> None:
        super().__init__()
        self._encoding = encoding

    @property
    def encoding(self) -> str:  # type: ignore[override]
        return self._encoding


def _console(encoding: str = "utf-8") -> tuple[Console, io.StringIO]:
    buffer = _Buffer(encoding)
    return make_console(file=buffer, width=100), buffer


def test_summary_line_variants() -> None:
    assert summary_line({Status.OK: 5, Status.WARN: 0, Status.ERROR: 0}) == "No problems detected."
    assert summary_line({Status.OK: 3, Status.WARN: 1, Status.ERROR: 0}) == "1 warning detected."
    assert summary_line({Status.OK: 3, Status.WARN: 2, Status.ERROR: 0}) == "2 warnings detected."
    assert (
        summary_line({Status.OK: 0, Status.WARN: 2, Status.ERROR: 1})
        == "1 error, 2 warnings detected."
    )
    assert summary_line({}) == "No problems detected."


def test_render_results_matches_documented_layout() -> None:
    results = [
        CheckResult("Hardware identification", Status.OK, "detected"),
        CheckResult("Graphics driver", Status.WARN, "generic driver", ("lspci: driver=vesafb",)),
        CheckResult("Network connectivity", Status.OK, "online"),
        CheckResult("Disk", Status.WARN, "92% used", ("df: /dev/sda1 92%",)),
    ]
    console, buffer = _console()
    render_results(console, results)
    out = buffer.getvalue()
    assert "SYSTEM STATUS" in out
    assert "[OK]" in out and "[WARN]" in out
    assert "Graphics driver" in out
    assert "↳ lspci: driver=vesafb" in out  # evidence of problems is always shown
    assert out.rstrip().endswith("2 warnings detected.")
    assert "\x1b[" not in out  # no color codes when not a terminal


def test_ok_evidence_is_hidden_unless_requested() -> None:
    result = CheckResult("RAM", Status.OK, "fine", ("free: 8 GiB",))
    console, buffer = _console()
    render_results(console, [result])
    assert "free: 8 GiB" not in buffer.getvalue()
    console, buffer = _console()
    render_results(console, [result], show_evidence=True)
    assert "free: 8 GiB" in buffer.getvalue()


def test_render_empty_results() -> None:
    console, buffer = _console()
    render_results(console, [])
    assert "No checks were run." in buffer.getvalue()


def test_system_text_is_never_parsed_as_markup() -> None:
    result = CheckResult("[bold]Device[/bold] [red]X", Status.OK, "ok [/oops]")
    console, buffer = _console()
    render_results(console, [result])  # must not raise MarkupError
    assert "[bold]Device[/bold] [red]X" in buffer.getvalue()


def test_ascii_fallback_for_non_utf8_terminals() -> None:
    console, buffer = _console(encoding="ascii")
    render_results(console, [CheckResult("Disk", Status.ERROR, "full", ("df: 100%",))])
    assert "-> df: 100%" in buffer.getvalue()
    assert "↳" not in buffer.getvalue()


def test_summarize_integration() -> None:
    results = [CheckResult("a", Status.OK, "x")]
    assert summary_line(summarize(results)) == "No problems detected."


def test_main_help_lists_every_command() -> None:
    console, buffer = _console()
    pending = Command("future", "not built yet", planned_phase=12)
    print_main_help(console, (*COMMANDS, pending))
    out = buffer.getvalue()
    for command in COMMANDS:
        assert command.name in out
    assert "future" in out and "(soon)" in out
