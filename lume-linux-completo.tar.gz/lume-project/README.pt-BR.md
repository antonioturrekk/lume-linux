# ✦ LUME

**Linux Utility & Monitoring Engine** — ferramenta livre de diagnóstico e suporte para Linux, que
funciona prioritariamente offline. Ela encontra problemas, explica em linguagem simples, mostra as
evidências e indica soluções verificadas — **sem nunca modificar o seu sistema**.

## Princípios

- **Somente leitura.** Só uma lista de comandos de leitura é executada, com argumentos fixos e sem
  shell. As soluções são **exibidas**, nunca executadas.
- **Evidência, não palpite.** Todo `WARN`/`ERROR` traz os fatos que o justificam. O que não pôde ser
  verificado aparece como `SKIP`, com o motivo.
- **Offline.** A única atividade de rede são duas sondas pequenas; `--offline` as desativa.
- **Privacidade.** Sem telemetria. Relatórios podem ser anonimizados (`--anonymize`).
- **Leve.** Cerca de 23 MiB de RAM e uma única dependência (Rich).

## Instalação

Requer Python 3.11+.

```bash
pipx install .                  # a partir deste repositório
# ou, em ambiente virtual:
python3 -m venv .venv && . .venv/bin/activate && pip install .
```

## Uso

```bash
lume                    # menu interativo
lume diagnose           # diagnóstico completo
lume hardware           # hardware
lume network            # rede
lume performance        # desempenho
lume storage            # armazenamento
lume solutions          # base de soluções (lume solutions SOL-0001)
lume report -f html --anonymize     # relatório para compartilhar (html | markdown | json)
```

Códigos de saída: `0` ok · `1` erro · `2` uso incorreto · `4` a análise encontrou ao menos um `ERROR`.

A interface e a base de soluções estão em inglês por enquanto; contribuições de tradução são bem-vindas.
Documentação completa em inglês: [README.md](README.md), [docs/USAGE.md](docs/USAGE.md).

## Licença

GPL-3.0-ou-posterior — veja [LICENSE](LICENSE).
